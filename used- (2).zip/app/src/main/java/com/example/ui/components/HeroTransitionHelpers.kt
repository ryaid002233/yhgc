package com.example.ui.components

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed

@OptIn(ExperimentalSharedTransitionApi::class)
val LocalSharedTransitionScope = compositionLocalOf<SharedTransitionScope?> { null }

val LocalNavAnimatedVisibilityScope = compositionLocalOf<AnimatedVisibilityScope?> { null }

@OptIn(ExperimentalSharedTransitionApi::class)
val HeroSpringBoundsTransform = BoundsTransform { _, _ ->
    spring(
        dampingRatio = 0.86f,
        stiffness = 520f
    )
}

@OptIn(ExperimentalSharedTransitionApi::class)
fun Modifier.heroElement(
    key: String?,
    renderInOverlayDuringTransition: Boolean = true,
    zIndexInOverlay: Float = 1f
): Modifier = composed {
    if (key.isNullOrBlank()) return@composed this
    val sharedScope = LocalSharedTransitionScope.current ?: return@composed this
    val visScope = LocalNavAnimatedVisibilityScope.current ?: return@composed this
    with(sharedScope) {
        this@composed.sharedElement(
            state = rememberSharedContentState(key = key),
            animatedVisibilityScope = visScope,
            boundsTransform = HeroSpringBoundsTransform,
            renderInOverlayDuringTransition = renderInOverlayDuringTransition,
            zIndexInOverlay = zIndexInOverlay
        )
    }
}

@OptIn(ExperimentalSharedTransitionApi::class)
fun Modifier.heroBounds(
    key: String?,
    renderInOverlayDuringTransition: Boolean = true,
    zIndexInOverlay: Float = 0f
): Modifier = composed {
    if (key.isNullOrBlank()) return@composed this
    val sharedScope = LocalSharedTransitionScope.current ?: return@composed this
    val visScope = LocalNavAnimatedVisibilityScope.current ?: return@composed this
    with(sharedScope) {
        this@composed.sharedBounds(
            sharedContentState = rememberSharedContentState(key = key),
            animatedVisibilityScope = visScope,
            boundsTransform = HeroSpringBoundsTransform,
            renderInOverlayDuringTransition = renderInOverlayDuringTransition,
            zIndexInOverlay = zIndexInOverlay
        )
    }
}
