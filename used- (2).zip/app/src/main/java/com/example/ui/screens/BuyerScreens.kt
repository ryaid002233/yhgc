package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.domain.WesternDigits.rawNumberString
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppStrings
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import kotlin.math.abs

@Composable
internal fun creditColor(isDark: Boolean): Color =
    if (isDark) AppColors.CreditGreenDark else AppColors.CreditGreen

@Composable
internal fun debitColor(isDark: Boolean): Color =
    if (isDark) AppColors.DebitRedDark else AppColors.DebitRed

@Composable
fun BuyerHubScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenDrawer: () -> Unit,
    onOpenBuyerFolders: () -> Unit,
    onOpenTransferSheets: () -> Unit,
    onOpenAnnualSheets: () -> Unit,
    onOpenSalesLedger: () -> Unit,
    onOpenProfitLedger: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    val settings = uiState.settings
    val snap = uiState.snapshot

    val filteredSales = remember(snap.buyerSales, settings.buyerActiveSpecialty) {
        snap.buyerSales.filter { matchesSpecialtyFilter(it.specialtyId, settings.buyerActiveSpecialty) }
    }
    val filteredProfits = remember(snap.buyerProfits, settings.buyerActiveSpecialty) {
        snap.buyerProfits.filter { matchesSpecialtyFilter(it.specialtyId, settings.buyerActiveSpecialty) }
    }
    val stats = remember(filteredSales, filteredProfits) {
        BuyerCalculators.computeStats(filteredSales, filteredProfits)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LuxuryMainTopBar(
            title = strings.purchase,
            onMenuClick = onOpenDrawer,
            secondaryIcon = Icons.Default.Sync,
            secondaryDesc = strings.t("مزامنة", "Sync"),
            secondaryTestTag = "buyer_sync_btn",
            onSecondaryClick = { viewModel.syncBuyerEcosystem() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top 3 Dark Horizontal Action Tiles matching Screenshot 7
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LuxuryDarkQuickTile(
                    label = strings.invoices,
                    onClick = onOpenBuyerFolders,
                    titleHeroKey = "hero_buyer_folders_title",
                    modifier = Modifier
                        .weight(1f)
                        .testTag("buyer_folders_card")
                )
                LuxuryDarkQuickTile(
                    label = strings.t("تحويل الشراء", "Conversion"),
                    onClick = onOpenTransferSheets,
                    titleHeroKey = "hero_buyer_transfer_title",
                    modifier = Modifier
                        .weight(1f)
                        .testTag("buyer_transfer_card")
                )
                LuxuryDarkQuickTile(
                    label = strings.t("الكشف السنوي", "Annual"),
                    onClick = onOpenAnnualSheets,
                    titleHeroKey = "hero_buyer_annual_title",
                    modifier = Modifier
                        .weight(1f)
                        .testTag("buyer_annual_card")
                )
            }

            // "المتحكم" Container Box matching Screenshot 7
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                border = BorderStroke(1.dp, LuxuryPalette.Gold.copy(alpha = 0.50f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = strings.t("المتحكم", "Controller"),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BuyerControllerGridCard(
                            title = strings.t("حوالات المبيعات", "Sales Remittances"),
                            subtitle = "",
                            value = stats.salesNet,
                            isDark = settings.dark,
                            tag = "buyer_sales_card",
                            titleHeroKey = "hero_buyer_ctrl_sales",
                            onClick = onOpenSalesLedger,
                            modifier = Modifier.weight(1f)
                        )
                        BuyerControllerGridCard(
                            title = strings.t("الأرباح والسحوبات", "Profits & Draws"),
                            subtitle = strings.t("قسم البائع", "Seller Split"),
                            value = stats.profitSellerNet,
                            isDark = settings.dark,
                            tag = "buyer_seller_profit_card",
                            titleHeroKey = "hero_buyer_ctrl_seller",
                            onClick = { onOpenProfitLedger("seller") },
                            modifier = Modifier.weight(1f)
                        )
                        BuyerControllerGridCard(
                            title = strings.t("الأرباح والسحوبات", "Profits & Draws"),
                            subtitle = strings.t("قسم المورد", "Supplier Split"),
                            value = stats.profitSupplierNet,
                            isDark = settings.dark,
                            tag = "buyer_supplier_profit_card",
                            titleHeroKey = "hero_buyer_ctrl_supplier",
                            onClick = { onOpenProfitLedger("supplier") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BuyerControllerGridCard(
    title: String,
    subtitle: String,
    value: Double,
    isDark: Boolean,
    tag: String,
    titleHeroKey: String? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fg = when {
        value > 1e-6 -> creditColor(isDark)
        value < -1e-6 -> debitColor(isDark)
        else -> MaterialTheme.colorScheme.onSurface
    }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, LuxuryPalette.Gold.copy(alpha = 0.55f)),
        shadowElevation = 2.dp,
        modifier = modifier
            .heightIn(min = 96.dp)
            .testTag(tag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(LuxuryPalette.creamBrush(isDark))
                .padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.heroBounds(titleHeroKey, zIndexInOverlay = 2f)
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = fmt(abs(value), 2),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = fg,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun BuyerInvoiceEditorScreen(
    folderId: String,
    invoiceId: String?,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    val folder = uiState.snapshot.weekFolders.firstOrNull { it.id == folderId }
    val existing = remember(folder, invoiceId) {
        if (invoiceId != null) folder?.invoices?.firstOrNull { it.id == invoiceId } else null
    }
    val isLocked = folder?.locked == true
    val takenDates = remember(folder, existing?.id) {
        folder?.invoices
            ?.filter { it.id != existing?.id && it.initDateISO.isNotBlank() }
            ?.map { it.initDateISO }
            ?.toSet()
            .orEmpty()
    }

    var tableNo by remember(existing?.id) { mutableStateOf(existing?.initNo ?: (folder?.order?.toString() ?: "")) }
    var dateIso by remember(existing?.id) {
        mutableStateOf(
            existing?.initDateISO?.ifBlank { null }
                ?: DateHelper.suggestNextFreeDate(
                    folder?.startDate.orEmpty(),
                    folder?.endDate.orEmpty(),
                    takenDates
                )
        )
    }
    var titleName by remember(existing?.id) { mutableStateOf(existing?.initSeller ?: "") }
    var expenseStr by remember(existing?.id) { mutableStateOf(existing?.buyerExpense?.takeIf { it > 0 }?.let { rawNumberString(it, 2) } ?: "") }
    var note by remember(existing?.id) { mutableStateOf(existing?.note ?: "") }
    var specialtyId by remember(existing?.id, folder?.id) {
        mutableStateOf(
            existing?.specialtyId?.ifBlank { folder?.specialtyId ?: "" }
                ?: folder?.specialtyId
                ?: if (uiState.settings.buyerActiveSpecialty !in listOf("all", "none")) uiState.settings.buyerActiveSpecialty else ""
        )
    }
    var rows by remember(existing?.id) {
        mutableStateOf(existing?.buyerRows?.ifEmpty { listOf(BuyerInvoiceRow()) } ?: listOf(BuyerInvoiceRow()))
    }
    var calcTarget by remember { mutableStateOf<Pair<String, (String) -> Unit>?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showPreview by remember { mutableStateOf(false) }

    val total = remember(rows) { rows.sumOf { num(it.qty) * num(it.price) } }
    val expense = num(expenseStr)
    val net = total + expense

    fun buildInv(): FolderInvoice {
        val cleanedRows = rows.filter { it.name.isNotBlank() || it.qty.isNotBlank() || it.price.isNotBlank() }
            .ifEmpty { listOf(BuyerInvoiceRow()) }
        return FolderInvoice(
            id = existing?.id ?: newId("inv"),
            folderId = folderId,
            invoiceKind = "buyer",
            initNo = tableNo.trim(),
            initDate = DateHelper.formatInvoiceDate(dateIso, uiState.settings.lang == "en"),
            initDateISO = dateIso.trim(),
            initSeller = titleName.trim(),
            note = note.trim(),
            specialtyId = specialtyId,
            buyerRows = cleanedRows.map { it.copy(total = num(it.qty) * num(it.price)) },
            buyerTotal = total,
            buyerExpense = expense,
            buyerNet = net,
            createdAt = existing?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun trySave() {
        if (titleName.isBlank()) {
            viewModel.emitMessage(strings.t("أدخل الاسم", "Enter name"))
            return
        }
        if (dateIso.isBlank()) {
            viewModel.emitMessage(strings.t("أدخل التاريخ", "Enter date"))
            return
        }
        val fStart = folder?.startDate.orEmpty()
        val fEnd = folder?.endDate.orEmpty()
        if ((fStart.isNotBlank() && dateIso < fStart) || (fEnd.isNotBlank() && dateIso > fEnd)) {
            viewModel.emitMessage(
                strings.t(
                    "التاريخ يجب أن يكون ضمن الأسبوع: من ${DateHelper.displaySlash(fStart)} إلى ${DateHelper.displaySlash(fEnd)}",
                    "Date must be within folder range"
                )
            )
            return
        }
        if (dateIso in takenDates) {
            viewModel.emitMessage(strings.t("يوجد فاتورة أخرى بنفس هذا التاريخ في هذا الأسبوع", "Another invoice already exists on this date"))
            return
        }
        val hasAnyData = rows.any { it.name.isNotBlank() || num(it.qty) > 0 || num(it.price) > 0 } || expense > 0
        if (!hasAnyData) {
            viewModel.emitMessage(strings.t("لا توجد بيانات للحفظ", "Nothing to save"))
            return
        }
        viewModel.saveInvoice(buildInv()) { onBack() }
    }

    if (showPreview) {
        BackHandler { showPreview = false }
        val invPreview = buildInv()
        Scaffold(
            topBar = {
                LuxurySubTopBar(
                    title = strings.t("معاينة فاتورة الشراء", "Invoice Preview"),
                    onBack = { showPreview = false }
                )
            }
        ) { pvPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pvPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, Color(0xFFCFE3F5)),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.t("فاتورة الشراء اليومية", "Daily Purchase Invoice"),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        HorizontalDivider(color = Color(0xFFE8EDF4))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${strings.t("رقم الجدول", "Table No")}: ${invPreview.initNo.ifBlank { "-" }}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("${strings.t("الاسم", "Name")}: ${invPreview.initSeller}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("${strings.date}: ${DateHelper.displaySlash(invPreview.initDateISO)}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        }

                        // Preview Table
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFFCFE3F5), RoundedCornerShape(8.dp))
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFE3F1FC))
                                    .padding(vertical = 8.dp, horizontal = 6.dp)
                            ) {
                                Text(strings.t("اسم الشروة", "Item"), fontWeight = FontWeight.Bold, color = Color(0xFF1F5B8F), modifier = Modifier.weight(1.4f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                                Text(strings.t("العدد", "Qty"), fontWeight = FontWeight.Bold, color = Color(0xFF1F5B8F), modifier = Modifier.weight(0.8f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                                Text(strings.t("مبلغ الشراء", "Price"), fontWeight = FontWeight.Bold, color = Color(0xFF1F5B8F), modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                                Text(strings.t("الإجمالي", "Total"), fontWeight = FontWeight.Bold, color = Color(0xFF1F5B8F), modifier = Modifier.weight(1.1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                            }
                            invPreview.buyerRows.forEach { r ->
                                HorizontalDivider(color = Color(0xFFE3E9F0))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(r.name.ifBlank { "-" }, modifier = Modifier.weight(1.4f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                                    Text(r.qty.ifBlank { "0" }, modifier = Modifier.weight(0.8f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                                    Text(fmt(num(r.price), 2), modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                                    Text(fmt(r.total, 2), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${strings.t("إجمالي الشراء", "Total")}: ${fmt(invPreview.buyerTotal, 2)}", fontWeight = FontWeight.Bold)
                            Text("${strings.t("الخرج اليومي", "Daily Expense")}: ${fmt(invPreview.buyerExpense, 2)}", fontWeight = FontWeight.Bold)
                            Text(
                                "${strings.net}: ${fmt(invPreview.buyerNet, 2)}",
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium,
                                color = creditColor(uiState.settings.dark)
                            )
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            viewModel.printHtmlReport(activity, invPreview.initDateISO, PrintReportBuilders.buildBuyerInvoiceHtml(invPreview, uiState.settings))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF52B788), contentColor = Color.White),
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 50.dp)
                            .testTag("buyer_preview_print_btn")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("طباعة", "Print"), fontWeight = FontWeight.Bold)
                    }
                    FilledTonalButton(
                        onClick = { showPreview = false },
                        shape = RoundedCornerShape(11.dp),
                        modifier = Modifier
                            .weight(0.45f)
                            .heightIn(min = 50.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.t("رجوع", "Back")
                        )
                    }
                }
            }
        }
        return
    }

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = strings.t("فاتورة الشرائي", "Purchase Invoice"),
                onBack = onBack,
                titleHeroKey = invoiceId?.let { "hero_invoice_title_$it" },
                actions = {
                    if (existing != null && !isLocked) {
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Delete,
                            contentDescription = strings.delete,
                            tint = MaterialTheme.colorScheme.error,
                            onClick = { confirmDelete = true }
                        )
                    }
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Print,
                        contentDescription = strings.print,
                        onClick = {
                            val inv = buildInv()
                            viewModel.printHtmlReport(activity, inv.initDateISO, PrintReportBuilders.buildBuyerInvoiceHtml(inv, uiState.settings))
                        }
                    )
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = strings.t("بيانات فاتورة الشراء اليومية", "Daily Purchase Invoice Details"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    HorizontalDivider(thickness = 2.dp, color = MaterialTheme.colorScheme.outlineVariant)

                    Text(
                        text = strings.t("التفاصيل الأساسية", "Basic Details"),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WesternNumberField(
                            value = tableNo,
                            onValueChange = { if (!isLocked) tableNo = it },
                            allowDecimal = false,
                            readOnly = isLocked,
                            label = strings.t("رقم الجدول", "Table No"),
                            modifier = Modifier.weight(0.75f)
                        )
                        NameSuggestTextField(
                            value = titleName,
                            onValueChange = { if (!isLocked) titleName = it },
                            readOnly = isLocked,
                            label = strings.t("الاسم", "Name"),
                            testTag = "buyer_name_input",
                            modifier = Modifier.weight(1.25f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ClickableDateField(
                            value = dateIso,
                            onDatePicked = { if (!isLocked) dateIso = it },
                            label = strings.date,
                            modifier = Modifier.weight(1f),
                            testTag = "buyer_date_input"
                        )
                        SpecialtyAssignDropdown(
                            specialties = uiState.settings.buyerSpecialties,
                            selectedId = specialtyId,
                            onAssign = { if (!isLocked) specialtyId = it },
                            onAddSpecialty = { n, w -> viewModel.addBuyerSpecialty(n, w) },
                            showWorkersAmount = false,
                            modifier = Modifier.weight(1.1f)
                        )
                    }

                    // 5-Column Horizontally Scrollable Table matching .tbl-wrap in DEFS["buyer"]
                    val hScroll = rememberScrollState()
                    val headerBg = if (uiState.settings.dark) Color(0xFF1E3A5F) else Color(0xFFE3F1FC)
                    val headerFg = if (uiState.settings.dark) Color(0xFFBAE6FD) else Color(0xFF1F5B8F)
                    val borderCol = if (uiState.settings.dark) Color(0xFF334155) else Color(0xFFCFE3F5)
                    val roBg = if (uiState.settings.dark) Color(0xFF1E293B) else Color(0xFFF2F5FA)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(hScroll)
                            .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .background(headerBg)
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.t("اسم الشروة", "Item"), fontWeight = FontWeight.Bold, color = headerFg, modifier = Modifier.width(145.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                            Text(strings.t("العدد", "Qty"), fontWeight = FontWeight.Bold, color = headerFg, modifier = Modifier.width(80.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                            Text(strings.t("مبلغ الشراء", "Price"), fontWeight = FontWeight.Bold, color = headerFg, modifier = Modifier.width(105.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                            Text(strings.t("إجمالي شراء الشروة", "Row Total"), fontWeight = FontWeight.Bold, color = headerFg, modifier = Modifier.width(120.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                            Text(strings.t("حذف", "Del"), fontWeight = FontWeight.Bold, color = headerFg, modifier = Modifier.width(58.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                        }

                        rows.forEachIndexed { idx, r ->
                            val rowTot = remember(r.qty, r.price) { num(r.qty) * num(r.price) }
                            val hasRowCalc = r.qty.isNotBlank() && r.price.isNotBlank()
                            HorizontalDivider(color = borderCol)
                            Row(
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                BuyerCompactCellField(
                                    value = r.name,
                                    onValueChange = { v ->
                                        if (!isLocked) rows = rows.toMutableList().apply { set(idx, r.copy(name = v)) }
                                    },
                                    readOnly = isLocked,
                                    isNumeric = false,
                                    modifier = Modifier.width(141.dp)
                                )
                                BuyerCompactCellField(
                                    value = r.qty,
                                    onValueChange = { v ->
                                        if (!isLocked) rows = rows.toMutableList().apply { set(idx, r.copy(qty = WesternDigits.cleanNumericInput(v))) }
                                    },
                                    readOnly = isLocked,
                                    isNumeric = true,
                                    modifier = Modifier.width(76.dp)
                                )
                                BuyerCompactCellField(
                                    value = r.price,
                                    onValueChange = { v ->
                                        if (!isLocked) rows = rows.toMutableList().apply { set(idx, r.copy(price = WesternDigits.cleanNumericInput(v))) }
                                    },
                                    readOnly = isLocked,
                                    isNumeric = true,
                                    modifier = Modifier.width(101.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .width(116.dp)
                                        .heightIn(min = 40.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(roBg)
                                        .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (hasRowCalc) fmt(rowTot, 2) else "",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1
                                    )
                                }
                                Box(
                                    modifier = Modifier.width(54.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Surface(
                                        onClick = {
                                            if (!isLocked) {
                                                rows = if (rows.size > 1) rows.toMutableList().apply { removeAt(idx) }
                                                else listOf(BuyerInvoiceRow())
                                            }
                                        },
                                        shape = RoundedCornerShape(9.dp),
                                        color = Color(0xFFFBE3E3),
                                        border = BorderStroke(1.dp, Color(0xFFF1B8B8)),
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("×", color = Color(0xFFD64545), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!isLocked) {
                        val dashCol = Color(0xFF8FC4EA)
                        val addBg = if (uiState.settings.dark) Color(0xFF172B44) else Color(0xFFE3F1FC)
                        val addFg = if (uiState.settings.dark) Color(0xFF7DD3FC) else Color(0xFF1F5B8F)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(addBg)
                                .drawBehind {
                                    drawRoundRect(
                                        color = dashCol,
                                        cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
                                        style = Stroke(
                                            width = 2.dp.toPx(),
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                                        )
                                    )
                                }
                                .clickable { rows = rows + BuyerInvoiceRow() }
                                .testTag("buyer_add_row_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = strings.t("+ إضافة صف جديد", "+ Add New Row"),
                                color = addFg,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    // Final Summary Card ("التفصيل النهائي") matching .nf-card in DEFS["buyer"]
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = strings.t("التفصيل النهائي", "Final Summary"),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(strings.t("إجمالي شراء الشروات", "Purchases Total"), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = roBg,
                                    border = BorderStroke(1.dp, borderCol),
                                    modifier = Modifier.width(150.dp)
                                ) {
                                    Text(
                                        text = fmt(total, 2),
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(strings.t("إجمالي الخرج اليومي", "Daily Expense"), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                WesternNumberField(
                                    value = expenseStr,
                                    onValueChange = { if (!isLocked) expenseStr = it },
                                    label = strings.t("الخرج", "Expense"),
                                    readOnly = isLocked,
                                    trailingIcon = if (!isLocked) {
                                        {
                                            IconButton(onClick = { calcTarget = expenseStr to { expenseStr = it } }) {
                                                Icon(Icons.Default.Calculate, contentDescription = strings.calculator)
                                            }
                                        }
                                    } else null,
                                    modifier = Modifier.width(150.dp)
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(strings.t("صافي الفاتورة", "Invoice Net"), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                                    modifier = Modifier.width(150.dp)
                                ) {
                                    Text(
                                        text = fmt(net, 2),
                                        fontWeight = FontWeight.Black,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = note,
                                onValueChange = { if (!isLocked) note = it },
                                readOnly = isLocked,
                                label = { Text(strings.note) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // Bottom 3 Buttons: حفظ البيانات ✓ | عرض المعاينة | إلغاء
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!isLocked) {
                            Button(
                                onClick = { trySave() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF52B788), contentColor = Color.White),
                                shape = RoundedCornerShape(11.dp),
                                modifier = Modifier
                                    .weight(1.1f)
                                    .heightIn(min = 50.dp)
                                    .testTag("buyer_save_btn")
                            ) {
                                Text(strings.t("حفظ البيانات ✓", "Save ✓"), fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                        FilledTonalButton(
                            onClick = { showPreview = true },
                            shape = RoundedCornerShape(11.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 50.dp)
                                .testTag("buyer_preview_btn")
                        ) {
                            Text(strings.t("عرض المعاينة", "Preview"), fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = onBack,
                            shape = RoundedCornerShape(11.dp),
                            modifier = Modifier
                                .weight(0.75f)
                                .heightIn(min = 50.dp)
                        ) {
                            Text(strings.cancel, maxLines = 1)
                        }
                    }
                }
            }
        }
    }

    calcTarget?.let { (initVal, onApply) ->
        CalculatorDialog(
            initialValue = initVal,
            onResult = onApply,
            onDismiss = { calcTarget = null }
        )
    }

    if (confirmDelete && existing != null) {
        ConfirmActionDialog(
            title = strings.delete,
            message = strings.t("هل تريد نقل هذه الفاتورة إلى سلة المهملات؟", "Move this invoice to Trash?"),
            confirmText = strings.delete,
            onConfirm = {
                viewModel.deleteInvoice(existing)
                onBack()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
private fun BuyerCompactCellField(
    value: String,
    onValueChange: (String) -> Unit,
    readOnly: Boolean,
    isNumeric: Boolean,
    modifier: Modifier = Modifier
) {
    val bg = if (readOnly) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
    Box(
        modifier = modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            .padding(horizontal = 6.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            readOnly = readOnly,
            singleLine = true,
            textStyle = TextStyle(
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            ),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = KeyboardOptions(
                keyboardType = if (isNumeric) KeyboardType.Decimal else KeyboardType.Text
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BuyerTransferListAndEditorScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val activity = LocalContext.current.findActivityOrNull()
    var selectedSheetId by remember { mutableStateOf<String?>(null) }

    val selectedSheet = uiState.snapshot.buyerTransfers.firstOrNull { it.id == selectedSheetId }
    if (selectedSheet != null) {
        BuyerTransferEditorPane(
            initialSheet = selectedSheet,
            uiState = uiState,
            viewModel = viewModel,
            onClose = { selectedSheetId = null }
        )
        return
    }

    var sortField by remember { mutableStateOf("date") }
    var sortAsc by remember { mutableStateOf(true) }
    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var longPressSheet by remember { mutableStateOf<BuyerTransferSheet?>(null) }

    val folderSpecMap = remember(uiState.snapshot.weekFolders) {
        uiState.snapshot.weekFolders.associate { it.id to it.specialtyId }
    }
    val folderCountMap = remember(uiState.snapshot.weekFolders) {
        uiState.snapshot.weekFolders.associate { it.id to it.invoices.size }
    }
    val filteredTransfers = remember(
        uiState.snapshot.buyerTransfers,
        folderSpecMap,
        uiState.settings.buyerActiveSpecialty,
        fromDate,
        toDate,
        sortField,
        sortAsc
    ) {
        val list = uiState.snapshot.buyerTransfers.filter { ts ->
            val spId = ts.specialtyId.ifBlank { folderSpecMap[ts.folderId] ?: "" }
            val specOk = matchesSpecialtyFilter(spId, uiState.settings.buyerActiveSpecialty)
            val dateOk = (fromDate.isBlank() || ts.toDate.ifBlank { ts.fromDate } >= fromDate) &&
                (toDate.isBlank() || ts.fromDate.ifBlank { ts.toDate } <= toDate)
            specOk && dateOk
        }
        val comparator: Comparator<BuyerTransferSheet> = when (sortField) {
            "name" -> compareBy { it.name }
            "amount" -> compareBy { BuyerCalculators.calculateTransfer(it).diff }
            else -> compareBy<BuyerTransferSheet> { it.fromDate }.thenBy { it.name }
        }
        val sorted = list.sortedWith(comparator)
        if (sortAsc) sorted else sorted.reversed()
    }

    val summary = remember(filteredTransfers, selectedIds) {
        val chosen = filteredTransfers.filter { it.id in selectedIds }
        val base = if (chosen.isNotEmpty()) chosen else filteredTransfers
        var totalCost = 0.0
        var totalSale = 0.0
        var totalDiff = 0.0
        base.forEach { ts ->
            val c = BuyerCalculators.calculateTransfer(ts)
            totalCost += c.totalExpenses
            totalSale += ts.weeklySale
            totalDiff += c.diff
        }
        QuadSummary(base.size, totalCost, totalSale, totalDiff)
    }

    val allSelected = filteredTransfers.isNotEmpty() && selectedIds.size == filteredTransfers.size

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = strings.t("تحويل الشراء", "Purchase Conversion"),
                onBack = onBack,
                titleHeroKey = "hero_buyer_transfer_title",
                actions = {
                    if (selectedIds.isNotEmpty()) {
                        LuxuryHeaderIconBtn(
                            icon = Icons.Default.Print,
                            contentDescription = strings.print,
                            onClick = {
                                val chosen = filteredTransfers.filter { it.id in selectedIds }
                                if (chosen.size == 1) {
                                    viewModel.printHtmlReport(
                                        activity,
                                        chosen.first().name,
                                        PrintReportBuilders.buildBuyerTransferHtml(chosen.first(), uiState.settings)
                                    )
                                } else if (chosen.isNotEmpty()) {
                                    val combined = chosen.joinToString("<hr style='margin:24px 0'/>") {
                                        PrintReportBuilders.buildBuyerTransferHtml(it, uiState.settings)
                                    }
                                    viewModel.printHtmlReport(activity, strings.t("تحويل الشراء", "Conversion"), combined)
                                }
                            }
                        )
                    }
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Sync,
                        contentDescription = strings.t("مزامنة", "Sync"),
                        onClick = { viewModel.syncBuyerEcosystem() }
                    )
                }
            )
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = {
                    val today = DateHelper.todayIso()
                    val sp = if (uiState.settings.buyerActiveSpecialty in listOf("all", "none")) "" else uiState.settings.buyerActiveSpecialty
                    val created = BuyerTransferSheet(
                        specialtyId = sp,
                        name = strings.t("كشف تحويل جديد", "New Conversion"),
                        fromDate = today,
                        toDate = DateHelper.addDays(today, 6)
                    )
                    viewModel.saveBuyerTransferSheet(created)
                    selectedSheetId = created.id
                },
                contentDescription = strings.t("إضافة كشف تحويل", "Add Conversion Sheet")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(2.dp))
            LuxurySortBar(
                options = listOf(
                    "date" to strings.t("التاريخ 📅", "Date"),
                    "name" to strings.t("الاسم", "Name"),
                    "amount" to strings.t("الفارق", "Diff")
                ),
                selected = sortField,
                sortAsc = sortAsc,
                onSelect = { sortField = it },
                onDirectionChange = { sortAsc = it }
            )

            LuxuryDateRangeBar(
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = { f, t -> fromDate = f; toDate = t; selectedIds = emptySet() }
            )

            LuxurySpecialtyHeaderBar(
                specialties = uiState.settings.buyerSpecialties,
                selectedId = uiState.settings.buyerActiveSpecialty,
                onSelect = viewModel::setBuyerSpecialty,
                onAddSpecialty = { n, w -> viewModel.addBuyerSpecialty(n, w) },
                showWorkersAmount = false,
                showManageButton = false,
                showSelectAll = true,
                selectAllChecked = allSelected,
                onToggleSelectAll = {
                    selectedIds = if (allSelected) emptySet() else filteredTransfers.map { it.id }.toSet()
                }
            )

            // 4 KPI Cards Row matching .bp-sum in renderTransfer()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SummaryStatCard(
                    if (selectedIds.isNotEmpty()) strings.t("المحدد", "Sel") else strings.t("الأسابيع", "Weeks"),
                    "${summary.count}",
                    modifier = Modifier.weight(0.75f)
                )
                SummaryStatCard(strings.t("الشراء مع الخرج", "Buy+Exp"), fmt(summary.cost, 0), modifier = Modifier.weight(1.1f))
                SummaryStatCard(strings.t("البيع", "Sale"), fmt(summary.sale, 0), modifier = Modifier.weight(0.95f))
                SummaryStatCard(
                    strings.t("الفارق", "Diff"),
                    fmt(abs(summary.diff), 0),
                    if (summary.diff >= 0) creditColor(uiState.settings.dark) else debitColor(uiState.settings.dark),
                    Modifier.weight(0.95f)
                )
            }

            if (filteredTransfers.isEmpty()) {
                Box(Modifier.fillMaxSize()) {
                    EmptyStateView(
                        Icons.Default.CurrencyExchange,
                        strings.t("لا توجد جداول تحويل شراء", "No Conversion Sheets"),
                        strings.t("أنشئ مجلد فواتير شرائي أو اضغط + لإضافة كشف تحويل", "Create a purchase folder or tap + to add one")
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(filteredTransfers, key = { it.id }) { ts ->
                        val calc = remember(ts) { BuyerCalculators.calculateTransfer(ts) }
                        val invCount = if (ts.folderId.isNotBlank()) (folderCountMap[ts.folderId] ?: ts.rows.size) else ts.rows.size
                        val isSel = ts.id in selectedIds
                        val diffColor = when {
                            calc.diff > 1e-6 -> creditColor(uiState.settings.dark)
                            calc.diff < -1e-6 -> debitColor(uiState.settings.dark)
                            else -> creditColor(uiState.settings.dark)
                        }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else Color.Transparent,
                            border = BorderStroke(1.dp, if (isSel) MaterialTheme.colorScheme.primary else LuxuryPalette.Gold.copy(alpha = 0.5f)),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { selectedSheetId = ts.id },
                                    onLongClick = { longPressSheet = ts }
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LuxuryPalette.creamBrush(uiState.settings.dark))
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Checkbox(
                                    checked = isSel,
                                    onCheckedChange = { checked ->
                                        selectedIds = if (checked) selectedIds + ts.id else selectedIds - ts.id
                                    }
                                )
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        text = "${ts.name.ifBlank { strings.t("كشف تحويل", "Conversion") }} 🗓️",
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${DateHelper.displaySlash(ts.fromDate)} ← ${DateHelper.displaySlash(ts.toDate)} · $invCount ${strings.t("فاتورة", "inv")}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = fmt(abs(calc.diff), 0),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = diffColor
                                    )
                                    Text(
                                        text = "${calc.profitLabel} · ${strings.t("حبات", "Units")} ${fmt(ts.habbaCount, 0)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    longPressSheet?.let { ts ->
        AlertDialog(
            onDismissRequest = { longPressSheet = null },
            title = { Text(ts.name.ifBlank { strings.t("تحويل الشراء", "Conversion") }, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = { selectedSheetId = ts.id; longPressSheet = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("👁️ عرض الجدول", "View Sheet"), modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        onClick = {
                            selectedIds = if (ts.id in selectedIds) selectedIds - ts.id else selectedIds + ts.id
                            longPressSheet = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (ts.id in selectedIds) strings.t("☑️ إلغاء التحديد", "Deselect") else strings.t("✅ تحديد", "Select"),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    TextButton(
                        onClick = {
                            viewModel.printHtmlReport(activity, ts.name, PrintReportBuilders.buildBuyerTransferHtml(ts, uiState.settings))
                            longPressSheet = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.t("🖨️ طباعة", "Print"), modifier = Modifier.fillMaxWidth()) }
                    if (ts.folderId.isBlank()) {
                        TextButton(
                            onClick = {
                                viewModel.deleteBuyerTransferSheet(ts.id)
                                longPressSheet = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(strings.t("🗑️ حذف الجدول", "Delete Sheet"), color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth()) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { longPressSheet = null }) { Text(strings.close) }
            }
        )
    }
}

private data class QuadSummary(val count: Int, val cost: Double, val sale: Double, val diff: Double)

private data class DailySlotDisplay(
    val dayName: String,
    val dateSlash: String,
    val hasData: Boolean,
    val qty: Double,
    val buy: Double,
    val exp: Double
)

@Composable
private fun BuyerTransferEditorPane(
    initialSheet: BuyerTransferSheet,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val activity = context.findActivityOrNull()

    val linkedFolder = uiState.snapshot.weekFolders.firstOrNull { it.id == initialSheet.folderId }

    // Keyed by sheet ID so unrelated DB emissions never reset unsaved typing
    var name by remember(initialSheet.id) { mutableStateOf(initialSheet.name) }
    var fromDate by remember(initialSheet.id) { mutableStateOf(initialSheet.fromDate) }
    var toDate by remember(initialSheet.id) { mutableStateOf(initialSheet.toDate) }
    var specialtyId by remember(initialSheet.id) { mutableStateOf(initialSheet.specialtyId) }
    var oldPriceStr by remember(initialSheet.id) { mutableStateOf(if (initialSheet.oldPrice > 0) rawNumberString(initialSheet.oldPrice, 4) else "") }
    var newPriceStr by remember(initialSheet.id) { mutableStateOf(if (initialSheet.newPrice > 0) rawNumberString(initialSheet.newPrice, 4) else "") }
    var rentRadaStr by remember(initialSheet.id) { mutableStateOf(if (initialSheet.rentRada > 0) rawNumberString(initialSheet.rentRada, 2) else "") }
    var rentShipStr by remember(initialSheet.id) { mutableStateOf(if (initialSheet.rentShip > 0) rawNumberString(initialSheet.rentShip, 2) else "") }
    var weeklySaleStr by remember(initialSheet.id) { mutableStateOf(if (initialSheet.weeklySale > 0) rawNumberString(initialSheet.weeklySale, 2) else "") }
    var habbaCountStr by remember(initialSheet.id) { mutableStateOf(if (initialSheet.habbaCount > 0) rawNumberString(initialSheet.habbaCount, 2) else "") }
    var diffAccountName by remember(initialSheet.id) { mutableStateOf(initialSheet.diffAccountName) }
    var diffNote by remember(initialSheet.id) { mutableStateOf(initialSheet.diffNote) }
    var rows by remember(initialSheet.id) { mutableStateOf(initialSheet.rows) }
    var showAddRowDialog by remember { mutableStateOf(false) }
    var showEditWeekDialog by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    val dailySlots = remember(linkedFolder, fromDate, toDate) {
        if (linkedFolder == null) emptyList()
        else {
            val slots = DateHelper.buildWeekSlots(
                fromDate.ifBlank { linkedFolder.startDate },
                toDate.ifBlank { linkedFolder.endDate }
            )
            val byDate = linkedFolder.invoices.groupBy { it.initDateISO }
            slots.map { (dayNm, dateIso) ->
                val invs = byDate[dateIso].orEmpty()
                val q = invs.sumOf { inv -> inv.buyerRows.sumOf { num(it.qty) } }
                val b = invs.sumOf { it.buyerTotal }
                val ex = invs.sumOf { it.buyerExpense }
                DailySlotDisplay(
                    dayName = dayNm,
                    dateSlash = DateHelper.displaySlash(dateIso),
                    hasData = invs.isNotEmpty(),
                    qty = q,
                    buy = b,
                    exp = ex
                )
            }
        }
    }

    val draftSheet = remember(
        initialSheet.id, name, fromDate, toDate, specialtyId,
        oldPriceStr, newPriceStr, rentRadaStr, rentShipStr,
        weeklySaleStr, habbaCountStr, diffAccountName, diffNote, rows
    ) {
        initialSheet.copy(
            name = name.trim(),
            fromDate = fromDate.trim(),
            toDate = toDate.trim(),
            specialtyId = specialtyId,
            oldPrice = num(oldPriceStr),
            newPrice = num(newPriceStr),
            rentRada = num(rentRadaStr),
            rentShip = num(rentShipStr),
            weeklySale = num(weeklySaleStr),
            habbaCount = num(habbaCountStr),
            diffAccountName = diffAccountName.trim(),
            diffNote = diffNote.trim(),
            rows = rows
        )
    }
    val calc = remember(draftSheet) { BuyerCalculators.calculateTransfer(draftSheet) }
    val diffColor = when {
        calc.diff > 1e-6 -> creditColor(uiState.settings.dark)
        calc.diff < -1e-6 -> debitColor(uiState.settings.dark)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val diffLabel = when {
        calc.diff > 1e-6 -> strings.t("الفارق (ربح)", "Diff (Profit)")
        calc.diff < -1e-6 -> strings.t("الفارق (خسارة)", "Diff (Loss)")
        else -> strings.t("الفارق", "Diff")
    }
    val tableQtyTotal = remember(dailySlots, draftSheet.habbaCount) {
        if (dailySlots.isNotEmpty()) dailySlots.sumOf { it.qty } else draftSheet.habbaCount
    }
    val tableBuyTotal = remember(dailySlots, rows) {
        if (dailySlots.isNotEmpty()) dailySlots.sumOf { it.buy } else rows.sumOf { it.buy }
    }
    val tableExpTotal = remember(dailySlots, rows) {
        if (dailySlots.isNotEmpty()) dailySlots.sumOf { it.exp } else rows.sumOf { it.exp }
    }

    Scaffold(
        topBar = {
            LuxurySubTopBar(
                title = name.ifBlank { strings.t("تحويل الشراء", "Conversion") },
                onBack = onClose,
                actions = {
                    LuxuryHeaderIconBtn(
                        icon = Icons.Default.Print,
                        contentDescription = strings.print,
                        onClick = {
                            viewModel.printHtmlReport(activity, draftSheet.name, PrintReportBuilders.buildBuyerTransferHtml(draftSheet, uiState.settings))
                        }
                    )
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. .bp-head 2x2 Grid Header
            StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BpHeadCell(strings.t("اسم الأسبوع", "Week Name"), name.ifBlank { "-" }, Modifier.weight(1f))
                        BpHeadCell(strings.t("رقم الجدول", "Table No"), linkedFolder?.order?.toString() ?: "-", Modifier.weight(1f))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BpHeadCell(strings.t("من تاريخ", "From Date"), DateHelper.displaySlash(fromDate).ifBlank { "-" }, Modifier.weight(1f))
                        BpHeadCell(strings.t("إلى تاريخ", "To Date"), DateHelper.displaySlash(toDate).ifBlank { "-" }, Modifier.weight(1f))
                    }
                }
            }

            // 2. "تفاصيل الأسبوع" 5-Column Table + "الجملة" Footer
            BpSectionBanner(strings.t("تفاصيل الأسبوع", "Week Details"))

            val tblBorder = MaterialTheme.colorScheme.outlineVariant
            val tblHeadBg = MaterialTheme.colorScheme.primary
            val tblTotalBg = if (uiState.settings.dark) Color(0xFF1F2937) else Color(0xFFF1F5F9)
            val hScroll = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(hScroll)
                    .border(1.dp, tblBorder, RoundedCornerShape(10.dp))
                    .clip(RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier
                        .background(tblHeadBg)
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.t("اليوم / التاريخ", "Day / Date"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(120.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("عدد الحبة", "Units"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(74.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("سعر الشرائي", "Buy Price"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(96.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("خرج رداع", "Rada Exp"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(92.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    Text(strings.t("إجمالي الشراء", "Total Buy"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    if (linkedFolder == null) {
                        Text(strings.delete, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.width(48.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
                    }
                }

                if (linkedFolder != null) {
                    dailySlots.forEach { slot ->
                        HorizontalDivider(color = tblBorder)
                        Row(
                            modifier = Modifier
                                .background(
                                    if (slot.hasData) MaterialTheme.colorScheme.surface
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                                )
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(slot.dayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                Text(slot.dateSlash, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(if (slot.hasData) fmt(slot.qty, 0) else "", modifier = Modifier.width(74.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text(if (slot.hasData) fmt(slot.buy, 2) else "", modifier = Modifier.width(96.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text(if (slot.hasData) fmt(slot.exp, 2) else "", modifier = Modifier.width(92.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text(if (slot.hasData) fmt(slot.buy + slot.exp, 2) else "", fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    rows.forEach { row ->
                        HorizontalDivider(color = tblBorder)
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(row.name.ifBlank { "-" }, fontWeight = FontWeight.Bold, modifier = Modifier.width(120.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text("-", modifier = Modifier.width(74.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text(fmt(row.buy, 2), modifier = Modifier.width(96.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text(fmt(row.exp, 2), modifier = Modifier.width(92.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            Text(fmt(row.buy + row.exp, 2), fontWeight = FontWeight.Bold, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                            IconButton(
                                onClick = { rows = rows.filterNot { it.id == row.id } },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                // Footer Total Row ("الجملة")
                HorizontalDivider(color = tblBorder, thickness = 1.5.dp)
                Row(
                    modifier = Modifier
                        .background(tblTotalBg)
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.t("الجملة", "Total"), fontWeight = FontWeight.Black, modifier = Modifier.width(120.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                    Text(fmt(tableQtyTotal, 0), fontWeight = FontWeight.Black, modifier = Modifier.width(74.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                    Text(fmt(tableBuyTotal, 2), fontWeight = FontWeight.Black, modifier = Modifier.width(96.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                    Text(fmt(tableExpTotal, 2), fontWeight = FontWeight.Black, modifier = Modifier.width(92.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                    Text(fmt(calc.oldTotal, 2), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, modifier = Modifier.width(102.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                    if (linkedFolder == null) {
                        Spacer(Modifier.width(48.dp))
                    }
                }
            }

            if (linkedFolder == null) {
                OutlinedButton(
                    onClick = { showAddRowDialog = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.t("+ إضافة صف شراء", "+ Add Purchase Row"), fontWeight = FontWeight.Bold)
                }
            }

            // 3. "تحويل الشراء جديد" (.bp-calc)
            BpSectionBanner(strings.t("تحويل الشراء جديد", "New Purchase Conversion"))
            StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BpCalcValueRow(
                        label = strings.t("مبلغ الشراء قديم (جملة الأيام)", "Old Purchase Total"),
                        value = fmt(calc.oldTotal, 2)
                    )
                    BpCalcInputRow(
                        label = strings.t("سعر السعودي القديم", "Old Saudi Rate"),
                        value = oldPriceStr,
                        onValueChange = { oldPriceStr = it }
                    )
                    BpCalcValueRow(
                        label = strings.t("الشراء قديم = مبلغ سعودي على صرف رداع", "Old Total in Saudi FX"),
                        value = fmt(calc.exchange, 2),
                        highlightBg = Color(0xFFDBEAFE),
                        highlightFg = Color(0xFF1E40AF)
                    )
                    BpCalcInputRow(
                        label = strings.t("سعر شراء السعودي جديد", "New Saudi Buy Rate"),
                        value = newPriceStr,
                        onValueChange = { newPriceStr = it }
                    )
                    BpCalcValueRow(
                        label = strings.t("الشراء قديم = الشراء جديد", "New Equivalent Total"),
                        value = fmt(calc.newTotal, 2),
                        highlightBg = Color(0xFFDCFCE7),
                        highlightFg = Color(0xFF166534)
                    )
                    if (num(oldPriceStr) > 0.0) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${fmt(calc.oldTotal, 2)} ÷ ${fmt(num(oldPriceStr), 2)} = ${fmt(calc.exchange, 2)} × ${fmt(num(newPriceStr), 2)} = ${fmt(calc.newTotal, 2)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // 4. "التفصيل النهائي" (.bp-calc)
            BpSectionBanner(strings.t("التفصيل النهائي", "Final Breakdown"))
            StyledAppCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BpCalcValueRow(
                        label = strings.t("إجمالي الشراء جديد", "New Purchase Total"),
                        value = fmt(calc.newTotal, 2)
                    )
                    BpCalcInputRow(
                        label = strings.t("خرج إجار رداع جديد", "New Rada Rent"),
                        value = rentRadaStr,
                        onValueChange = { rentRadaStr = it }
                    )
                    BpCalcInputRow(
                        label = strings.t("خرج إجار شحن جديد", "New Shipping Rent"),
                        value = rentShipStr,
                        onValueChange = { rentShipStr = it }
                    )
                    BpCalcValueRow(
                        label = strings.t("إجمالي الشراء مع الخرج جديد", "Total Buy + Expenses"),
                        value = fmt(calc.totalExpenses, 2),
                        highlightBg = Color(0xFFFEE2E2),
                        highlightFg = Color(0xFFDC2626)
                    )
                    BpCalcInputRow(
                        label = strings.t("بيع الأسبوع المفصل شحن", "Weekly Sale (Shipped)"),
                        value = weeklySaleStr,
                        onValueChange = { weeklySaleStr = it }
                    )
                    BpCalcInputRow(
                        label = strings.t("عدد الحبات", "Units Count"),
                        value = habbaCountStr,
                        onValueChange = { habbaCountStr = it }
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NameSuggestTextField(
                            value = diffAccountName,
                            onValueChange = { diffAccountName = it },
                            label = strings.t("حساب الفرق", "Diff Account"),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = diffNote,
                            onValueChange = { diffNote = it },
                            label = { Text(strings.t("بيان الفرق", "Diff Note")) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    BpCalcValueRow(
                        label = diffLabel,
                        value = fmt(abs(calc.diff), 2),
                        highlightBg = when {
                            calc.diff > 1e-6 -> Color(0xFFDCFCE7)
                            calc.diff < -1e-6 -> Color(0xFFFEE2E2)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        highlightFg = diffColor
                    )
                }
            }

            // 5. Bottom 5-button action bar (.bp-acts)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BpActionPillBtn(
                    label = strings.t("🚪 خروج", "Exit"),
                    bg = MaterialTheme.colorScheme.surfaceVariant,
                    fg = MaterialTheme.colorScheme.onSurfaceVariant,
                    onClick = onClose,
                    modifier = Modifier.weight(1f)
                )
                BpActionPillBtn(
                    label = strings.t("🗑️ مسح", "Clear"),
                    bg = Color(0xFFFEE2E2),
                    fg = Color(0xFFDC2626),
                    onClick = { confirmClear = true },
                    modifier = Modifier.weight(1f)
                )
                BpActionPillBtn(
                    label = strings.t("📤 مشاركة", "Share"),
                    bg = Color(0xFFDCFCE7),
                    fg = Color(0xFF15803D),
                    onClick = {
                        val txt = buildString {
                            append("تحويل الشراء — ").append(draftSheet.name).append('\n')
                            append("من ").append(DateHelper.displaySlash(fromDate)).append(" إلى ").append(DateHelper.displaySlash(toDate)).append('\n')
                            append("عدد الحبات: ").append(fmt(tableQtyTotal, 0)).append('\n')
                            append("مبلغ الشراء قديم: ").append(fmt(calc.oldTotal, 2)).append('\n')
                            append("الشراء جديد: ").append(fmt(calc.newTotal, 2)).append('\n')
                            append("إجمالي الشراء مع الخرج: ").append(fmt(calc.totalExpenses, 2)).append('\n')
                            append("بيع الأسبوع: ").append(fmt(draftSheet.weeklySale, 2)).append('\n')
                            append("الفارق (${calc.profitLabel}): ").append(fmt(abs(calc.diff), 2))
                        }
                        ShareHelper.shareText(context, draftSheet.name.ifBlank { "تحويل الشراء" }, txt)
                    },
                    modifier = Modifier.weight(1f)
                )
                BpActionPillBtn(
                    label = strings.t("✏️ تعديل", "Edit"),
                    bg = Color(0xFFFEF3C7),
                    fg = Color(0xFFB45309),
                    onClick = { showEditWeekDialog = true },
                    modifier = Modifier.weight(1f)
                )
            }
            Button(
                onClick = {
                    viewModel.saveBuyerTransferSheet(draftSheet)
                    onClose()
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 50.dp)
                    .testTag("buyer_transfer_save_btn")
            ) {
                Text(strings.t("💾 حفظ الجدول", "💾 Save Sheet"), fontWeight = FontWeight.Black)
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = strings.t("📊 يتحدث الكشف السنوي (تخصيص هذا الأسبوع) تلقائياً", "📊 Annual Summary (this week's specialty) updates automatically"),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }

    if (showAddRowDialog) {
        var rName by remember { mutableStateOf("") }
        var rBuy by remember { mutableStateOf("") }
        var rExp by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddRowDialog = false },
            title = { Text(strings.t("إضافة بند شراء", "Add Purchase Row")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NameSuggestTextField(value = rName, onValueChange = { rName = it }, label = strings.t("البيان", "Label"), modifier = Modifier.fillMaxWidth())
                    WesternNumberField(value = rBuy, onValueChange = { rBuy = it }, label = strings.t("الشراء", "Buy"))
                    WesternNumberField(value = rExp, onValueChange = { rExp = it }, label = strings.t("المصروف", "Expense"))
                }
            },
            confirmButton = {
                Button(onClick = {
                    rows = rows + BuyerTransferRow(name = rName.trim(), buy = num(rBuy), exp = num(rExp))
                    showAddRowDialog = false
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showAddRowDialog = false }) { Text(strings.cancel) } }
        )
    }

    if (showEditWeekDialog) {
        var eName by remember(name) { mutableStateOf(name) }
        var eFrom by remember(fromDate) { mutableStateOf(fromDate) }
        var eTo by remember(toDate) { mutableStateOf(toDate) }
        var eSpec by remember(specialtyId) { mutableStateOf(specialtyId) }
        AlertDialog(
            onDismissRequest = { showEditWeekDialog = false },
            title = { Text(strings.t("تعديل بيانات الأسبوع", "Edit Week Info"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NameSuggestTextField(value = eName, onValueChange = { eName = it }, label = strings.t("اسم الأسبوع", "Week Name"), modifier = Modifier.fillMaxWidth())
                    ClickableDateField(value = eFrom, onDatePicked = { eFrom = it }, label = strings.from, modifier = Modifier.fillMaxWidth())
                    ClickableDateField(value = eTo, onDatePicked = { eTo = it }, label = strings.to, modifier = Modifier.fillMaxWidth())
                    SpecialtyAssignDropdown(
                        specialties = uiState.settings.buyerSpecialties,
                        selectedId = eSpec,
                        onAssign = { eSpec = it },
                        onAddSpecialty = { n, w -> viewModel.addBuyerSpecialty(n, w) },
                        showWorkersAmount = false,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    name = eName.trim()
                    fromDate = eFrom.trim()
                    toDate = eTo.trim()
                    specialtyId = eSpec
                    if (linkedFolder != null) {
                        viewModel.saveWeekFolder(
                            linkedFolder.copy(
                                name = eName.trim(),
                                startDate = eFrom.trim(),
                                endDate = eTo.trim(),
                                specialtyId = eSpec
                            )
                        )
                    }
                    viewModel.saveBuyerTransferSheet(
                        draftSheet.copy(
                            name = eName.trim(),
                            fromDate = eFrom.trim(),
                            toDate = eTo.trim(),
                            specialtyId = eSpec
                        )
                    )
                    showEditWeekDialog = false
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showEditWeekDialog = false }) { Text(strings.cancel) } }
        )
    }

    if (confirmClear) {
        ConfirmActionDialog(
            title = strings.t("مسح", "Clear"),
            message = strings.t("مسح بيانات الإدخال اليدوي لهذا الأسبوع؟", "Clear manual inputs for this week?"),
            confirmText = strings.t("مسح", "Clear"),
            onConfirm = {
                oldPriceStr = ""
                newPriceStr = ""
                rentRadaStr = ""
                rentShipStr = ""
                weeklySaleStr = ""
                viewModel.saveBuyerTransferSheet(
                    draftSheet.copy(
                        oldPrice = 0.0,
                        newPrice = 0.0,
                        rentRada = 0.0,
                        rentShip = 0.0,
                        weeklySale = 0.0
                    )
                )
                confirmClear = false
            },
            onDismiss = { confirmClear = false }
        )
    }
}

@Composable
private fun BpHeadCell(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun BpSectionBanner(title: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 10.dp)
        )
    }
}

@Composable
private fun BpCalcValueRow(
    label: String,
    value: String,
    highlightBg: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
    highlightFg: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = highlightBg,
            border = BorderStroke(1.dp, highlightFg.copy(alpha = 0.3f)),
            modifier = Modifier.width(136.dp)
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.Black,
                color = highlightFg,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun BpCalcInputRow(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp)
        )
        BuyerCompactCellField(
            value = value,
            onValueChange = { onValueChange(WesternDigits.cleanNumericInput(it)) },
            readOnly = false,
            isNumeric = true,
            modifier = Modifier.width(136.dp)
        )
    }
}

@Composable
private fun BpActionPillBtn(
    label: String,
    bg: Color,
    fg: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.3f)),
        modifier = modifier.heightIn(min = 48.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)) {
            Text(label, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}


