package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DateHelper
import com.example.domain.Specialty
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens

object LuxuryPalette {
    val HeaderTop = Color(0xFF090B10)
    val HeaderBottom = Color(0xFF171B24)
    val DarkCardTop = Color(0xFF0D1017)
    val DarkCardBottom = Color(0xFF1B202B)
    val Gold = Color(0xFFD8AE52)
    val GoldSoft = Color(0xFFE7C97D)
    val CreamTop = Color(0xFFFFFFFF)
    val CreamBottom = Color(0xFFF3EFE4)
    val DarkSurfaceTop = Color(0xFF1C212C)
    val DarkSurfaceBottom = Color(0xFF141821)

    private val cachedHeaderBrush: Brush = Brush.verticalGradient(listOf(HeaderTop, HeaderBottom))
    private val cachedDarkCardBrush: Brush = Brush.verticalGradient(listOf(DarkCardTop, DarkCardBottom))
    private val cachedCreamLightBrush: Brush = Brush.verticalGradient(listOf(CreamTop, CreamBottom))
    private val cachedCreamDarkBrush: Brush = Brush.verticalGradient(listOf(DarkSurfaceTop, DarkSurfaceBottom))

    fun headerBrush(): Brush = cachedHeaderBrush
    fun darkCardBrush(): Brush = cachedDarkCardBrush
    fun creamBrush(isDark: Boolean): Brush = if (isDark) cachedCreamDarkBrush else cachedCreamLightBrush
}

@Composable
private fun frameBorderOrNull(widthMultiplier: Float = 1f, customColor: Color? = null): BorderStroke? {
    val tokens = LocalFrameTokens.current
    if (!tokens.frameEnabled || tokens.borderWidth <= 0.dp || tokens.frameStyle == "none") return null
    val w = (tokens.borderWidth.value * widthMultiplier).dp.coerceAtLeast(0.8.dp)
    return BorderStroke(w, customColor ?: tokens.borderColor)
}

@Composable
fun LuxuryMainTopBar(
    title: String,
    onMenuClick: () -> Unit,
    modifier: Modifier = Modifier,
    menuTestTag: String = "drawer_menu_button",
    secondaryIcon: ImageVector = Icons.Default.Notifications,
    secondaryDesc: String = "",
    secondaryTestTag: String = "",
    onSecondaryClick: (() -> Unit)? = null,
    extraActions: @Composable RowScope.() -> Unit = {}
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val btnShape = RoundedCornerShape(tokens.buttonRadius)
    val btnBorder = frameBorderOrNull(customColor = tokens.barDivider)
    Surface(
        color = Color.Transparent,
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.barBrush)
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onMenuClick,
                    modifier = Modifier
                        .size(48.dp)
                        .let { if (menuTestTag.isNotBlank()) it.testTag(menuTestTag) else it }
                ) {
                    Surface(
                        shape = btnShape,
                        color = tokens.barButtonBg,
                        border = btnBorder,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = strings.settings,
                                tint = tokens.barContent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Text(
                    text = title,
                    color = tokens.barContent,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    extraActions()
                    if (onSecondaryClick != null) {
                        IconButton(
                            onClick = onSecondaryClick,
                            modifier = Modifier
                                .size(48.dp)
                                .let { if (secondaryTestTag.isNotBlank()) it.testTag(secondaryTestTag) else it }
                        ) {
                            Surface(
                                shape = btnShape,
                                color = tokens.barButtonBg,
                                border = btnBorder,
                                modifier = Modifier.size(38.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = secondaryIcon,
                                        contentDescription = secondaryDesc,
                                        tint = tokens.barAccent,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                }
            }
            if (tokens.frameEnabled && tokens.frameStyle != "none") {
                HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
            }
        }
    }
}

@Composable
fun LuxurySubTopBar(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    backTestTag: String = "luxury_back_btn",
    includeStatusBarPadding: Boolean = true,
    titleHeroKey: String? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    Surface(
        color = Color.Transparent,
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.barBrush)
                .let { if (includeStatusBarPadding) it.statusBarsPadding() else it }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .let { if (backTestTag.isNotBlank()) it.testTag(backTestTag) else it }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.t("رجوع", "Back"),
                        tint = tokens.barContent,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = tokens.barContent,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.heroBounds(titleHeroKey, zIndexInOverlay = 2f)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    content = actions
                )
            }
            if (tokens.frameEnabled && tokens.frameStyle != "none") {
                HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
            }
        }
    }
}

@Composable
fun LuxuryHeaderIconBtn(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    tint: Color? = null,
    testTag: String = ""
) {
    val tokens = LocalFrameTokens.current
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(48.dp)
            .let { if (testTag.isNotBlank()) it.testTag(testTag) else it }
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.buttonRadius),
            color = tokens.barButtonBg,
            border = frameBorderOrNull(customColor = tokens.barDivider),
            modifier = Modifier.size(38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    icon,
                    contentDescription = contentDescription,
                    tint = tint ?: tokens.barAccent,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
fun LuxuryBottomNavBar(
    currentRoute: String?,
    homeRoute: String,
    privateRoute: String,
    buyerRoute: String,
    onSelect: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val items = listOf(
        Triple(homeRoute, strings.home, Icons.Default.Home to "nav_tab_home"),
        Triple(privateRoute, strings.privateAccounts, Icons.Default.Person to "nav_tab_private"),
        Triple(buyerRoute, strings.purchase, Icons.Default.ShoppingBag to "nav_tab_buyer")
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(tokens.barBrush)
    ) {
        if (tokens.frameEnabled && tokens.frameStyle != "none") {
            HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items.forEach { (route, label, iconTag) ->
                val (icon, tag) = iconTag
                val selected = currentRoute == route ||
                    (route == privateRoute && currentRoute?.startsWith("private") == true)
                Surface(
                    onClick = { onSelect(route) },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = if (selected) tokens.barButtonBg else Color.Transparent,
                    border = if (selected) frameBorderOrNull(customColor = tokens.barAccent.copy(alpha = 0.72f)) else null,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 52.dp)
                        .testTag(tag)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(tokens.iconTileRadius))
                                .background(
                                    if (selected) tokens.barAccent
                                    else tokens.barContent.copy(alpha = 0.22f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (selected) tokens.barTop else tokens.barContent,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = label,
                            color = if (selected) tokens.barAccent else tokens.barContent.copy(alpha = 0.88f),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LuxuryDarkQuickTile(
    icon: ImageVector? = null,
    label: String,
    badgeTint: Color = Color(0xFF38BDF8),
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeText: String = "",
    titleHeroKey: String? = null,
    cardHeroKey: String? = null
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = frameBorderOrNull(1.1f),
        shadowElevation = tokens.elevation,
        modifier = modifier
            .heightIn(min = 50.dp)
            .heroBounds(cardHeroKey)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 8.dp, vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                color = tokens.darkTileContent,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.heroBounds(titleHeroKey, zIndexInOverlay = 2f)
            )
        }
    }
}

@Composable
fun LuxurySpecialtyHeaderBar(
    specialties: List<Specialty>,
    selectedId: String,
    onSelect: (String) -> Unit,
    onAddSpecialty: (String, Double) -> Unit,
    showWorkersAmount: Boolean = true,
    showManageButton: Boolean = true,
    showSelectAll: Boolean = false,
    selectAllChecked: Boolean = false,
    onToggleSelectAll: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var menuOpen by remember { mutableStateOf(false) }
    var showManageDialog by remember { mutableStateOf(false) }

    val selectedLabel = when (selectedId) {
        "all", "" -> strings.allSpecialties
        "none" -> strings.noSpecialty
        else -> specialties.firstOrNull { it.id == selectedId }?.name ?: strings.allSpecialties
    }

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = frameBorderOrNull(1.1f),
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.darkTileBrush)
                .padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (showManageButton) {
                Surface(
                    onClick = { showManageDialog = true },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.heightIn(min = 38.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.t("التخاصيص", "Specialties"),
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                Surface(
                    onClick = { menuOpen = true },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = frameBorderOrNull(0.8f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 38.dp)
                        .testTag("specialty_filter_button")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = selectedLabel,
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text(strings.allSpecialties, fontWeight = if (selectedId == "all" || selectedId.isBlank()) FontWeight.Bold else FontWeight.Normal) },
                        leadingIcon = {
                            if (selectedId == "all" || selectedId.isBlank()) Icon(Icons.Default.Check, contentDescription = null)
                            else Icon(Icons.Default.AllInclusive, contentDescription = null)
                        },
                        onClick = { onSelect("all"); menuOpen = false }
                    )
                    DropdownMenuItem(
                        text = { Text(strings.noSpecialty, fontWeight = if (selectedId == "none") FontWeight.Bold else FontWeight.Normal) },
                        leadingIcon = {
                            if (selectedId == "none") Icon(Icons.Default.Check, contentDescription = null)
                            else Icon(Icons.Default.LabelOff, contentDescription = null)
                        },
                        onClick = { onSelect("none"); menuOpen = false }
                    )
                    if (specialties.isNotEmpty()) {
                        HorizontalDivider()
                        specialties.forEach { sp ->
                            val isSel = selectedId == sp.id
                            DropdownMenuItem(
                                text = { Text(sp.name, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                                leadingIcon = {
                                    if (isSel) Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    else Icon(Icons.Default.Label, contentDescription = null)
                                },
                                onClick = { onSelect(sp.id); menuOpen = false }
                            )
                        }
                    }
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = {
                            Text(
                                strings.t("إضافة تخصيص جديد +", "Add Specialty +"),
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        onClick = { menuOpen = false; showManageDialog = true }
                    )
                }
            }

            if (showSelectAll && onToggleSelectAll != null) {
                Surface(
                    onClick = onToggleSelectAll,
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = if (selectAllChecked) tokens.barAccent else MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .heightIn(min = 38.dp)
                        .testTag("select_all_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = strings.selectAll,
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Icon(
                            imageVector = if (selectAllChecked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = strings.selectAll,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    if (showManageDialog) {
        var spName by remember { mutableStateOf("") }
        var spWorkers by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showManageDialog = false },
            title = { Text(strings.t("إضافة تخصيص جديد", "Add Specialty"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = spName,
                        onValueChange = { spName = it },
                        label = { Text(strings.t("اسم التخصيص *", "Name *")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (showWorkersAmount) {
                        WesternNumberField(
                            value = spWorkers,
                            onValueChange = { spWorkers = it },
                            label = strings.t("مبلغ خرج العمال (اختياري)", "Workers Amount"),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (spName.isNotBlank()) {
                            onAddSpecialty(spName.trim(), com.example.domain.WesternDigits.num(spWorkers))
                            showManageDialog = false
                        }
                    },
                    enabled = spName.isNotBlank()
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showManageDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
fun <T> LuxurySortBar(
    options: List<Pair<T, String>>,
    selected: T,
    sortAsc: Boolean,
    onSelect: (T) -> Unit,
    onDirectionChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var dropdownOpen by remember { mutableStateOf(false) }
    val selectedLabel = options.firstOrNull { it.first == selected }?.second ?: ""

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = frameBorderOrNull(),
        shadowElevation = tokens.elevation,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.cardBrush)
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = strings.t("ترتيب حسب:", "Sort by:"),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )

            Box(modifier = Modifier.weight(1f)) {
                Surface(
                    onClick = { dropdownOpen = true },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = frameBorderOrNull(0.8f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 38.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = selectedLabel,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
                DropdownMenu(expanded = dropdownOpen, onDismissRequest = { dropdownOpen = false }) {
                    options.forEach { (key, label) ->
                        DropdownMenuItem(
                            text = { Text(label, fontWeight = if (key == selected) FontWeight.Bold else FontWeight.Normal) },
                            leadingIcon = {
                                if (key == selected) Icon(Icons.Default.Check, contentDescription = null)
                            },
                            onClick = { onSelect(key); dropdownOpen = false }
                        )
                    }
                }
            }

            LuxurySortDirChip(
                label = strings.t("↑ تصاعدي", "↑ Asc"),
                selected = sortAsc,
                onClick = { onDirectionChange(true) }
            )
            LuxurySortDirChip(
                label = strings.t("↓ تنازلي", "↓ Desc"),
                selected = !sortAsc,
                onClick = { onDirectionChange(false) }
            )
        }
    }
}

@Composable
private fun LuxurySortDirChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val tokens = LocalFrameTokens.current
    val surfaceCol = MaterialTheme.colorScheme.surface
    val surfaceVarCol = MaterialTheme.colorScheme.surfaceVariant
    val unselectedBrush = remember(surfaceCol, surfaceVarCol) {
        Brush.verticalGradient(listOf(surfaceCol, surfaceVarCol))
    }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.buttonRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled) {
            BorderStroke(1.dp, if (selected) tokens.borderColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
        } else null,
        shadowElevation = if (selected) tokens.elevation else 0.dp,
        modifier = Modifier.heightIn(min = 38.dp)
    ) {
        Box(
            modifier = Modifier
                .background(if (selected) tokens.darkTileBrush else unselectedBrush)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                color = if (selected) tokens.darkTileContent else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
fun LuxuryDateRangeBar(
    fromDate: String,
    toDate: String,
    onRangeChange: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var pickingTarget by remember { mutableStateOf<String?>(null) }

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Surface(
            onClick = {
                val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, -1)
                onRangeChange(nf, nt)
            },
            shape = RoundedCornerShape(tokens.buttonRadius),
            color = Color.Transparent,
            border = frameBorderOrNull(),
            modifier = Modifier
                .size(44.dp)
                .testTag("date_shift_prev_btn")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(tokens.darkTileBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = strings.t("الفترة السابقة", "Previous"),
                    tint = tokens.darkTileContent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius),
            color = MaterialTheme.colorScheme.surface,
            border = frameBorderOrNull(),
            shadowElevation = tokens.elevation,
            modifier = Modifier.weight(1f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    onClick = { pickingTarget = "from" },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 38.dp)
                        .testTag("date_from_input")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = strings.from,
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (fromDate.isNotBlank()) DateHelper.displaySlash(fromDate) else strings.from,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Text(
                    text = strings.t("إلى", "to"),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    onClick = { pickingTarget = "to" },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 38.dp)
                        .testTag("date_to_input")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = strings.to,
                            tint = tokens.iconTileTint,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (toDate.isNotBlank()) DateHelper.displaySlash(toDate) else strings.to,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Surface(
            onClick = {
                val (nf, nt) = DateHelper.shiftPeriod(fromDate, toDate, 1)
                onRangeChange(nf, nt)
            },
            shape = RoundedCornerShape(tokens.buttonRadius),
            color = Color.Transparent,
            border = frameBorderOrNull(),
            modifier = Modifier
                .size(44.dp)
                .testTag("date_shift_next_btn")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(tokens.darkTileBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = strings.t("الفترة التالية", "Next"),
                    tint = tokens.darkTileContent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }

    if (pickingTarget != null) {
        AppDatePickerDialog(
            initialIso = if (pickingTarget == "from") fromDate else toDate,
            onPicked = { picked ->
                if (pickingTarget == "from") onRangeChange(picked, toDate)
                else onRangeChange(fromDate, picked)
                pickingTarget = null
            },
            onDismiss = { pickingTarget = null }
        )
    }
}

@Composable
fun LuxuryAddFab(
    onClick: () -> Unit,
    contentDescription: String,
    modifier: Modifier = Modifier,
    icon: ImageVector = Icons.Default.Add
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = frameBorderOrNull(1.1f),
        shadowElevation = (tokens.elevation.value * 2f).dp,
        modifier = modifier.size(56.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(tokens.darkTileBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tokens.darkTileContent,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun rightFabPosition(): FabPosition =
    if (LocalLayoutDirection.current == LayoutDirection.Rtl) FabPosition.Start else FabPosition.End

@Composable
fun rightBottomAlignment(): Alignment =
    if (LocalLayoutDirection.current == LayoutDirection.Rtl) Alignment.BottomStart else Alignment.BottomEnd

@Composable
fun LuxuryDrawerMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String = "",
    iconTint: Color? = null,
    isDanger: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
            BorderStroke(
                width = tokens.borderWidth.coerceAtLeast(0.8.dp),
                color = if (isDanger) MaterialTheme.colorScheme.error.copy(alpha = 0.55f) else tokens.borderColor
            )
        } else null,
        shadowElevation = (tokens.elevation.value * 0.5f).dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.cardBrush)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(tokens.iconTileRadius))
                    .background(if (isDanger) MaterialTheme.colorScheme.errorContainer else tokens.iconTileBg)
                    .then(
                        if (tokens.frameEnabled && tokens.frameStyle != "none") {
                            Modifier.border(1.dp, tokens.borderColor.copy(alpha = 0.55f), RoundedCornerShape(tokens.iconTileRadius))
                        } else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isDanger) MaterialTheme.colorScheme.error else (iconTint ?: tokens.iconTileTint),
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle.isNotBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(RoundedCornerShape((tokens.iconTileRadius.value - 2f).coerceAtLeast(2f).dp))
                    .then(
                        if (tokens.frameEnabled && tokens.frameStyle != "none") {
                            Modifier.border(1.dp, tokens.borderColor.copy(alpha = 0.5f), RoundedCornerShape((tokens.iconTileRadius.value - 2f).coerceAtLeast(2f).dp))
                        } else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = null,
                    tint = tokens.iconTileTint,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
