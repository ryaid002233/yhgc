package com.example.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.domain.AppSettings
import com.example.domain.AppearanceSettings
import com.example.domain.Strings

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance

@Immutable
data class FrameTokens(
    val cornerRadius: Dp = 16.dp,
    val buttonRadius: Dp = 12.dp,
    val borderWidth: Dp = 1.dp,
    val borderColor: Color = Color(0x33D8AE52),
    val frameStyle: String = "solid",
    val frameEnabled: Boolean = true,
    val shadowsEnabled: Boolean = true,
    val elevation: Dp = 2.dp,
    val isBrutal: Boolean = false,
    val isGlass: Boolean = false,
    val isFlat: Boolean = false,
    val isLuxury: Boolean = false,
    val barTop: Color = Color(0xFF090B10),
    val barBottom: Color = Color(0xFF171B24),
    val barButtonBg: Color = Color(0xFF171B24),
    val barContent: Color = Color.White,
    val barAccent: Color = Color(0xFFE7C97D),
    val barDivider: Color = Color(0xB8D8AE52),
    val cardTop: Color = Color(0xFFFFFFFF),
    val cardBottom: Color = Color(0xFFF3EFE4),
    val darkTileTop: Color = Color(0xFF0D1017),
    val darkTileBottom: Color = Color(0xFF1B202B),
    val darkTileContent: Color = Color.White,
    val iconTileBg: Color = Color(0xFFEFF6FF),
    val iconTileTint: Color = Color(0xFF1E40AF),
    val iconTileRadius: Dp = 10.dp
) {
    val barBrush: Brush = Brush.verticalGradient(listOf(barTop, barBottom))
    val darkTileBrush: Brush = Brush.verticalGradient(listOf(darkTileTop, darkTileBottom))
    val cardBrush: Brush = Brush.verticalGradient(listOf(cardTop, cardBottom))
}

fun resolveFrameTokens(appearance: AppearanceSettings, colors: ColorScheme, dark: Boolean = false): FrameTokens {
    val radius = if (!appearance.frameShapeEnabled) 14.dp else when (appearance.frameShape) {
        "square" -> 0.dp
        "soft" -> 6.dp
        "rounded" -> 14.dp
        "round" -> 22.dp
        "pill", "circle" -> 28.dp
        else -> 14.dp
    }
    val btnRadius = when (appearance.buttonShape) {
        "rounded" -> 20.dp
        "simple" -> 4.dp
        else -> 10.dp
    }
    val iconRadius = when (appearance.buttonShape) {
        "rounded" -> 14.dp
        "simple" -> 4.dp
        else -> if (appearance.frameShape == "square") 2.dp else 10.dp
    }
    val width = if (!appearance.frameEnabled || !appearance.frameThicknessEnabled) 0.dp else when (appearance.frameThickness) {
        "medium" -> 2.dp
        "thick" -> 3.dp
        else -> 1.dp
    }
    val col = if (!appearance.frameEnabled) Color.Transparent else if (!appearance.frameColorEnabled) {
        colors.primary
    } else when (appearance.frameColor) {
        "gold" -> AppColors.GoldAccent
        "silver" -> AppColors.Silver
        "copper" -> AppColors.Copper
        "theme" -> colors.primary
        else -> parseHexColor(appearance.frameColor, AppColors.GoldAccent)
    }

    val design = appearance.designType
    val isBrutal = design == "neobrutalism"
    val isGlass = design == "glassmorphism" || design == "fluent"
    val isFlat = design == "flat" || design == "minimal"
    val isLuxury = design == "luxury" || design == "editorial"
    val resolvedStyle = if (!appearance.frameEnabled) "none"
    else if (!appearance.frameStyleEnabled) "solid"
    else appearance.frameStyle.ifBlank { "solid" }

    val primary = colors.primary
    val primaryDeep = lerp(primary, Color.Black, if (dark) 0.55f else 0.34f)
    val primarySoft = lerp(primary, if (dark) Color(0xFF0F172A) else Color.White, 0.85f)

    // Derive bar colors & foregrounds per design system + primary color + dark mode
    val (barTop, barBot, barBtnBg, barContent, barAccent) = when (design) {
        "luxury" -> listOf(
            Color(0xFF090B10),
            lerp(Color(0xFF171B24), primary, 0.14f),
            Color(0xFF171B24),
            Color.White,
            AppColors.GoldLight
        )
        "futuristic" -> listOf(
            Color(0xFF070D19),
            lerp(Color(0xFF0F172A), primary, 0.28f),
            Color(0xFF111C33),
            Color(0xFFE0F2FE),
            Color(0xFF22D3EE)
        )
        "editorial" -> if (dark) listOf(
            Color(0xFF111111), Color(0xFF1E1E1E), Color(0xFF262626), Color.White, AppColors.GoldLight
        ) else listOf(
            Color(0xFFFFFFFF), Color(0xFFF8F7F4), Color(0xFFF1EFE9), Color(0xFF111111), primary
        )
        "minimal" -> if (dark) listOf(
            Color(0xFF0F172A), Color(0xFF182235), Color(0xFF1E293B), Color(0xFFF8FAFC), primary
        ) else listOf(
            Color(0xFFFFFFFF), Color(0xFFF8FAFC), Color(0xFFF1F5F9), Color(0xFF0F172A), primary
        )
        "neumorphism" -> if (dark) listOf(
            Color(0xFF1B2230), Color(0xFF222B3C), Color(0xFF283347), Color(0xFFF1F5F9), primary
        ) else listOf(
            Color(0xFFE8EEF5), Color(0xFFDDE5EF), Color(0xFFF1F5F9), Color(0xFF0F172A), primary
        )
        "neobrut" , "neobrutalism" -> listOf(
            if (dark) primaryDeep else lerp(primary, Color(0xFFFACC15), 0.35f),
            if (dark) primary else lerp(primary, Color(0xFFFDE047), 0.25f),
            Color(0xFF111827),
            if (dark) Color.White else Color(0xFF0F172A),
            if (dark) Color(0xFFFACC15) else Color(0xFF0F172A)
        )
        "classic" -> listOf(
            lerp(Color(0xFF3E2723), primary, 0.28f),
            lerp(Color(0xFF2B1B17), primary, 0.22f),
            lerp(Color(0xFF4E342E), primary, 0.22f),
            Color(0xFFFFF8E7),
            AppColors.GoldLight
        )
        "glassmorphism" -> {
            val gTop = if (dark) lerp(Color(0xFF0B1120), primary, 0.36f) else lerp(primary, primaryDeep, 0.22f)
            val gBot = if (dark) lerp(Color(0xFF131D33), primary, 0.26f) else primaryDeep
            listOf(gTop, gBot, Color.White.copy(alpha = 0.14f), Color.White, lerp(col, Color.White, 0.45f))
        }
        else -> {
            // material3, bento, flat, fluent, skeuomorphism, ui3d, hybrid
            val bTop = if (dark) lerp(Color(0xFF0F172A), primary, 0.30f) else primary
            val bBot = if (dark) lerp(Color(0xFF1E293B), primaryDeep, 0.35f) else primaryDeep
            val fg = if (bTop.luminance() > 0.56f) Color(0xFF0F172A) else Color.White
            val accent = if (appearance.frameColor == "gold") AppColors.GoldLight else if (fg == Color.White) lerp(primary, Color.White, 0.65f) else primaryDeep
            listOf(bTop, bBot, fg.copy(alpha = if (fg == Color.White) 0.14f else 0.08f), fg, accent)
        }
    }

    val (tileTop, tileBot, tileFg) = when (design) {
        "luxury" -> Triple(Color(0xFF0D1017), Color(0xFF1B202B), Color.White)
        "futuristic" -> Triple(Color(0xFF0B1220), lerp(Color(0xFF172554), primary, 0.3f), Color(0xFFE0F2FE))
        "editorial", "minimal" -> if (dark) Triple(Color(0xFF182235), Color(0xFF1E293B), Color(0xFFF8FAFC))
        else Triple(Color(0xFFFFFFFF), Color(0xFFF8FAFC), Color(0xFF0F172A))
        else -> {
            val fg = if (primaryDeep.luminance() > 0.56f) Color(0xFF0F172A) else Color.White
            Triple(lerp(primary, Color.Black, if (dark) 0.38f else 0.18f), primaryDeep, fg)
        }
    }

    val (cardTop, cardBot) = when {
        dark -> Color(0xFF1C212C) to lerp(Color(0xFF141821), primary, 0.06f)
        design == "luxury" || design == "classic" -> Color(0xFFFFFFFF) to Color(0xFFF3EFE4)
        design == "neumorphism" -> Color(0xFFF1F5F9) to Color(0xFFE2E8F0)
        design == "glassmorphism" -> Color(0xFFFFFFFF).copy(alpha = 0.92f) to primarySoft.copy(alpha = 0.72f)
        design == "flat" || design == "minimal" -> Color(0xFFFFFFFF) to Color(0xFFFFFFFF)
        else -> Color(0xFFFFFFFF) to lerp(Color(0xFFF8FAFC), primarySoft, 0.35f)
    }

    val iconBg = when {
        dark -> lerp(Color(0xFF1E293B), primary, 0.26f)
        design == "luxury" -> Color(0xFFFFF8E6)
        else -> primarySoft
    }
    val iconTint = when {
        design == "luxury" && !dark -> Color(0xFF92400E)
        design == "futuristic" -> Color(0xFF22D3EE)
        else -> primary
    }

    val resolvedBorderColor = when {
        !appearance.frameEnabled -> Color.Transparent
        isBrutal -> colors.onSurface
        !appearance.frameColorEnabled -> primary.copy(alpha = 0.55f)
        appearance.frameColor == "theme" -> primary.copy(alpha = if (design == "material3" || isFlat) 0.48f else 0.78f)
        else -> col.copy(alpha = if (design == "material3" || isFlat) 0.52f else 0.80f)
    }

    return FrameTokens(
        cornerRadius = if (isBrutal) 4.dp else radius,
        buttonRadius = if (isBrutal) 4.dp else btnRadius,
        borderWidth = when {
            !appearance.frameEnabled -> 0.dp
            isBrutal -> 2.5.dp
            else -> width
        },
        borderColor = resolvedBorderColor,
        frameStyle = resolvedStyle,
        frameEnabled = appearance.frameEnabled,
        shadowsEnabled = appearance.shadows,
        elevation = when {
            !appearance.shadows || isFlat || isBrutal -> 0.dp
            design == "ui3d" || design == "skeuomorphism" -> 6.dp
            design == "bento" || design == "material3" -> 2.dp
            else -> 3.dp
        },
        isBrutal = isBrutal,
        isGlass = isGlass,
        isFlat = isFlat,
        isLuxury = isLuxury,
        barTop = barTop,
        barBottom = barBot,
        barButtonBg = barBtnBg,
        barContent = barContent,
        barAccent = barAccent,
        barDivider = if (!appearance.frameEnabled) Color.Transparent else resolvedBorderColor.copy(alpha = 0.82f),
        cardTop = cardTop,
        cardBottom = cardBot,
        darkTileTop = tileTop,
        darkTileBottom = tileBot,
        darkTileContent = tileFg,
        iconTileBg = iconBg,
        iconTileTint = iconTint,
        iconTileRadius = iconRadius
    )
}

val LocalAppSettings = staticCompositionLocalOf { AppSettings() }
val LocalAppStrings = staticCompositionLocalOf { Strings(isEn = false) }
val LocalFrameTokens = staticCompositionLocalOf { FrameTokens() }
val LocalSavedNames = staticCompositionLocalOf<List<String>> { emptyList() }
val LocalOnRemoveSavedName = staticCompositionLocalOf<((String) -> Unit)?> { null }

@Composable
fun SmartAdminTheme(
    settings: AppSettings = AppSettings(),
    content: @Composable () -> Unit
) {
    val colorScheme = remember(settings.primaryColorHex, settings.dark) {
        buildAppColorScheme(settings.primaryColorHex, settings.dark)
    }
    val typography = remember(settings.fontFamily, settings.fontWeight, settings.fontSize) {
        buildAppTypography(settings.fontFamily, settings.fontWeight, settings.fontSize)
    }
    val frameTokens = remember(settings.appearance, colorScheme, settings.dark) {
        resolveFrameTokens(settings.appearance, colorScheme, settings.dark)
    }
    val strings = remember(settings.lang) {
        Strings(isEn = settings.lang == "en")
    }
    val layoutDirection = if (settings.lang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl

    val view = LocalView.current
    val isLightStatusBar = frameTokens.barTop.luminance() > 0.5f
    if (!view.isInEditMode) {
        LaunchedEffect(view, isLightStatusBar) {
            var ctx: Context? = view.context
            while (ctx is ContextWrapper && ctx !is Activity) {
                ctx = ctx.baseContext
            }
            val window = (ctx as? Activity)?.window ?: return@LaunchedEffect
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = isLightStatusBar
        }
    }

    val shapes = remember(frameTokens.buttonRadius, frameTokens.cornerRadius) {
        Shapes(
            small = RoundedCornerShape(frameTokens.buttonRadius),
            medium = RoundedCornerShape(frameTokens.cornerRadius),
            large = RoundedCornerShape((frameTokens.cornerRadius.value + 4f).dp)
        )
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalAppSettings provides settings,
        LocalAppStrings provides strings,
        LocalFrameTokens provides frameTokens
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = shapes,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    SmartAdminTheme(
        settings = AppSettings(dark = darkTheme),
        content = content
    )
}
