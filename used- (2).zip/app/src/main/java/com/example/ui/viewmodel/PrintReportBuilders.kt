package com.example.ui.viewmodel

import com.example.data.PdfPrintManager
import com.example.data.PdfPrintManager.esc
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import kotlin.math.abs

/**
 * Generates PV2, Weekly Filter (.pdoc), Detail (.df-print), and Buyer (.by-print) HTML report bodies,
 * honoring Stamping/Signature rules, currency statement filters, phone visibility, and Credit/Debit styling.
 */
object PrintReportBuilders {

    private fun metaLine(settings: AppSettings, extra: String = ""): String {
        val ps = settings.printing
        val parts = mutableListOf<String>()
        if (ps.showPrintDate) parts.add("التاريخ: ${esc(DateHelper.displaySlash(DateHelper.todayIso()))}")
        if (ps.showPrintTime) parts.add("الوقت: ${esc(DateHelper.nowTime())}")
        if (extra.isNotBlank()) parts.add(extra)
        if (parts.isEmpty()) return ""
        return "<div class='pv-meta'>${parts.joinToString(" &nbsp;|&nbsp; ")}</div>"
    }

    private fun authSignBlock(): String =
        "<div class='pv-sign'><div>مدير الحسابات<br>الاسم: ........................<br>التوقيع: ........................</div><div>عن العميل<br>الاسم: ........................<br>التوقيع: ........................</div></div>"

    private fun tafqeetWords(amount: Double, unit: String): String {
        val rounded = kotlin.math.round(abs(amount)).toLong()
        val u = if (unit.isNotBlank()) " $unit" else ""
        return "${fmt(rounded.toDouble())}$u فقط لا غير"
    }

    fun buildSellerInvoiceHtml(inv: FolderInvoice, settings: AppSettings): String {
        val calc = SellerInvoiceCalculator.calculate(inv.formData)
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.invoices)
        val colCount = inv.formData.saleColCount.coerceIn(1, 3)

        val saleHeaderExtra = buildString {
            if (colCount >= 2) append("<th>ع2</th><th>م2</th>")
            if (colCount >= 3) append("<th>ع3</th><th>م3</th>")
        }
        val salesRowsHtml = inv.formData.salesRows.joinToString("") { r ->
            buildString {
                append("<tr>")
                append("<td>${esc(r.s1n)}</td><td>${esc(r.s1m)}</td>")
                if (colCount >= 2) append("<td>${esc(r.s2n)}</td><td>${esc(r.s2m)}</td>")
                if (colCount >= 3) append("<td>${esc(r.s3n)}</td><td>${esc(r.s3m)}</td>")
                append("<td>${esc(r.dn)}</td><td>${esc(r.dm)}</td><td>${esc(r.dname)}</td>")
                append("<td>${esc(r.onQty)}</td><td>${esc(r.om)}</td><td>${esc(r.oname)}</td>")
                append("</tr>")
            }
        }.ifBlank { "<tr><td colspan='${6 + colCount * 2}'>لا توجد صفوف</td></tr>" }

        val curHtml = if (inv.formData.currencyRows.isNotEmpty()) {
            val rows = inv.formData.currencyRows.joinToString("") { cr ->
                val a = num(cr.amount)
                val r = if (cr.cur.contains("يمني")) 1.0 else num(cr.rate).let { if (it > 0) it else 1.0 }
                "<tr><td>${esc(cr.cur)}</td><td>${fmt(a)}</td><td>${fmt(r)}</td><td>${fmt(a * r)}</td></tr>"
            }
            "<div class='pv-cur'>العملات</div><table class='pv-t'><thead><tr><th>العملة</th><th>المبلغ</th><th>السعر</th><th>القيمة</th></tr></thead><tbody>$rows<tr class='pv-sum'><td colspan='3'>الإجمالي</td><td>${fmt(calc.currencyTotal)}</td></tr></tbody></table>"
        } else ""

        val dateDisp = DateHelper.formatInvoiceDate(inv.initDateISO, settings.lang == "en")
        return """
            <div class='pv'>
              <div class='pv-title'>فاتورة بائع</div>
              <div class='pv-meta bold'>التاريخ: ${esc(dateDisp)}${if (inv.initNo.isNotBlank()) " &nbsp;|&nbsp; رقم: ${esc(inv.initNo)}" else ""}</div>
              <div class='pv-acc'>${esc(inv.initSeller.ifBlank { "بدون اسم" })}</div>
              <div class='sum'>
                <div>الكمية المسجلة: ${fmt(calc.enteredQty)}</div>
                <div>المتبقي كمية: ${fmt(calc.qtyBalance)}</div>
                <div class='grn'>صافي الكاش: ${fmt(calc.cashBalance)}</div>
              </div>
              <table class='pv-t'>
                <thead>
                  <tr>
                    <th>ع1</th><th>م1</th>$saleHeaderExtra
                    <th>دين ك</th><th>دين م</th><th>المشتري</th>
                    <th>خارج ك</th><th>خارج م</th><th>البيان</th>
                  </tr>
                </thead>
                <tbody>
                  $salesRowsHtml
                  <tr class='pv-sum'>
                    <td>${fmt(calc.sumS1n)}</td><td>${fmt(calc.sumS1m)}</td>
                    ${if (colCount >= 2) "<td>${fmt(calc.sumS2n)}</td><td>${fmt(calc.sumS2m)}</td>" else ""}
                    ${if (colCount >= 3) "<td>${fmt(calc.sumS3n)}</td><td>${fmt(calc.sumS3m)}</td>" else ""}
                    <td>${fmt(calc.sumDebtQty)}</td><td>${fmt(calc.sumDebtAmt)}</td><td>الدين</td>
                    <td>${fmt(calc.sumQatOutQty)}</td><td>${fmt(calc.sumQatOutAmt)}</td><td>الخارج</td>
                  </tr>
                </tbody>
              </table>
              <table class='pv-t' style='margin-top:8px'>
                <thead><tr><th>البيع نقد</th><th>الدين</th><th>الخوارج</th><th>المسلمة</th><th>السحب</th><th>الأسبوعي</th></tr></thead>
                <tbody><tr><td class='grn'>${fmt(calc.saleCash)}</td><td class='red'>${fmt(calc.sumDebtAmt)}</td><td>${fmt(calc.sumOut)}</td><td>${fmt(calc.sumReceived)}</td><td class='red'>${fmt(calc.sumWithdraw)}</td><td>${fmt(calc.sumWeekly)}</td></tr></tbody>
              </table>
              $curHtml
              ${if (inv.note.isNotBlank()) "<div class='pv-r'>ملاحظة: ${esc(inv.note)}</div>" else ""}
              <div class='pv-bal blu'>صافي الفاتورة: ${fmt(calc.cashBalance)}</div>
              $foot
            </div>
        """.trimIndent()
    }

    fun buildBuyerInvoiceHtml(inv: FolderInvoice, settings: AppSettings): String {
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.invoices)
        val rows = inv.buyerRows.joinToString("") { r ->
            "<tr><td>${esc(r.name)}</td><td>${esc(r.qty)}</td><td>${fmt(num(r.price), 2)}</td><td>${fmt(r.total, 2)}</td></tr>"
        }.ifBlank { "<tr><td colspan='4'>لا توجد صفوف</td></tr>" }
        val netCls = if (inv.buyerNet < 0) "red" else "blu"
        return """
            <div class='pv by-print'>
              <div class='pv-title'>فاتورة الشراء اليومية</div>
              <div class='pv-meta bold'>رقم الجدول: ${esc(inv.initNo.ifBlank { "-" })} &nbsp;|&nbsp; الاسم: ${esc(inv.initSeller)} &nbsp;|&nbsp; التاريخ: ${esc(DateHelper.displaySlash(inv.initDateISO))}</div>
              <table class='pv-t'>
                <thead><tr><th>اسم الشروة</th><th>العدد</th><th>مبلغ الشراء</th><th>الإجمالي</th></tr></thead>
                <tbody>
                  $rows
                  <tr class='pv-sum'><td colspan='3'>إجمالي الشراء</td><td>${fmt(inv.buyerTotal, 2)}</td></tr>
                  <tr class='pv-sum'><td colspan='3'>الخرج اليومي</td><td class='red'>${fmt(inv.buyerExpense, 2)}</td></tr>
                </tbody>
              </table>
              <div class='pv-bal $netCls'>الصافي: ${fmt(inv.buyerNet, 2)}</div>
              ${if (inv.note.isNotBlank()) "<div class='pv-r'>ملاحظة: ${esc(inv.note)}</div>" else ""}
              $foot
            </div>
        """.trimIndent()
    }

    fun buildWeeklyFilterHtml(filter: WeeklyFilter, settings: AppSettings): String {
        val calc = WeeklyFilterCalculator.calculate(filter)
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.statement)
        val qtyHtml = filter.qtyRows.mapIndexed { idx, r ->
            val rem = calc.rowQtyRemaining.getOrElse(idx) { 0.0 }
            val cleanDay = r.day.replace(Regex("""\s*[\u0660-\u06690-9]+\s*-\s*[\u0660-\u06690-9]+\s*$"""), "").trim()
            "<tr><td class='day-col'><b>${esc(cleanDay)}</b><br><small>${esc(DateHelper.displaySlash(r.date))}</small></td><td>${esc(r.qty)}</td><td>${esc(r.cash)}</td><td>${esc(r.debt)}</td><td>${esc(r.expense)}</td><td><b>${fmt(rem)}</b></td></tr>"
        }.joinToString("")

        val saleHtml = filter.salesRows.mapIndexed { idx, r ->
            val tot = calc.rowSalesTotals.getOrElse(idx) { 0.0 }
            val cleanDay = r.day.replace(Regex("""\s*[\u0660-\u06690-9]+\s*-\s*[\u0660-\u06690-9]+\s*$"""), "").trim()
            val wNote = if (r.weeklyNote.isNotBlank()) "<div style='font-size:9px;color:#7B6B6B'>${esc(r.weeklyNote)}</div>" else ""
            val wsNote = if (r.weeklySalesNote.isNotBlank()) "<div style='font-size:9px;color:#7B6B6B'>${esc(r.weeklySalesNote)}</div>" else ""
            val pNote = if (r.prevNote.isNotBlank()) "<div style='font-size:9px;color:#7B6B6B'>${esc(r.prevNote)}</div>" else ""
            "<tr><td class='day-col'><b>${esc(cleanDay)}</b><br><small>${esc(DateHelper.displaySlash(r.date))}</small></td><td>${esc(r.cash)}</td><td>${esc(r.weeklyAmt)}$wNote</td><td>${esc(r.weeklySalesAmt)}$wsNote</td><td>${esc(r.prevAmt)}$pNote</td><td><b>${fmt(tot)}</b></td></tr>"
        }.joinToString("")

        val moneyHtml = filter.moneyRows.mapIndexed { idx, r ->
            val tot = calc.rowMoneyTotals.getOrElse(idx) { 0.0 }
            val cleanDay = r.day.replace(Regex("""\s*[\u0660-\u06690-9]+\s*-\s*[\u0660-\u06690-9]+\s*$"""), "").trim()
            "<tr><td class='day-col'><b>${esc(cleanDay)}</b><br><small>${esc(DateHelper.displaySlash(r.date))}</small></td><td>${esc(r.yemeni)}</td><td>${esc(r.saudiAmt)}</td><td>${esc(r.saudiExch)}</td><td>${esc(r.omaniAmt)}</td><td>${esc(r.omaniExch)}</td><td>${esc(r.dirhamAmt)}</td><td>${esc(r.dirhamExch)}</td><td><b>${fmt(tot)}</b></td></tr>"
        }.joinToString("")

        val diffCls = when {
            abs(calc.diff) < 1e-6 -> "highlight-green"
            calc.diff > 0 -> "highlight-blue"
            else -> "highlight-red"
        }

        return """
            <div class='pdoc'>
              <div class='doc-head'>
                <div class='nf-doc-title'>الفلتر الأسبوعي</div>
                <div class='doc-sub'>${esc(filter.name)}</div>
              </div>
              <div class='header-info'>
                <div class='item'><b>الاسم</b><span>${esc(filter.name.ifBlank { "-" })}</span></div>
                <div class='item'><b>من تاريخ</b><span>${esc(DateHelper.displaySlash(filter.fromDate).ifBlank { "-" })}</span></div>
                <div class='item'><b>إلى تاريخ</b><span>${esc(DateHelper.displaySlash(filter.toDate).ifBlank { "-" })}</span></div>
              </div>
              <div class='sec'>عمود الكميه</div>
              <div class='tw'>
                <table class='data-table'>
                  <thead><tr><th>اليوم</th><th>الكميه</th><th>نقد</th><th>دين</th><th>خرج</th><th>الباقي</th></tr></thead>
                  <tbody>
                    $qtyHtml
                    <tr class='total-row'><td>الجملة</td><td>${fmt(calc.totQty)}</td><td>${fmt(calc.totCashQty)}</td><td>${fmt(calc.totDebtQty)}</td><td>${fmt(calc.totExpQty)}</td><td>${fmt(calc.totQtyRemaining)}</td></tr>
                  </tbody>
                </table>
              </div>
              <div class='sec'>عمود البيع</div>
              <div class='tw'>
                <table class='data-table'>
                  <thead><tr><th>اليوم</th><th>نقد الباقي</th><th>مسلم فلوس</th><th>مسلم أسبوع</th><th>السحب فلوس</th><th>= جملة يومية</th></tr></thead>
                  <tbody>
                    $saleHtml
                    <tr class='total-row'><td>الجملة</td><td>${fmt(calc.totSalesCash)}</td><td>${fmt(calc.totSalesWeekly)}</td><td>${fmt(calc.totSalesWeeklySales)}</td><td>${fmt(calc.totSalesPrev)}</td><td>${fmt(calc.totSalesAll)}</td></tr>
                  </tbody>
                </table>
              </div>
              <div class='sec'>العملات</div>
              <div class='tw'>
                <table class='data-table'>
                  <thead>
                    <tr><th rowspan='2'></th><th rowspan='2'>يمني<br><small>صرفها</small></th><th colspan='2'>سعودي</th><th colspan='2'>عماني</th><th colspan='2'>درهم</th><th rowspan='2'>جملة يومية</th></tr>
                    <tr><th>المبلغ</th><th>صرفها</th><th>المبلغ</th><th>صرفها</th><th>المبلغ</th><th>صرفها</th></tr>
                  </thead>
                  <tbody>
                    $moneyHtml
                    <tr class='total-row'><td>الجملة</td><td>${fmt(calc.totYemeni)}</td><td>${fmt(calc.totSaudiAmt)}</td><td>${fmt(calc.totSaudiExch)}</td><td>${fmt(calc.totOmaniAmt)}</td><td>${fmt(calc.totOmaniExch)}</td><td>${fmt(calc.totDirhamAmt)}</td><td>${fmt(calc.totDirhamExch)}</td><td>${fmt(calc.totMoneyAll)}</td></tr>
                  </tbody>
                </table>
              </div>
              <div class='sec'>التجميل النهائي</div>
              <div class='calc-box'>
                <div class='calc-row'><span class='lbl'>إجمالي نقد الباقي</span><div class='val-box'>${fmt(calc.totSalesCash)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي مسلم فلوس</span><div class='val-box'>${fmt(calc.totSalesWeekly)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي مسلم أسبوع</span><div class='val-box'>${fmt(calc.totSalesWeeklySales)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي السحب فلوس</span><div class='val-box'>${fmt(calc.totSalesPrev)}</div></div>
                <div class='calc-row total'><span class='lbl'>إجمالي جملة جدول فلوس البيع والمسلم</span><div class='val-box highlight-blue'>${fmt(calc.totSalesAll)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي العملة اليمنية</span><div class='val-box'>${fmt(calc.totYemeni)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي صرف السعودي</span><div class='val-box'>${fmt(calc.totSaudiExch)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي صرف العماني</span><div class='val-box'>${fmt(calc.totOmaniExch)}</div></div>
                <div class='calc-row'><span class='lbl'>إجمالي صرف الدرهم</span><div class='val-box'>${fmt(calc.totDirhamExch)}</div></div>
                <div class='calc-row total'><span class='lbl'>إجمالي جدول العملات</span><div class='val-box highlight-green'>${fmt(calc.totMoneyAll)}</div></div>
                <div class='calc-row total'><span class='lbl'>الفارق (يجب أن يكون صفر)</span><div class='val-box $diffCls'>${if (abs(calc.diff) < 1e-6) "0" else fmt(abs(calc.diff))}</div></div>
              </div>
              $foot
            </div>
        """.trimIndent()
    }

    fun buildDetailHtml(detail: DetailRecord, settings: AppSettings): String {
        val fd = DetailCalculator.recalculate(detail.formData)
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.statement)
        val debtRows = fd.debtRows.joinToString("") {
            "<tr><td>${esc(it.name)}</td><td>${esc(it.qty)}</td><td>${esc(it.amount)}</td><td>${esc(it.weekly)}</td><td class='red'>${fmt(it.rest)}</td></tr>"
        }.ifBlank { "<tr><td colspan='5'>لا توجد ديون</td></tr>" }
        val recRows = fd.receivedRows.joinToString("") {
            "<tr><td>${esc(it.name)}</td><td class='grn'>${esc(it.amount)}</td></tr>"
        }.ifBlank { "<tr><td colspan='2'>لا توجد مسلمات</td></tr>" }
        val moneyRows = fd.moneyRows.joinToString("") {
            "<tr><td>${esc(it.label)}</td><td>${esc(it.amount)}</td><td>${esc(it.value)}</td></tr>"
        }
        val diffCls = if (abs(fd.calcChkDiff) < 1e-6) "grn" else "red"
        return """
            <div class='pv df-print'>
              <div class='pv-title'>التفصيل الأسبوعي</div>
              <div class='pv-meta bold'>${esc(detail.initDetail)} &nbsp;|&nbsp; من: ${esc(DateHelper.displaySlash(detail.initDateFrom))} إلى: ${esc(DateHelper.displaySlash(detail.initDateTo))}</div>
              <div class='sum'>
                <div>متبقي الكمية: ${fmt(fd.calcQRest)}</div>
                <div>جملة البيع: ${fmt(fd.calcSGrand)}</div>
                <div>الميزانية: ${fmt(fd.calcMidTotal)}</div>
                <div>النقود: ${fmt(fd.calcMTotal)}</div>
                <div class='$diffCls'>الفارق: ${fmt(fd.calcChkDiff)}</div>
              </div>
              <div class='pv-cur'>الديون</div>
              <table class='pv-t'><thead><tr><th>الاسم</th><th>الكمية</th><th>المبلغ</th><th>الأسبوعي</th><th>المتبقي</th></tr></thead><tbody>$debtRows<tr class='pv-sum'><td colspan='4'>صافي الديون</td><td class='red'>${fmt(fd.calcSDebtSale)}</td></tr></tbody></table>
              <div class='pv-cur'>المسلمات</div>
              <table class='pv-t'><thead><tr><th>الاسم</th><th>المبلغ</th></tr></thead><tbody>$recRows<tr class='pv-sum'><td>إجمالي المسلمات</td><td class='grn'>${fmt(fd.calcPrevTotal)}</td></tr></tbody></table>
              <div class='pv-cur'>العملات (${esc(fd.wLabel)}: ${esc(fd.wValue)})</div>
              <table class='pv-t'><thead><tr><th>العملة</th><th>المبلغ</th><th>المعادل</th></tr></thead><tbody>$moneyRows<tr class='pv-sum'><td colspan='2'>إجمالي النقود</td><td class='grn'>${fmt(fd.calcMTotal)}</td></tr></tbody></table>
              <div class='pv-bal $diffCls'>الفارق النهائي: ${fmt(fd.calcChkDiff)}</div>
              ${if (fd.note.isNotBlank()) "<div class='pv-r'>ملاحظة: ${esc(fd.note)}</div>" else ""}
              $foot
            </div>
        """.trimIndent()
    }

    fun buildClockLedgerHtml(
        section: ClockSection,
        entries: List<ClockEntry>,
        from: String,
        to: String,
        auth: Boolean,
        settings: AppSettings
    ): String {
        if (section == ClockSection.CURRENCY && !auth) {
            return buildClockCurrencyStatementHtml(entries, from, to, settings)
        }
        val stampMode = if (auth) settings.printing.stampSettings.balance else settings.printing.stampSettings.statement
        val foot = PdfPrintManager.buildFootHtml(settings, stampMode)
        val sorted = entries.sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp })
        val balances = ClockCalculator.runningBalances(sorted)
        var credit = 0.0
        var debit = 0.0
        val rows = sorted.joinToString("") { e ->
            val isCred = e.dir != "عليكم"
            if (isCred) credit += e.amount else debit += e.amount
            val curSummary = if (section == ClockSection.CURRENCY && e.rows.isNotEmpty()) {
                "<div style='font-size:10px;color:#475569;'>" +
                    e.rows.joinToString(" | ") { r -> "${esc(r.cur)}: ${fmt(r.a)} × ${fmt(r.r)} = ${fmt(r.a * r.r)}" } +
                    "</div>"
            } else ""
            val run = balances[e.id] ?: 0.0
            val runLbl = "${fmt(abs(run))} ${if (run < 0) "عليكم" else if (run > 0) "لكم" else ""}"
            "<tr><td>${esc(DateHelper.displaySlash(e.date))}</td><td>${esc(e.name.ifBlank { e.note })}$curSummary</td><td class='red'>${if (!isCred) fmt(e.amount) else ""}</td><td class='grn'>${if (isCred) fmt(e.amount) else ""}</td><td class='blu'>$runLbl</td></tr>"
        }.ifBlank { "<tr><td colspan='5'>لا توجد حركات خلال الفترة المحددة</td></tr>" }

        val net = credit - debit
        val ab = abs(net)
        val side = if (net < -1e-9) "عليكم" else if (net > 1e-9) "لكم" else "متوازن"
        val cls = if (net < -1e-9) "red" else if (net > 1e-9) "grn" else "blu"
        val title = if (auth) "مصادقة رصيد — ${section.labelAr}" else "كشف ${section.labelAr}"
        val periodStr = "الفترة: من ${esc(DateHelper.displaySlash(from))} إلى ${esc(DateHelper.displaySlash(to))}"

        return if (auth) {
            """
                <div class='pv'>
                  <div class='pv-title'>$title</div>
                  <div class='pv-meta bold'>$periodStr</div>
                  ${metaLine(settings)}
                  <div class='pv-who'><span>الأخ / ${esc(section.labelAr)}</span><span>المحترم</span></div>
                  <div class='pv-c'>تحية طيبة وبعد</div>
                  <div class='pv-c'>نرجو منكم مطابقة ومصادقة الرصيد أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع</div>
                  <div class='pv-c'>وأرصدتكم لدينا كالتالي</div>
                  <table class='pv-t'><thead><tr><th>عليكم</th><th>لكم</th><th style='width:25%'></th><th>الرصيد</th><th>العملة</th></tr></thead>
                  <tbody><tr><td class='red'>${fmt(debit)}</td><td class='grn'>${fmt(credit)}</td><td></td><td class='blu'>${fmt(ab)}</td><td>${esc(settings.defaultCurrency)}</td></tr></tbody></table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)}</div>
                  <div class='pv-c'>الرجاء مصادقة الرصيد وموافاتنا بالرد</div>
                  <div class='pv-c'>علماً أنه لا يوجد لدينا أي أرصدة أخرى خلال الفترة المحددة</div>
                  <div class='pv-r'>تاريخ المصادقة: ${esc(DateHelper.displaySlash(DateHelper.todayIso()))}</div>
                  ${authSignBlock()}
                  $foot
                </div>
            """.trimIndent()
        } else {
            """
                <div class='pv'>
                  <div class='pv-title'>$title</div>
                  <div class='pv-meta bold'>$periodStr</div>
                  ${metaLine(settings)}
                  <table class='pv-t'>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>عليه</th><th>له</th><th>الرصيد</th></tr></thead>
                    <tbody>
                      $rows
                      <tr class='pv-sum'><td colspan='2'>الإجمالي</td><td class='red'>${fmt(debit)}</td><td class='grn'>${fmt(credit)}</td><td class='blu'>${fmt(ab)}</td></tr>
                      <tr class='pv-sum'><td colspan='2'>الباقي</td><td class='red'>${fmt(maxOf(debit - credit, 0.0))}</td><td class='grn'>${fmt(maxOf(credit - debit, 0.0))}</td><td class='blu'>${fmt(ab)}</td></tr>
                    </tbody>
                  </table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)}</div>
                  $foot
                </div>
            """.trimIndent()
        }
    }

    private fun buildClockCurrencyStatementHtml(
        entries: List<ClockEntry>,
        from: String,
        to: String,
        settings: AppSettings
    ): String {
        val ps = settings.printing
        val foot = PdfPrintManager.buildFootHtml(settings, ps.stampSettings.statement)
        val hideHdrStyle = if (!ps.currencyStmtHeader) "<style>.company-header,.print-profile-header,.full-image-header{display:none!important}</style>" else ""

        val selectedCurs = ps.currencyStmtList
        val curCatalog = settings.currencies
        val targetCurrencies: List<AppCurrency> = if (selectedCurs == null) {
            curCatalog
        } else {
            curCatalog.filter { c -> selectedCurs.any { it.equals(c.name, true) || it.equals(c.symbol, true) } }
        }

        val sorted = entries.sortedWith(compareBy<ClockEntry> { it.date }.thenBy { it.sentStamp })
        val sectionsHtml = StringBuilder()

        data class SecSum(val name: String, val sym: String, val totalL: Double, val totalO: Double, val amtL: Double, val amtO: Double, val net: Double)
        val summaries = mutableListOf<SecSum>()

        targetCurrencies.forEach { cur ->
            var amtL = 0.0
            var amtO = 0.0
            var totalL = 0.0
            var totalO = 0.0
            var runBal = 0.0
            val rowsHtml = StringBuilder()

            sorted.forEach { e ->
                val matching = if (e.rows.isNotEmpty()) {
                    e.rows.filter { r ->
                        r.cur.contains(cur.name, true) || r.cur.contains(cur.symbol, true) ||
                            cur.name.contains(r.cur, true)
                    }
                } else if (e.cur.contains(cur.name, true) || e.cur.contains(cur.symbol, true) || cur.name.contains(e.cur, true)) {
                    listOf(TsRowCurrency(cur = e.cur, a = if (e.curAmount > 0) e.curAmount else e.amount, r = if (e.curRate > 0) e.curRate else 1.0))
                } else emptyList()

                matching.forEach { r ->
                    val lk = e.dir != "عليكم"
                    val v = r.a * r.r
                    if (lk) {
                        amtL += r.a; totalL += v; runBal += r.a
                    } else {
                        amtO += r.a; totalO += v; runBal -= r.a
                    }
                    val tLabel = when (e.tsKind) {
                        "acc" -> "سند"
                        "fund" -> "صندوق"
                        else -> if (e.auto) "تفصيل" else "قيد"
                    }
                    val stmt = listOf(e.name, e.note).filter { it.isNotBlank() }.distinct().joinToString(" — ")
                    rowsHtml.append(
                        "<tr><td>${esc(DateHelper.displaySlash(e.date))}</td><td>$tLabel</td>" +
                            "<td class='grn'>${if (lk) fmt(r.a) else ""}</td><td class='red'>${if (!lk) fmt(r.a) else ""}</td>" +
                            "<td>${fmt(r.r)}</td>" +
                            "<td class='grn'>${if (lk) fmt(v) else ""}</td><td class='red'>${if (!lk) fmt(v) else ""}</td>" +
                            "<td class='blu'>${fmt(abs(runBal))} ${if (runBal < 0) "عليكم" else if (runBal > 0) "لكم" else ""}</td>" +
                            "<td class='cs-stmt'>${esc(stmt)}</td></tr>"
                    )
                }
            }

            if (amtL > 0 || amtO > 0) {
                summaries.add(SecSum(cur.name, cur.symbol, totalL, totalO, amtL, amtO, runBal))
                val vn = totalL - totalO
                val sideCol = if (runBal < 0 || vn < 0) "red" else if (runBal > 0 || vn > 0) "grn" else "blu"
                val sideTxt = if (runBal < 0) "الباقي عليكم" else if (runBal > 0) "الباقي لكم" else "متوازن"
                sectionsHtml.append(
                    """
                    <div class='pv-cur'>العملة: ${esc(cur.name)}${if (cur.symbol.isNotBlank()) " (${esc(cur.symbol)})" else ""}</div>
                    <table class='pv-t cs-t'>
                      <thead>
                        <tr><th rowspan='2'>التاريخ</th><th rowspan='2'>نوع السند</th><th colspan='2'>مبلغ العملة</th><th rowspan='2'>سعر الصرف</th><th colspan='2'>القيمة بعد الصرف</th><th rowspan='2'>الرصيد</th><th rowspan='2'>البيان</th></tr>
                        <tr><th>لكم</th><th>عليكم</th><th>لكم</th><th>عليكم</th></tr>
                      </thead>
                      <tbody>
                        $rowsHtml
                        <tr class='pv-sum'><td>الإجمالي</td><td></td><td class='grn'>${fmt(amtL)}</td><td class='red'>${fmt(amtO)}</td><td></td><td class='grn'>${fmt(totalL)}</td><td class='red'>${fmt(totalO)}</td><td class='blu'>${fmt(abs(runBal))} ${if (runBal < 0) "عليكم" else "لكم"}</td><td></td></tr>
                      </tbody>
                    </table>
                    <div class='pv-bal $sideCol'>${esc(cur.name)} $sideTxt: ${fmt(abs(runBal))} ${esc(cur.symbol)} [الرصيد ${fmt(abs(vn))} ${if (vn < 0) "عليكم" else "لكم"}]</div>
                    """.trimIndent()
                )
            }
        }

        val summaryHtml = if (ps.currencyStmtSummary && summaries.isNotEmpty()) {
            val tv = summaries.sumOf { it.totalL - it.totalO }
            val sumRows = summaries.joinToString("") { s ->
                "<tr><td>${esc(s.name)}</td><td class='grn'>${fmt(s.totalL)}</td><td class='red'>${fmt(s.totalO)}</td><td class='grn'>${fmt(s.amtL)}</td><td class='red'>${fmt(s.amtO)}</td><td class='blu'>${fmt(abs(s.net))} ${if (s.net < 0) "عليكم" else "لكم"}</td></tr>"
            }
            val netLine = summaries.joinToString(" &nbsp;|&nbsp; ") { s ->
                "${esc(s.name)} ${fmt(abs(s.net))} ${if (s.net < 0) "عليكم" else if (s.net > 0) "لكم" else "متوازن"}"
            }
            """
                <div class='pv-cur'>تجميع القبض من العملات + إرسال الحوالات</div>
                <table class='pv-t cs-t'>
                  <thead><tr><th>العملة</th><th>لكم (بعد الصرف)</th><th>عليكم (بعد الصرف)</th><th>مبلغ العملة لكم</th><th>مبلغ العملة عليكم</th><th>الرصيد بالعملة</th></tr></thead>
                  <tbody>
                    $sumRows
                    <tr class='pv-sum'><td colspan='6' style='text-align:right'>إجمالي كامل رصيد العملات: $netLine &nbsp; [الرصيد ${fmt(abs(tv))} ${if (tv < 0) "عليكم" else "لكم"}]</td></tr>
                  </tbody>
                </table>
            """.trimIndent()
        } else ""

        return """
            $hideHdrStyle
            <div class='pv'>
              <div class='pv-title'>كشف العملات</div>
              <div class='pv-meta bold'>الفترة: من ${esc(DateHelper.displaySlash(from))} إلى ${esc(DateHelper.displaySlash(to))}</div>
              ${metaLine(settings)}
              ${sectionsHtml.toString().ifBlank { "<div class='pv-c'>لا توجد حركات عملات ضمن الفترة أو الفلترة المحددة</div>" }}
              $summaryHtml
              $foot
            </div>
        """.trimIndent()
    }

    fun buildAutoDebtFifoHtml(rows: List<FifoOpenDebtRow>, auth: Boolean, settings: AppSettings): String {
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.statement)
        val body = rows.joinToString("") { r ->
            "<tr><td>${esc(DateHelper.displaySlash(r.date))}</td><td>${esc(r.detailTitle)}</td><td>${esc(r.customerName)}</td><td>${fmt(r.qty)}</td><td>${fmt(r.grossAmount)}</td><td class='red'>${fmt(r.remainingDebt)}</td><td class='blu'>${fmt(r.runningTotal)}</td></tr>"
        }.ifBlank { "<tr><td colspan='7'>لا توجد ديون مفتوحة</td></tr>" }
        val total = rows.lastOrNull()?.runningTotal ?: 0.0
        return """
            <div class='pv'>
              <div class='pv-title'>${if (auth) "مصادقة " else ""}صندوق الديون التلقائي (FIFO)</div>
              ${metaLine(settings)}
              <table class='pv-t'>
                <thead><tr><th>التاريخ</th><th>التفصيل</th><th>العميل</th><th>الكمية</th><th>أصل الدين</th><th>المتبقي</th><th>التراكمي</th></tr></thead>
                <tbody>$body<tr class='pv-sum'><td colspan='5'>الإجمالي</td><td colspan='2' class='red'>${fmt(total)}</td></tr></tbody>
              </table>
              <div class='pv-bal red'>إجمالي الديون المفتوحة: ${fmt(total)}</div>
              $foot
            </div>
        """.trimIndent()
    }

    fun buildPrivateStatementHtml(
        account: PrivateAccount,
        txs: List<PrivateTx>,
        priorBal: Double,
        currencyFilter: String,
        auth: Boolean,
        settings: AppSettings
    ): String {
        val stampMode = if (auth) settings.printing.stampSettings.balance else settings.printing.stampSettings.statement
        val foot = PdfPrintManager.buildFootHtml(settings, stampMode)
        val sorted = txs.sortedWith(compareBy<PrivateTx> { it.date }.thenBy { it.createdAt })
        var run = priorBal // positive => عليه (debt)
        var totDebt = 0.0
        var totPay = 0.0
        val rows = buildString {
            if (abs(priorBal) > 1e-6) {
                append("<tr><td>-</td><td>رصيد سابق</td><td class='${if (priorBal >= 0) "red" else ""}'>${if (priorBal >= 0) fmt(abs(priorBal)) else ""}</td><td class='${if (priorBal < 0) "grn" else ""}'>${if (priorBal < 0) fmt(abs(priorBal)) else ""}</td><td class='blu'>${fmt(abs(run))} ${if (run >= 0) "عليكم" else "لكم"}</td></tr>")
            }
            sorted.forEach { t ->
                val isDebt = t.type == "عليه"
                if (isDebt) { totDebt += t.amount; run += t.amount } else { totPay += t.amount; run -= t.amount }
                val detail = t.lines.joinToString(" | ").ifBlank { t.type }
                append("<tr><td>${esc(DateHelper.displaySlash(t.date))}</td><td>${esc(detail)}</td><td class='red'>${if (isDebt) fmt(t.amount) else ""}</td><td class='grn'>${if (!isDebt) fmt(t.amount) else ""}</td><td class='blu'>${fmt(abs(run))} ${if (run >= 0) "عليكم" else "لكم"}</td></tr>")
            }
        }.ifBlank { "<tr><td colspan='5'>لا توجد حركات خلال الفترة المحددة</td></tr>" }

        val ab = abs(run)
        val side = if (run > 1e-6) "عليكم" else if (run < -1e-6) "لكم" else "متوازن"
        val cls = if (run > 1e-6) "red" else if (run < -1e-6) "grn" else "blu"
        val phoneMeta = if (settings.printing.showPhone && account.phone.isNotBlank()) "هاتف: ${esc(account.phone)}" else ""

        return if (auth) {
            """
                <div class='pv'>
                  <div class='pv-title'>مصادقة رصيد</div>
                  ${metaLine(settings, phoneMeta)}
                  <div class='pv-who'><span>الأخ / ${esc(account.name)}</span><span>المحترم</span></div>
                  <div class='pv-c'>تحية طيبة وبعد</div>
                  <div class='pv-c'>نرجو منكم مطابقة ومصادقة الرصيد أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع</div>
                  <div class='pv-c'>وأرصدتكم لدينا كالتالي</div>
                  <table class='pv-t'><thead><tr><th>عليكم</th><th>لكم</th><th style='width:25%'></th><th>الرصيد</th><th>العملة</th></tr></thead>
                  <tbody><tr><td class='red'>${fmt(totDebt)}</td><td class='grn'>${fmt(totPay)}</td><td></td><td class='blu'>${fmt(ab)}</td><td>${esc(currencyFilter)}</td></tr></tbody></table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)} (${esc(currencyFilter)})</div>
                  <div class='pv-c'>الرجاء مصادقة الرصيد وموافاتنا بالرد</div>
                  <div class='pv-c'>علماً أنه لا يوجد لدينا أي أرصدة أخرى خلال الفترة المحددة</div>
                  <div class='pv-r'>تاريخ المصادقة: ${esc(DateHelper.displaySlash(DateHelper.todayIso()))}</div>
                  ${authSignBlock()}
                  $foot
                </div>
            """.trimIndent()
        } else {
            """
                <div class='pv'>
                  <div class='pv-title'>كشف حساب</div>
                  ${metaLine(settings, "العملة: ${esc(currencyFilter)}" + if (phoneMeta.isNotBlank()) " &nbsp;|&nbsp; $phoneMeta" else "")}
                  <div class='pv-acc'>${esc(account.name)}</div>
                  <table class='pv-t'>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>عليه</th><th>له</th><th>الرصيد</th></tr></thead>
                    <tbody>
                      $rows
                      <tr class='pv-sum'><td colspan='2'>الإجمالي</td><td class='red'>${fmt(totDebt)}</td><td class='grn'>${fmt(totPay)}</td><td class='blu'>${fmt(ab)}</td></tr>
                      <tr class='pv-sum'><td colspan='2'>الباقي</td><td class='red'>${fmt(maxOf(totDebt - totPay, 0.0))}</td><td class='grn'>${fmt(maxOf(totPay - totDebt, 0.0))}</td><td class='blu'>${fmt(ab)}</td></tr>
                    </tbody>
                  </table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)} (${esc(currencyFilter)})</div>
                  $foot
                </div>
            """.trimIndent()
        }
    }

    fun buildPrivateSingleVoucherHtml(
        account: PrivateAccount,
        tx: PrivateTx,
        allAccountTxs: List<PrivateTx>,
        settings: AppSettings
    ): String {
        val stamp = PdfPrintManager.buildStampHtml(settings, settings.printing.stampSettings.vouchers)
        val sorted = allAccountTxs
            .filter { it.currency == tx.currency }
            .sortedWith(compareBy<PrivateTx> { it.date }.thenBy { it.createdAt })
        var run = 0.0
        for (item in sorted) {
            run += if (item.type == "عليه") item.amount else -item.amount
            if (item.id == tx.id) break
        }
        val balSide = if (run > 1e-6) "عليه" else if (run < -1e-6) "له" else "متعادل"
        val sym = settings.currencies.firstOrNull { it.name == tx.currency }?.symbol ?: tx.currency
        val noteHtml = tx.lines.joinToString("<br>") { esc(it) }.ifBlank { "—" }
        val imgHtml = if (tx.img.isNotBlank()) {
            val file = java.io.File(tx.img)
            val src = if (file.exists()) "file://${file.absolutePath}" else tx.img
            "<div style='margin-top:8px;text-align:center'><img src='${esc(src)}' style='max-width:100%;max-height:260px;border-radius:8px;border:1px solid #cbd5e1'/></div>"
        } else ""
        return """
            <div class='pv'>
              <div class='pv-title'>سند قيد (${esc(tx.type)})</div>
              <div class='tx-who'><span>الأخ:</span><span class='nm'>${esc(account.name)}</span><span>المحترم</span></div>
              ${if (settings.printing.showPhone && account.phone.isNotBlank()) "<div class='pv-meta'>الهاتف: ${esc(account.phone)}</div>" else ""}
              <div class='tx'>
                <div>التاريخ: ${esc(DateHelper.displaySlash(tx.date))}${if (tx.time.isNotBlank()) " ${esc(tx.time)}" else ""}</div>
                <div>النوع: ${esc(tx.type)} &nbsp;|&nbsp; المبلغ: ${fmt(tx.amount)} ${esc(sym)}</div>
                <div>البيان: $noteHtml</div>
                <div>الرصيد بعد المعاملة: $balSide ${fmt(abs(run))} ${esc(sym)}</div>
              </div>
              $imgHtml
              <div class='vc-stamp'>$stamp</div>
            </div>
        """.trimIndent()
    }

    fun buildDebtStatementHtml(
        account: DebtAccount,
        vouchers: List<DebtVoucher>,
        auth: Boolean,
        settings: AppSettings
    ): String {
        val stampMode = if (auth) settings.printing.stampSettings.balance else settings.printing.stampSettings.statement
        val foot = PdfPrintManager.buildFootHtml(settings, stampMode)
        val sorted = vouchers.sortedWith(compareBy<DebtVoucher> { it.date }.thenBy { it.createdAt })
        var run = 0.0
        var debt = 0.0
        var pay = 0.0
        val rows = sorted.joinToString("") { v ->
            val isDebt = v.type == "debt"
            if (isDebt) { debt += v.amount; run += v.amount } else { pay += v.amount; run -= v.amount }
            val noteHtml = esc(v.note).replace("\n", "<br>")
            "<tr><td>${esc(DateHelper.displaySlash(v.date))}</td><td>$noteHtml</td><td class='red'>${if (isDebt) fmt(v.amount) else ""}</td><td class='grn'>${if (!isDebt) fmt(v.amount) else ""}</td><td class='blu'>${fmt(abs(run))} ${if (run > 1e-9) "عليكم" else if (run < -1e-9) "لكم" else ""}</td></tr>"
        }.ifBlank { "<tr><td colspan='5'>لا توجد حركات خلال الفترة المحددة</td></tr>" }

        val ab = abs(run)
        val side = if (run > 1e-9) "عليكم" else if (run < -1e-9) "لكم" else "متوازن"
        val cls = if (run > 1e-9) "red" else if (run < -1e-9) "grn" else "blu"
        val phoneMeta = if (settings.printing.showPhone && account.phone.isNotBlank()) "هاتف: ${esc(account.phone)}" else ""

        return if (auth) {
            """
                <div class='pv'>
                  <div class='pv-title'>مصادقة رصيد</div>
                  ${metaLine(settings, phoneMeta)}
                  <div class='pv-who'><span>الأخ / ${esc(account.name)}</span><span>المحترم</span></div>
                  <div class='pv-c'>تحية طيبة وبعد</div>
                  <div class='pv-c'>نرجو منكم مطابقة ومصادقة الرصيد أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع</div>
                  <div class='pv-c'>وأرصدتكم لدينا كالتالي</div>
                  <table class='pv-t'><thead><tr><th>عليكم</th><th>لكم</th><th style='width:25%'></th><th>الرصيد</th><th>العملة</th></tr></thead>
                  <tbody><tr><td class='red'>${fmt(debt)}</td><td class='grn'>${fmt(pay)}</td><td></td><td class='blu'>${fmt(ab)}</td><td>${esc(settings.defaultCurrency)}</td></tr></tbody></table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)}</div>
                  <div class='pv-c'>الرجاء مصادقة الرصيد وموافاتنا بالرد</div>
                  <div class='pv-c'>علماً أنه لا يوجد لدينا أي أرصدة أخرى خلال الفترة المحددة</div>
                  <div class='pv-r'>تاريخ المصادقة: ${esc(DateHelper.displaySlash(DateHelper.todayIso()))}</div>
                  ${authSignBlock()}
                  $foot
                </div>
            """.trimIndent()
        } else {
            """
                <div class='pv'>
                  <div class='pv-title'>كشف حساب</div>
                  ${metaLine(settings, phoneMeta)}
                  <div class='pv-acc'>${esc(account.name)}</div>
                  <table class='pv-t'>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>عليه</th><th>له</th><th>الرصيد</th></tr></thead>
                    <tbody>
                      $rows
                      <tr class='pv-sum'><td colspan='2'>الإجمالي</td><td class='red'>${fmt(debt)}</td><td class='grn'>${fmt(pay)}</td><td class='blu'>${fmt(ab)}</td></tr>
                      <tr class='pv-sum'><td colspan='2'>الباقي</td><td class='red'>${fmt(maxOf(debt - pay, 0.0))}</td><td class='grn'>${fmt(maxOf(pay - debt, 0.0))}</td><td class='blu'>${fmt(ab)}</td></tr>
                    </tbody>
                  </table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)}</div>
                  $foot
                </div>
            """.trimIndent()
        }
    }

    fun buildDebtCashboxHtml(
        cashboxName: String,
        accounts: List<DebtAccount>,
        vouchers: List<DebtVoucher>,
        from: String,
        to: String,
        auth: Boolean,
        settings: AppSettings
    ): String {
        val stampMode = if (auth) settings.printing.stampSettings.balance else settings.printing.stampSettings.statement
        val foot = PdfPrintManager.buildFootHtml(settings, stampMode)
        var totPay = 0.0
        var totDebt = 0.0
        val rows = accounts.joinToString("") { acc ->
            val accVs = vouchers.filter { it.accountId == acc.id }
            val pay = accVs.filter { it.type == "pay" }.sumOf { it.amount }
            val debt = accVs.filter { it.type == "debt" }.sumOf { it.amount }
            totPay += pay
            totDebt += debt
            val net = pay - debt
            val side = if (net > 1e-9) "لكم" else if (net < -1e-9) "عليكم" else "متعادل"
            "<tr><td>${esc(acc.name)}</td><td class='grn'>${fmt(pay)}</td><td class='red'>${fmt(debt)}</td><td class='blu'>${esc(side)} ${fmt(abs(net))}</td></tr>"
        }.ifBlank { "<tr><td colspan='4'>لا توجد حسابات أو حركات ضمن الفترة</td></tr>" }

        val netAll = totPay - totDebt
        val sideAll = if (netAll > 1e-9) "لكم" else if (netAll < -1e-9) "عليكم" else "متعادل"
        val cls = if (netAll > 1e-9) "grn" else if (netAll < -1e-9) "red" else "blu"
        return """
            <div class='pv'>
              <div class='pv-title'>${if (auth) "مصادقة" else "كشف حسابات"} — ${esc(cashboxName)}</div>
              <div class='pv-meta bold'>الفترة: ${esc(DateHelper.displaySlash(from))} إلى ${esc(DateHelper.displaySlash(to))}</div>
              ${metaLine(settings)}
              <table class='pv-t'>
                <thead><tr><th>الحساب</th><th>لكم</th><th>عليكم</th><th>الرصيد</th></tr></thead>
                <tbody>
                  $rows
                  <tr class='pv-sum'><td>الإجمالي</td><td class='grn'>${fmt(totPay)}</td><td class='red'>${fmt(totDebt)}</td><td class='blu'>${fmt(abs(netAll))}</td></tr>
                </tbody>
              </table>
              <div class='pv-bal $cls'>الصافي ($sideAll): ${fmt(abs(netAll))}</div>
              $foot
            </div>
        """.trimIndent()
    }

    fun buildDebtSingleVoucherHtml(
        account: DebtAccount,
        voucher: DebtVoucher,
        allAccountVouchers: List<DebtVoucher>,
        settings: AppSettings
    ): String {
        val stamp = PdfPrintManager.buildStampHtml(settings, settings.printing.stampSettings.vouchers)
        val isPay = voucher.type == "pay"
        val totPay = allAccountVouchers.filter { it.type == "pay" }.sumOf { it.amount }
        val totDebt = allAccountVouchers.filter { it.type == "debt" }.sumOf { it.amount }
        val net = totPay - totDebt
        val balSide = if (net > 1e-9) "لكم" else if (net < -1e-9) "عليكم" else "متعادل"
        val balLabel = if (isPay) "الرصيد الباقي" else "الرصيد الكامل"
        val dirLabel = if (isPay) "سند قبض (لكم):" else "سند قيد (عليكم):"
        val unit = if (voucher.currency.isNotBlank()) " (${esc(voucher.currency)})" else ""
        return """
            <div class='pv'>
              <div class='tx-who'><span>الأخ:</span><span class='nm'>${esc(account.name)}</span><span>المحترم</span></div>
              <div class='tx'>
                <div>التاريخ: ${esc(DateHelper.displaySlash(voucher.date))} ${esc(voucher.time)}</div>
                <div>$dirLabel ${fmt(voucher.amount)}$unit</div>
                <div>البيان: ${esc(voucher.note.ifBlank { "—" }).replace("\n", "<br>")}</div>
                <div>$balLabel $balSide: ${fmt(abs(net))}$unit</div>
              </div>
              <div class='vc-stamp'>$stamp</div>
            </div>
        """.trimIndent()
    }

    fun buildTasfeerAccountHtml(
        account: TsAccount,
        vouchers: List<TsVoucher>,
        currencies: List<AppCurrency>,
        auth: Boolean,
        settings: AppSettings
    ): String {
        val baseCur = currencies.firstOrNull()?.name ?: "ريال يمني"
        val stampMode = if (auth) settings.printing.stampSettings.balance else settings.printing.stampSettings.statement
        val foot = PdfPrintManager.buildFootHtml(settings, stampMode)
        var run = 0.0
        var ps = 0.0
        var ng = 0.0
        val rows = vouchers
            .filter { it.accId == account.id }
            .sortedWith(compareBy<TsVoucher> { it.date }.thenBy { it.createdAt })
            .joinToString("") { v ->
                val vTot = TasfeerFxEngine.voucherTotalBase(v, baseCur)
                val isOut = v.dir == "out" || v.kind == "internal"
                if (isOut) ng += vTot else ps += vTot
                run += if (isOut) -vTot else vTot
                val label = when {
                    v.kind == "clockacc" -> "سند المراقب (${v.pg})"
                    v.kind == "internal" -> "حوالة داخلية"
                    v.isFx -> "فارق صرف"
                    v.isCom -> "عمولة حوالة"
                    else -> v.note.ifBlank { v.kind }
                }
                val noteTxt = "${esc(label)}${if (v.note.isNotBlank() && label != v.note) " — ${esc(v.note)}" else ""}"
                "<tr><td>${esc(DateHelper.displaySlash(v.date))}</td><td>$noteTxt</td><td class='red'>${if (isOut) fmt(vTot) else ""}</td><td class='grn'>${if (!isOut) fmt(vTot) else ""}</td><td class='blu'>${fmt(abs(run))} ${if (run < 0) "عليكم" else "لكم"}</td></tr>"
            }.ifBlank { "<tr><td colspan='5'>لا توجد حركات خلال الفترة المحددة</td></tr>" }

        val ab = abs(run)
        val side = if (run < -1e-9) "عليكم" else if (run > 1e-9) "لكم" else "متوازن"
        val cls = if (run < -1e-9) "red" else if (run > 1e-9) "grn" else "blu"

        return if (auth) {
            """
                <div class='pv'>
                  <div class='pv-title'>مصادقة حساب صرافة</div>
                  ${metaLine(settings)}
                  <div class='pv-who'><span>الأخ / ${esc(account.name)}</span><span>المحترم</span></div>
                  <div class='pv-c'>تحية طيبة وبعد</div>
                  <div class='pv-c'>نرجو منكم مطابقة ومصادقة الرصيد أدناه وذلك كجزء من إجراءاتنا مع كافة العملاء ولما فيه مصلحة الجميع</div>
                  <div class='pv-c'>وأرصدتكم لدينا كالتالي</div>
                  <table class='pv-t'><thead><tr><th>عليكم</th><th>لكم</th><th style='width:25%'></th><th>الرصيد</th><th>العملة</th></tr></thead>
                  <tbody><tr><td class='red'>${fmt(ng)}</td><td class='grn'>${fmt(ps)}</td><td></td><td class='blu'>${fmt(ab)}</td><td>${esc(baseCur)}</td></tr></tbody></table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)} (${esc(baseCur)})</div>
                  <div class='pv-c'>الرجاء مصادقة الرصيد وموافاتنا بالرد</div>
                  <div class='pv-r'>تاريخ المصادقة: ${esc(DateHelper.displaySlash(DateHelper.todayIso()))}</div>
                  ${authSignBlock()}
                  $foot
                </div>
            """.trimIndent()
        } else {
            """
                <div class='pv'>
                  <div class='pv-title'>كشف حساب صرافة</div>
                  ${metaLine(settings)}
                  <div class='pv-acc'>${esc(account.name)}</div>
                  <table class='pv-t'>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>عليه</th><th>له</th><th>الرصيد</th></tr></thead>
                    <tbody>
                      $rows
                      <tr class='pv-sum'><td colspan='2'>الإجمالي</td><td class='red'>${fmt(ng)}</td><td class='grn'>${fmt(ps)}</td><td class='blu'>${fmt(ab)}</td></tr>
                      <tr class='pv-sum'><td colspan='2'>الباقي</td><td class='red'>${fmt(maxOf(ng - ps, 0.0))}</td><td class='grn'>${fmt(maxOf(ps - ng, 0.0))}</td><td class='blu'>${fmt(ab)}</td></tr>
                    </tbody>
                  </table>
                  <div class='pv-bal $cls'>الرصيد $side: ${fmt(ab)}</div>
                  $foot
                </div>
            """.trimIndent()
        }
    }

    fun buildTasfeerFundHtml(
        fund: TsFund,
        vouchers: List<TsVoucher>,
        currencies: List<AppCurrency>,
        from: String,
        to: String,
        auth: Boolean,
        settings: AppSettings
    ): String {
        val baseCur = currencies.firstOrNull()?.name ?: "ريال يمني"
        val stampMode = if (auth) settings.printing.stampSettings.balance else settings.printing.stampSettings.statement
        val foot = PdfPrintManager.buildFootHtml(settings, stampMode)
        val filtered = vouchers
            .filter { (it.fundId == fund.id || it.fromFundId == fund.id || it.toFundId == fund.id) }
            .filter { (from.isBlank() || it.date >= from) && (to.isBlank() || it.date <= to) }
            .sortedWith(compareBy<TsVoucher> { it.date }.thenBy { it.createdAt })

        var ps = 0.0
        var ng = 0.0
        val rows = filtered.joinToString("") { v ->
            val vTot = TasfeerFxEngine.voucherTotalBase(v, baseCur)
            val isOut = v.kind == "internal" || (v.kind == "transfer" && v.fromFundId == fund.id) || (v.kind == "receipt" && v.dir == "out")
            if (isOut) ng += vTot else ps += vTot
            val curDet = v.rows.joinToString(" | ") { "${esc(it.cur)}: ${fmt(it.a)} × ${fmt(it.r)}" }
                .ifBlank { "${esc(v.fromCur)} ${fmt(v.fromAmt)} ← ${esc(v.toCur)} ${fmt(v.toAmt)}" }
            "<tr><td>${esc(DateHelper.displaySlash(v.date))}</td><td>${esc(v.kind)}</td><td>$curDet</td><td class='red'>${if (isOut) fmt(vTot) else ""}</td><td class='grn'>${if (!isOut) fmt(vTot) else ""}</td></tr>"
        }.ifBlank { "<tr><td colspan='5'>لا توجد حركات خلال الفترة المحددة</td></tr>" }

        val net = ps - ng
        val cls = if (net < -1e-9) "red" else if (net > 1e-9) "grn" else "blu"
        val side = if (net < -1e-9) "عليكم" else if (net > 1e-9) "لكم" else "متوازن"
        return """
            <div class='pv'>
              <div class='pv-title'>${if (auth) "مصادقة صندوق" else "كشف صندوق"} — ${esc(fund.name)}</div>
              <div class='pv-meta bold'>الفترة: ${esc(DateHelper.displaySlash(from))} إلى ${esc(DateHelper.displaySlash(to))}</div>
              ${metaLine(settings)}
              <table class='pv-t'>
                <thead><tr><th>التاريخ</th><th>النوع</th><th>العملات</th><th>صادر (عليكم)</th><th>وارد (لكم)</th></tr></thead>
                <tbody>$rows<tr class='pv-sum'><td colspan='3'>الإجمالي</td><td class='red'>${fmt(ng)}</td><td class='grn'>${fmt(ps)}</td></tr></tbody>
              </table>
              <div class='pv-bal $cls'>الرصيد $side: ${fmt(abs(net))} ${esc(baseCur)}</div>
              $foot
            </div>
        """.trimIndent()
    }

    fun buildTasfeerSingleVoucherHtml(
        v: TsVoucher,
        accounts: List<TsAccount>,
        funds: List<TsFund>,
        settings: AppSettings
    ): String {
        val baseCur = settings.currencies.firstOrNull()?.name ?: "ريال يمني"
        val stamp = PdfPrintManager.buildStampHtml(settings, settings.printing.stampSettings.vouchers)
        val accName = accounts.firstOrNull { it.id == v.accId }?.name ?: ""
        val fundName = funds.firstOrNull { it.id == v.fundId || it.id == v.fromFundId }?.name ?: ""
        val tot = TasfeerFxEngine.voucherTotalBase(v, baseCur)
        val isOut = v.dir == "out" || v.kind == "internal"
        val dateStr = "${DateHelper.displaySlash(v.date)} ${v.time}".trim()

        if (v.kind == "internal") {
            val amts = v.rows.joinToString(" | ") { "${fmt(it.a)} ${esc(it.cur)}" }
                .ifBlank { "${fmt(v.amount)} ${esc(v.cur.ifBlank { baseCur })}" }
            return """
                <div class='pv'>
                  <div class='pv-title'>سند إرسال حوالة</div>
                  <div class='pv-meta bold'>التاريخ : ${esc(dateStr)}</div>
                  <div class='hw-lab'>مبلغ ورمز العملة</div>
                  <div class='hw-amt'><div>$amts</div><div class='hw-b'>إرسال حوالة</div></div>
                  <table class='hw-t'><tbody>
                    <tr><th>من حساب</th><td colspan='3'>${esc(accName.ifBlank { fundName })}</td></tr>
                    <tr><th>مبلغ الحوالة</th><td colspan='2'>${esc(tafqeetWords(tot, baseCur))}</td><td>عمولة ${fmt(v.com)}</td></tr>
                    <tr><th>اسم المرسل</th><td colspan='2'>${esc(v.sender)}</td><td>إجمالي</td></tr>
                    <tr><th>اسم المستلم</th><td colspan='2'>${esc(v.receiver)}</td><td class='red'>${fmt(tot + v.com)} ${esc(baseCur)}</td></tr>
                    <tr><th>جهة التحويل</th><td>${esc(v.dest)}</td><th>رقم الحوالة</th><td>${esc(v.transferNo)}</td></tr>
                  </tbody></table>
                  ${if (v.note.isNotBlank()) "<div class='vc-note'>البيان: ${esc(v.note)}</div>" else ""}
                  <div class='hw-s'><span>توقيع المرسل</span><span>توقيع الموظف</span></div>
                  <div class='vc-stamp'>$stamp</div>
                </div>
            """.trimIndent()
        }

        val title = when (v.kind) {
            "transfer" -> "ترحيل بين الصناديق"
            "clockacc" -> "سند من المراقب — ${v.pg}"
            "exchange" -> "سند صرافة عملات"
            else -> if (isOut) "سند صرف" else "سند قبض"
        }
        val rowsHtml = if (v.rows.isNotEmpty()) {
            v.rows.joinToString("") { r -> "<tr><td>${fmt(r.a)}</td><td class='vc-c'>${esc(r.cur)}</td><td>${fmt(r.a * r.r)}</td></tr>" }
        } else {
            "<tr><td>${fmt(tot)}</td><td class='vc-c'>${esc(v.cur.ifBlank { baseCur })}</td><td>${fmt(tot)}</td></tr>"
        }
        return """
            <div class='pv'>
              <div class='vc'>
                <div class='pv-title green'>📥 ${esc(title)}</div>
                <div class='pv-meta bold'>التاريخ: ${esc(dateStr)}</div>
                <div class='pv-who'><span>من / ${esc(accName.ifBlank { fundName })}</span><span>المحترم</span></div>
                <div class='vc-w'><div class='vc-wt'>${esc(tafqeetWords(tot, baseCur))}</div><div class='vc-wl'>${if (isOut) "عليكم" else "لكم"}</div></div>
                <div class='vc-dh'>💱 العملات والتفصيل</div>
                <table class='vc-t'><tbody>$rowsHtml</tbody></table>
                ${if (v.note.isNotBlank()) "<div class='vc-note'>البيان: ${esc(v.note)}</div>" else ""}
                <div class='vc-tot'>${if (isOut) "المبلغ عليكم" else "المبلغ 💚 لكم"}: <span class='${if (isOut) "red" else "grn"}'>${fmt(tot)} ${esc(baseCur)}</span></div>
                <div class='vc-sign'><span>المستلم: ......................</span><span>أمين الصندوق: ......................</span></div>
                <div class='vc-stamp'>$stamp</div>
              </div>
            </div>
        """.trimIndent()
    }

    fun buildBuyerTransferHtml(sheet: BuyerTransferSheet, settings: AppSettings): String {
        val calc = BuyerCalculators.calculateTransfer(sheet)
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.statement)
        var qTot = 0.0
        var bTot = 0.0
        var eTot = 0.0
        val rows = sheet.rows.joinToString("") { r ->
            bTot += r.buy; eTot += r.exp
            "<tr><td>${esc(r.name)}</td><td>-</td><td>${fmt(r.buy, 2)}</td><td>${fmt(r.exp, 2)}</td><td>${fmt(r.buy + r.exp, 2)}</td></tr>"
        }.ifBlank { "<tr><td colspan='5'>لا توجد أيام</td></tr>" }
        qTot = sheet.habbaCount
        fun kvRow(a: String, b: String) = "<tr><td style='text-align:right'>$a</td><td>$b</td></tr>"
        return """
            <div class='pv by-print'>
              <section>
                <div class='pv-title'>تحويل الشراء — ${esc(sheet.name)}</div>
                <p>من ${esc(DateHelper.displaySlash(sheet.fromDate))} إلى ${esc(DateHelper.displaySlash(sheet.toDate))}</p>
                ${metaLine(settings)}
                <table class='pv-t'>
                  <thead><tr><th>اليوم / التاريخ</th><th>عدد الحبة</th><th>سعر الشراء</th><th>خرج رداع</th><th>إجمالي الشراء</th></tr></thead>
                  <tbody>$rows</tbody>
                  <tfoot><tr class='pv-sum'><td>الجملة</td><td>${fmt(qTot, 2)}</td><td>${fmt(bTot, 2)}</td><td>${fmt(eTot, 2)}</td><td>${fmt(calc.oldTotal, 2)}</td></tr></tfoot>
                </table>
                <h3>تحويل الشراء جديد</h3>
                <table class='pv-t kv'><tbody>
                  ${kvRow("مبلغ الشراء قديم", fmt(calc.oldTotal, 2))}
                  ${kvRow("سعر السعودي القديم", fmt(sheet.oldPrice, 2))}
                  ${kvRow("الشراء قديم = مبلغ سعودي على صرف رداع", fmt(calc.exchange, 2))}
                  ${kvRow("سعر شراء السعودي جديد", fmt(sheet.newPrice, 2))}
                  ${kvRow("الشراء قديم = الشراء جديد", fmt(calc.newTotal, 2))}
                </tbody></table>
                <h3>التفصيل النهائي</h3>
                <table class='pv-t kv'><tbody>
                  ${kvRow("خرج إجار رداع جديد", fmt(sheet.rentRada, 2))}
                  ${kvRow("خرج إجار شحن جديد", fmt(sheet.rentShip, 2))}
                  ${kvRow("إجمالي الشراء مع الخرج جديد", fmt(calc.totalExpenses, 2))}
                  ${kvRow("بيع الأسبوع المفصل شحن", fmt(sheet.weeklySale, 2))}
                  ${kvRow("الفارق (${calc.profitLabel})", fmt(abs(calc.diff), 2))}
                </tbody></table>
                ${if (sheet.diffAccountName.isNotBlank() || sheet.diffNote.isNotBlank()) "<div class='pv-r'>حساب الفرق: ${esc(sheet.diffAccountName)} — ${esc(sheet.diffNote)}</div>" else ""}
              </section>
              $foot
            </div>
        """.trimIndent()
    }

    fun buildBuyerAnnualHtml(folders: List<BuyerAnnualFolder>, settings: AppSettings): String {
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.statement)
        val sections = folders.joinToString("") { af ->
            val th = af.rows.sumOf { it.habba }
            val tb = af.rows.sumOf { it.buy }
            val ts = af.rows.sumOf { it.sell }
            val net = ts - tb
            val rows = af.rows.joinToString("") { r ->
                val cls = if (r.diff > 0) "grn" else if (r.diff < 0) "red" else "blu"
                "<tr><td>${esc(DateHelper.displaySlash(r.from))}</td><td>${esc(DateHelper.displaySlash(r.to))}</td><td>${fmt(r.habba, 2)}</td><td>${fmt(r.buy, 2)}</td><td>${fmt(r.sell, 2)}</td><td class='$cls'>${esc(r.profitLabel)}</td><td class='$cls'>${fmt(abs(r.diff), 2)}</td></tr>"
            }.ifBlank { "<tr><td colspan='7'>لا توجد بيانات</td></tr>" }
            val netLbl = if (net > 0) "الباقي ربح: " else if (net < 0) "الباقي خسارة: " else ""
            val netCls = if (net > 0) "grn" else if (net < 0) "red" else "blu"
            """
                <section style='page-break-after:auto'>
                  <div class='pv-title'>الكشف السنوي — ${esc(af.name)}</div>
                  ${metaLine(settings)}
                  <table class='pv-t'>
                    <thead><tr><th>من</th><th>إلى</th><th>عدد الحبه</th><th>الشراء جديد</th><th>البيع جديد</th><th>ربح/خساره</th><th>الفارق</th></tr></thead>
                    <tbody>$rows</tbody>
                    <tfoot><tr class='pv-sum'><td colspan='2'>الجملة</td><td>${fmt(th, 2)}</td><td>${fmt(tb, 2)}</td><td>${fmt(ts, 2)}</td><td colspan='2' class='$netCls'>$netLbl${fmt(abs(net), 2)}</td></tr></tfoot>
                  </table>
                </section>
            """.trimIndent()
        }
        return "<div class='pv by-print'>$sections$foot</div>"
    }

    fun buildBuyerControllerLedgerHtml(
        mode: String,
        sales: List<BuyerSaleEntry>,
        profits: List<BuyerProfitEntry>,
        specialties: List<Specialty>,
        settings: AppSettings
    ): String {
        val foot = PdfPrintManager.buildFootHtml(settings, settings.printing.stampSettings.statement)
        val specMap = specialties.associate { it.id to it.name }
        val title = when (mode) {
            "sales" -> "حوالات المبيعات"
            "seller" -> "الأرباح والسحوبات — البائع (50%)"
            else -> "الأرباح والسحوبات — المورد (50%)"
        }
        return if (mode == "sales") {
            val totCred = sales.filter { it.dir == "لكم" }.sumOf { it.amount }
            val totDeb = sales.filter { it.dir != "لكم" }.sumOf { it.amount }
            val net = totCred - totDeb
            val rows = sales.joinToString("") { s ->
                val isCred = s.dir == "لكم"
                val extra = listOfNotNull(
                    s.sender.takeIf { it.isNotBlank() }?.let { "المرسل: $it" },
                    s.receiver.takeIf { it.isNotBlank() }?.let { "المستلم: $it" },
                    s.entity.takeIf { it.isNotBlank() }?.let { "الجهة: $it" },
                    s.refNo.takeIf { it.isNotBlank() }?.let { "رقم: $it" }
                ).joinToString(" | ")
                "<tr><td>${esc(DateHelper.displaySlash(s.date))}</td><td>${esc(s.note.ifBlank { s.entity.ifBlank { s.sender } })}${if (extra.isNotBlank()) "<div style='font-size:10px;color:#475569;'>${esc(extra)}</div>" else ""}</td><td>${esc(specMap[s.specialtyId] ?: "")}</td><td class='red'>${if (!isCred) fmt(s.amount, 2) else ""}</td><td class='grn'>${if (isCred) fmt(s.amount, 2) else ""}</td></tr>"
            }.ifBlank { "<tr><td colspan='5'>لا توجد حركات</td></tr>" }
            val cls = if (net >= 0) "grn" else "red"
            """
                <div class='pv'>
                  <div class='pv-title'>$title</div>
                  ${metaLine(settings)}
                  <table class='pv-t'>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>التخصيص</th><th>عليكم</th><th>لكم</th></tr></thead>
                    <tbody>$rows<tr class='pv-sum'><td colspan='3'>الإجمالي</td><td class='red'>${fmt(totDeb, 2)}</td><td class='grn'>${fmt(totCred, 2)}</td></tr></tbody>
                  </table>
                  <div class='pv-bal $cls'>الصافي (${if (net >= 0) "لكم" else "عليكم"}): ${fmt(abs(net), 2)}</div>
                  $foot
                </div>
            """.trimIndent()
        } else {
            val totPlus = profits.filter { it.type != "سحب" && it.kind != "خسارة" }.sumOf { it.amount }
            val totMinus = profits.filter { it.type == "سحب" || it.kind == "خسارة" }.sumOf { it.amount }
            val net = totPlus - totMinus
            val rows = profits.joinToString("") { p ->
                val isPlus = p.type != "سحب" && p.kind != "خسارة"
                "<tr><td>${esc(DateHelper.displaySlash(p.date))}</td><td>${esc(p.note.ifBlank { p.type })}</td><td>${esc(specMap[p.specialtyId] ?: "")}</td><td>${esc(p.type)}</td><td class='${if (isPlus) "grn" else "red"}'>${fmt(p.amount, 2)}</td></tr>"
            }.ifBlank { "<tr><td colspan='5'>لا توجد حركات</td></tr>" }
            val cls = if (net >= 0) "grn" else "red"
            """
                <div class='pv'>
                  <div class='pv-title'>$title</div>
                  ${metaLine(settings)}
                  <table class='pv-t'>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>التخصيص</th><th>النوع</th><th>المبلغ</th></tr></thead>
                    <tbody>$rows<tr class='pv-sum'><td colspan='3'>الإجمالي</td><td class='grn'>+${fmt(totPlus, 2)}</td><td class='red'>-${fmt(totMinus, 2)}</td></tr></tbody>
                  </table>
                  <div class='pv-bal $cls'>الصافي: ${fmt(net, 2)}</div>
                  $foot
                </div>
            """.trimIndent()
        }
    }
}
