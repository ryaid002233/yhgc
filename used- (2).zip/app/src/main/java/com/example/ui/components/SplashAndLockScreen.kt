package com.example.ui.components

import android.content.Context
import android.content.ContextWrapper
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.luminance
import androidx.core.view.WindowCompat
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.core.content.ContextCompat
import com.example.domain.AppLockSettings
import com.example.ui.theme.AppColors
import com.example.ui.theme.AppFonts
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import kotlinx.coroutines.delay

private val SplashBgTop = Color(0xFF02060F)
private val SplashBgMid = Color(0xFF050D1E)
private val SplashGold = Color(0xFFF5CF7B)
private val SplashGoldBright = Color(0xFFFFEA9F)
private val SplashGoldDark = Color(0xFFB88828)
private val SplashMuted = Color(0xFF8C9BA8)
private val SplashBlueGlow = Color(0xFF006EFF)
private val SplashParticles = listOf(
    Offset(0.20f, 0.70f) to 0.0f,
    Offset(0.80f, 0.60f) to 0.20f,
    Offset(0.50f, 0.75f) to 0.35f,
    Offset(0.32f, 0.38f) to 0.55f,
    Offset(0.72f, 0.32f) to 0.75f
)

/**
 * Faithful Jetpack Compose implementation of index_0088c0bb.html welcome splash screen
 * with staggered entrance animations, glowing backdrop waves, metallic emblem, and smooth transition.
 */
@Composable
private fun DarkOverlayStatusBarEffect() {
    val view = LocalView.current
    val tokens = LocalFrameTokens.current
    val restoreLight = tokens.barTop.luminance() > 0.5f
    if (!view.isInEditMode) {
        DisposableEffect(view, restoreLight) {
            val window = view.context.findActivityOrNull()?.window
            val controller = window?.let { WindowCompat.getInsetsController(it, view) }
            controller?.isAppearanceLightStatusBars = false
            onDispose {
                controller?.isAppearanceLightStatusBars = restoreLight
            }
        }
    }
}

@Composable
fun LuxurySplashOverlay(onFinished: () -> Unit) {
    DarkOverlayStatusBarEffect()
    val strings = LocalAppStrings.current
    val infinite = rememberInfiniteTransition(label = "splash_anim")
    val spinDeg by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(35000, easing = LinearEasing)),
        label = "dashed_spin"
    )
    val particleFloat by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(6000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particles"
    )

    // Staggered animation states matching index_0088c0bb.html
    val frameAlpha = remember { Animatable(0f) }
    val emblemProgress = remember { Animatable(0f) }
    val titleProgress = remember { Animatable(0f) }
    val dividerProgress = remember { Animatable(0f) }
    val subtitleProgress = remember { Animatable(0f) }
    val loaderContainerProgress = remember { Animatable(0f) }
    val loaderFill = remember { Animatable(0f) }
    val footerProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        val backEasing = CubicBezierEasing(0.175f, 0.885f, 0.32f, 1.275f)
        val ease = FastOutSlowInEasing
        val loaderEasing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)

        launch {
            delay(60L)
            frameAlpha.animateTo(1f, tween(520, easing = ease))
        }
        launch {
            delay(80L)
            emblemProgress.animateTo(1f, tween(560, easing = backEasing))
        }
        launch {
            delay(200L)
            titleProgress.animateTo(1f, tween(480, easing = ease))
        }
        launch {
            delay(320L)
            dividerProgress.animateTo(1f, tween(460, easing = ease))
        }
        launch {
            delay(420L)
            subtitleProgress.animateTo(1f, tween(460, easing = ease))
        }
        launch {
            delay(500L)
            loaderContainerProgress.animateTo(1f, tween(420, easing = ease))
        }
        launch {
            delay(560L)
            loaderFill.animateTo(1f, tween(980, easing = loaderEasing))
        }
        launch {
            delay(700L)
            footerProgress.animateTo(1f, tween(460, easing = ease))
        }

        delay(1600L)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(SplashBgTop, SplashBgMid, SplashBgTop)
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onFinished
            )
            .testTag("luxury_splash_screen")
    ) {
        // Static background radial glows & angled waves cached via drawWithCache
        Spacer(
            modifier = Modifier
                .fillMaxSize()
                .drawWithCache {
                    val topSpot = Offset(size.width * 0.5f, size.height * 0.25f)
                    val topRadius = size.maxDimension * 0.56f
                    val topBrush = Brush.radialGradient(
                        colors = listOf(SplashBlueGlow.copy(alpha = 0.30f), Color.Transparent),
                        center = topSpot,
                        radius = topRadius
                    )
                    val botGoldSpot = Offset(size.width * 0.5f, size.height * 0.85f)
                    val botRadius = size.maxDimension * 0.48f
                    val botBrush = Brush.radialGradient(
                        colors = listOf(SplashGoldDark.copy(alpha = 0.16f), Color.Transparent),
                        center = botGoldSpot,
                        radius = botRadius
                    )
                    val leftWaveCenter = Offset(size.width * 0.35f, size.height * 0.92f)
                    val leftWaveRadius = size.width * 0.65f
                    val leftWaveBrush = Brush.radialGradient(
                        colors = listOf(Color(0xFF0066FF).copy(alpha = 0.22f), Color.Transparent),
                        center = leftWaveCenter,
                        radius = leftWaveRadius
                    )
                    val rightWaveCenter = Offset(size.width * 0.65f, size.height * 0.96f)
                    val rightWaveRadius = size.width * 0.60f
                    val rightWaveBrush = Brush.radialGradient(
                        colors = listOf(Color(0xFFD4AF6A).copy(alpha = 0.18f), Color.Transparent),
                        center = rightWaveCenter,
                        radius = rightWaveRadius
                    )
                    onDrawBehind {
                        drawCircle(brush = topBrush, center = topSpot, radius = topRadius)
                        drawCircle(brush = botBrush, center = botGoldSpot, radius = botRadius)
                        withTransform({
                            rotate(degrees = -8f, pivot = leftWaveCenter)
                            scale(scaleX = 1.45f, scaleY = 0.55f, pivot = leftWaveCenter)
                        }) {
                            drawCircle(brush = leftWaveBrush, center = leftWaveCenter, radius = leftWaveRadius)
                        }
                        withTransform({
                            rotate(degrees = 12f, pivot = rightWaveCenter)
                            scale(scaleX = 1.40f, scaleY = 0.45f, pivot = rightWaveCenter)
                        }) {
                            drawCircle(brush = rightWaveBrush, center = rightWaveCenter, radius = rightWaveRadius)
                        }
                    }
                }
        )

        // Floating luminous gold particles
        Canvas(modifier = Modifier.fillMaxSize()) {
            val baseOffset = 20.dp.toPx()
            val travel = 140.dp.toPx()
            val glowRadius = 8.dp.toPx()
            val coreRadius = 2.2.dp.toPx()
            SplashParticles.forEach { (pos, phase) ->
                val t = (particleFloat + phase) % 1f
                val alpha = kotlin.math.sin(t * Math.PI).toFloat().coerceIn(0f, 1f) * 0.80f
                val pScale = 0.5f + 0.7f * t
                val px = size.width * pos.x
                val py = size.height * pos.y + baseOffset - (t * travel)
                drawCircle(
                    color = SplashGold.copy(alpha = alpha * 0.38f),
                    radius = glowRadius * pScale,
                    center = Offset(px, py)
                )
                drawCircle(
                    color = SplashGoldBright.copy(alpha = alpha),
                    radius = coreRadius * pScale,
                    center = Offset(px, py)
                )
            }
        }

        // 4 Golden L-shaped corner brackets inside safe insets (.frame i)
        Spacer(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(18.dp)
                .graphicsLayer { alpha = frameAlpha.value }
                .drawWithCache {
                    val len = 28.dp.toPx()
                    val strokeW = 1.2.dp.toPx()
                    val bracketGlow = SplashGold.copy(alpha = 0.22f)
                    val bracketColor = SplashGold.copy(alpha = 0.62f)
                    val w = size.width
                    val h = size.height
                    val lines = listOf(
                        Offset(0f, 0f) to Offset(len, 0f),
                        Offset(0f, 0f) to Offset(0f, len),
                        Offset(w - len, 0f) to Offset(w, 0f),
                        Offset(w, 0f) to Offset(w, len),
                        Offset(0f, h - len) to Offset(0f, h),
                        Offset(0f, h) to Offset(len, h),
                        Offset(w, h - len) to Offset(w, h),
                        Offset(w - len, h) to Offset(w, h)
                    )
                    onDrawBehind {
                        lines.forEach { (start, end) ->
                            drawLine(bracketGlow, start, end, strokeW * 3.5f)
                            drawLine(bracketColor, start, end, strokeW)
                        }
                    }
                }
        )

        // Center content matching index_0088c0bb.html
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 56.dp)
        ) {
            // Circular Emblem (220dp) with spring scale-in
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(220.dp)
                        .graphicsLayer {
                            val p = emblemProgress.value
                            val s = 0.80f + 0.20f * p
                            scaleX = s
                            scaleY = s
                            alpha = p.coerceIn(0f, 1f)
                        }
                ) {
                    // Outer blue & gold halo (.emblem-glow)
                    Spacer(
                        modifier = Modifier
                            .size(248.dp)
                            .drawWithCache {
                                val halo = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF0078FF).copy(alpha = 0.48f),
                                        SplashGold.copy(alpha = 0.22f),
                                        Color.Transparent
                                    )
                                )
                                onDrawBehind { drawCircle(brush = halo) }
                            }
                    )

                    // Outer disc + gold border + inner ring + rotating dashed ring
                    Box(
                        modifier = Modifier
                            .size(220.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF1D61CD),
                                        Color(0xFF071F4F),
                                        Color(0xFF020A1C)
                                    ),
                                    center = Offset(155f, 155f),
                                    radius = 430f
                                )
                            )
                            .border(BorderStroke(3.5.dp, SplashGold), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        // .ring-gold-inner (5dp inset)
                        Spacer(
                            modifier = Modifier
                                .fillMaxSize()
                                .drawWithCache {
                                    val inset1 = 5.dp.toPx()
                                    val stroke = Stroke(width = 1.dp.toPx())
                                    val radius = (size.minDimension / 2f) - inset1
                                    val col = SplashGold.copy(alpha = 0.70f)
                                    onDrawBehind {
                                        drawCircle(color = col, radius = radius, style = stroke)
                                    }
                                }
                        )

                        // .ring-dashed (9dp inset, rotating via graphicsLayer)
                        Spacer(
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer { rotationZ = spinDeg }
                                .drawWithCache {
                                    val inset2 = 9.dp.toPx()
                                    val radius = (size.minDimension / 2f) - inset2
                                    val stroke = Stroke(
                                        width = 1.dp.toPx(),
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                                    )
                                    val col = SplashGold.copy(alpha = 0.36f)
                                    onDrawBehind {
                                        drawCircle(color = col, radius = radius, style = stroke)
                                    }
                                }
                        )

                        // Curved metallic silver wires (.wires-svg)
                        Spacer(
                            modifier = Modifier
                                .padding(top = 52.dp)
                                .width(150.dp)
                                .height(75.dp)
                                .align(Alignment.TopCenter)
                                .drawWithCache {
                                    val sx = size.width / 150f
                                    val sy = size.height / 75f
                                    val wireBrush = Brush.linearGradient(
                                        colors = listOf(Color.White, Color(0xFFA0B8D8), Color(0xFF5577A8))
                                    )
                                    val wireStroke = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
                                    val curves = listOf(
                                        listOf(30f, 10f, 15f, 25f, 20f, 55f, 65f, 62f),
                                        listOf(40f, 10f, 25f, 30f, 32f, 58f, 75f, 64f),
                                        listOf(50f, 10f, 40f, 35f, 45f, 60f, 85f, 65f),
                                        listOf(62f, 10f, 55f, 40f, 62f, 62f, 95f, 65f),
                                        listOf(88f, 10f, 95f, 40f, 88f, 62f, 105f, 65f),
                                        listOf(100f, 10f, 110f, 35f, 105f, 60f, 115f, 65f),
                                        listOf(110f, 10f, 125f, 30f, 118f, 58f, 125f, 64f),
                                        listOf(120f, 10f, 135f, 25f, 130f, 55f, 135f, 62f)
                                    )
                                    val paths = curves.map { c ->
                                        Path().apply {
                                            moveTo(c[0] * sx, c[1] * sy)
                                            cubicTo(
                                                c[2] * sx, c[3] * sy,
                                                c[4] * sx, c[5] * sy,
                                                c[6] * sx, c[7] * sy
                                            )
                                        }
                                    }
                                    onDrawBehind {
                                        paths.forEach { p ->
                                            drawPath(
                                                path = p,
                                                brush = wireBrush,
                                                alpha = 0.90f,
                                                style = wireStroke
                                            )
                                        }
                                    }
                                }
                        )

                        // Inner vertical emblem content (.emblem-inner-content)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 22.dp, bottom = 18.dp, start = 15.dp, end = 15.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Top rounded icon box (.inner-box) with outer blue glow
                            Box(contentAlignment = Alignment.Center) {
                                Spacer(
                                    modifier = Modifier
                                        .size(96.dp)
                                        .drawWithCache {
                                            val glow = Brush.radialGradient(
                                                colors = listOf(Color(0xFF008CFF).copy(alpha = 0.55f), Color.Transparent)
                                            )
                                            onDrawBehind { drawCircle(brush = glow) }
                                        }
                                )
                                Box(
                                    modifier = Modifier
                                        .size(78.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(Color(0xFF184C98), Color(0xFF061633))
                                            )
                                        )
                                        .border(2.dp, Color(0xFFA4C7FF), RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    // Top-right glowing dot (.inner-dot)
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(top = 11.dp, end = 12.dp)
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF7FB2FF))
                                    )
                                    // White geometric arch vector (.inner-icon)
                                    Spacer(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .drawWithCache {
                                                val u = size.minDimension / 24f
                                                val outerArch = Path().apply {
                                                    moveTo(4f * u, 18f * u)
                                                    lineTo(4f * u, 9.5f * u)
                                                    lineTo(12f * u, 4f * u)
                                                    lineTo(20f * u, 9.5f * u)
                                                    lineTo(20f * u, 18f * u)
                                                }
                                                val innerArch = Path().apply {
                                                    moveTo(9f * u, 18f * u)
                                                    lineTo(9f * u, 12f * u)
                                                    lineTo(12f * u, 10f * u)
                                                    lineTo(15f * u, 12f * u)
                                                    lineTo(15f * u, 18f * u)
                                                }
                                                val glowColor = Color.White.copy(alpha = 0.35f)
                                                val glowStroke = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                                                val mainStroke = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                                                onDrawBehind {
                                                    drawPath(outerArch, glowColor, style = glowStroke)
                                                    drawPath(innerArch, glowColor, style = glowStroke)
                                                    drawPath(outerArch, Color.White, style = mainStroke)
                                                    drawPath(innerArch, Color.White, style = mainStroke)
                                                }
                                            }
                                    )
                                }
                            }

                            // Bottom labels inside circle (.emblem-labels)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = strings.t("الاداري برو", "Al-Idari Pro"),
                                    fontFamily = AppFonts.Cairo,
                                    fontSize = 21.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    style = TextStyle(
                                        shadow = Shadow(
                                            color = Color(0xFF0066FF),
                                            offset = Offset(0f, 2f),
                                            blurRadius = 12f
                                        )
                                    )
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(SplashGold, SplashGoldBright, SplashGold)
                                            )
                                        )
                                        .padding(horizontal = 12.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = strings.t("تصميم رياض اليافعي", "Design: Riyadh Al-Yafei"),
                                        fontFamily = AppFonts.Cairo,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF071633),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // Main Title (.main-title)
            Text(
                text = strings.t("الإداري برو", "Al-Idari Pro"),
                fontFamily = AppFonts.Cairo,
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.White, SplashGoldBright, SplashGold, SplashGoldDark)
                    ),
                    shadow = Shadow(
                        color = Color.Black.copy(alpha = 0.70f),
                        offset = Offset(0f, 4f),
                        blurRadius = 12f
                    )
                ),
                modifier = Modifier.graphicsLayer {
                    val p = titleProgress.value
                    alpha = p
                    translationY = (1f - p) * 20.dp.toPx()
                }
            )

            Spacer(Modifier.height(10.dp))

            // Diamond Divider (.divider)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth(0.70f)
                    .widthIn(max = 280.dp)
                    .graphicsLayer {
                        val p = dividerProgress.value
                        alpha = p
                        translationY = (1f - p) * 16.dp.toPx()
                    }
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(
                            Brush.horizontalGradient(listOf(Color.Transparent, SplashGold))
                        )
                )
                Box(contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.size(20.dp)) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(SplashGold.copy(alpha = 0.65f), Color.Transparent)
                            )
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .rotate(45f)
                            .background(SplashGoldBright)
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                        .background(
                            Brush.horizontalGradient(listOf(SplashGold, Color.Transparent))
                        )
                )
            }

            Spacer(Modifier.height(10.dp))

            // Subtitle (.subtitle)
            Text(
                text = strings.t("نظام إدارة عصري", "Modern Management System"),
                fontFamily = AppFonts.Cairo,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = Color(0xFFE0E6ED),
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer {
                    val p = subtitleProgress.value
                    alpha = p
                    translationY = (1f - p) * 16.dp.toPx()
                }
            )

            Spacer(Modifier.height(32.dp))

            // Golden Progress Loader Capsule (.loader-container)
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.80f)
                    .widthIn(max = 240.dp)
                    .height(7.dp)
                    .graphicsLayer {
                        val p = loaderContainerProgress.value
                        alpha = p
                        translationY = (1f - p) * 16.dp.toPx()
                    }
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.10f))
                    .border(1.dp, SplashGold.copy(alpha = 0.40f), RoundedCornerShape(10.dp))
                    .padding(1.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction = loaderFill.value.coerceIn(0f, 1f))
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(SplashGoldDark, SplashGoldBright, SplashGold)
                            )
                        )
                )
            }
        }

        // Bottom Footer Credits (.footer-credits)
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 18.dp)
                .graphicsLayer {
                    val p = footerProgress.value
                    alpha = p
                    translationY = (1f - p) * 14.dp.toPx()
                },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(15.dp)
        ) {
            Box(Modifier.width(35.dp).height(1.dp).background(SplashGold.copy(alpha = 0.30f)))
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = SplashMuted, fontWeight = FontWeight.Normal)) {
                        append(strings.t("من تصميم ", "Designed by "))
                    }
                    withStyle(SpanStyle(color = SplashGoldBright, fontWeight = FontWeight.Bold)) {
                        append(strings.t("رياض اليافعي", "Riyadh Al-Yafei"))
                    }
                },
                fontFamily = AppFonts.Cairo,
                fontSize = 12.sp
            )
            Box(Modifier.width(35.dp).height(1.dp).background(SplashGold.copy(alpha = 0.30f)))
        }
    }
}

@Composable
fun AppLockScreen(
    lockSettings: AppLockSettings,
    onVerifyPin: (String) -> Boolean,
    onBiometricSuccess: () -> Unit
) {
    DarkOverlayStatusBarEffect()
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var entered by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }
    val targetLen = lockSettings.pin.length.coerceAtLeast(4)

    fun triggerBiometric() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && lockSettings.biometric) {
            val activity = context.findActivityOrNull() ?: return
            try {
                val prompt = BiometricPrompt.Builder(activity)
                    .setTitle(strings.appTitle)
                    .setSubtitle(strings.t("افتح القفل بالبصمة", "Unlock with Biometrics"))
                    .setNegativeButton(
                        strings.t("استخدام الرمز", "Use PIN"),
                        ContextCompat.getMainExecutor(activity)
                    ) { _, _ -> }
                    .build()
                prompt.authenticate(
                    CancellationSignal(),
                    ContextCompat.getMainExecutor(activity),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                            onBiometricSuccess()
                        }
                    }
                )
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(lockSettings.biometric) {
        if (lockSettings.biometric) triggerBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(AppColors.NavyDeep, Color(0xFF0A193A)))
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(AppColors.GoldAccent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = AppColors.GoldLight, modifier = Modifier.size(34.dp))
            }

            Text(
                text = strings.t("التطبيق مقفل", "App Locked"),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(targetLen) { idx ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (idx < entered.length) AppColors.GoldAccent
                                else Color.White.copy(alpha = 0.25f)
                            )
                    )
                }
            }

            if (errorMsg.isNotBlank()) {
                Text(errorMsg, color = AppColors.DebitRedDark, style = MaterialTheme.typography.bodySmall)
            }

            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("BIO", "0", "DEL")
            )

            keys.forEach { row ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    row.forEach { k ->
                        when (k) {
                            "BIO" -> {
                                if (lockSettings.biometric && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                    FilledTonalButton(
                                        onClick = { triggerBiometric() },
                                        shape = CircleShape,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(62.dp)
                                    ) {
                                        Icon(Icons.Default.Fingerprint, contentDescription = "Biometric")
                                    }
                                } else {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                            "DEL" -> {
                                FilledTonalButton(
                                    onClick = { if (entered.isNotEmpty()) entered = entered.dropLast(1) },
                                    shape = CircleShape,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(62.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = strings.delete)
                                }
                            }
                            else -> {
                                ElevatedButton(
                                    onClick = {
                                        errorMsg = ""
                                        if (entered.length < targetLen) {
                                            entered += k
                                            if (entered.length == targetLen) {
                                                if (!onVerifyPin(entered)) {
                                                    errorMsg = strings.t("الرمز غير صحيح", "Incorrect PIN")
                                                    entered = ""
                                                }
                                            }
                                        }
                                    },
                                    shape = CircleShape,
                                    colors = ButtonDefaults.elevatedButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.14f),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(62.dp)
                                        .testTag("pin_key_$k")
                                ) {
                                    Text(k, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

tailrec fun Context.findActivityOrNull(): android.app.Activity? = when (this) {
    is android.app.Activity -> this
    is ContextWrapper -> baseContext.findActivityOrNull()
    else -> null
}
