package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.PrintReportBuilders
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs

// =====================================================================
// Shared Private Accounts Chrome Components (admin.html .pa-* visual match)
// =====================================================================

@Composable
private fun PrivateTopBar(
    title: String,
    onBack: () -> Unit,
    backTestTag: String = "pa_back_btn",
    titleHeroKey: String? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val btnBorder = if (tokens.frameEnabled && tokens.frameStyle != "none") {
        BorderStroke(1.dp, tokens.barDivider)
    } else null

    Surface(
        color = Color.Transparent,
        shadowElevation = tokens.elevation,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.barBrush)
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag(backTestTag)
                ) {
                    Surface(
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = tokens.barButtonBg,
                        border = btnBorder,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = strings.close,
                                tint = tokens.barContent,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        color = tokens.barContent,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.heroBounds(titleHeroKey, zIndexInOverlay = 2f)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    actions()
                }
            }
            if (tokens.frameEnabled && tokens.frameStyle != "none") {
                HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
            }
        }
    }
}

@Composable
private fun PrivateHeaderIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    tint: Color? = null,
    testTag: String = ""
) {
    val tokens = LocalFrameTokens.current
    val btnBorder = if (tokens.frameEnabled && tokens.frameStyle != "none") {
        BorderStroke(1.dp, tokens.barDivider)
    } else null
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(48.dp)
            .let { if (testTag.isNotBlank()) it.testTag(testTag) else it }
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.buttonRadius),
            color = tokens.barButtonBg,
            border = btnBorder,
            modifier = Modifier.size(38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = contentDescription,
                    tint = tint ?: tokens.barContent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun PrivateCurrencyRow(
    currencies: List<AppCurrency>,
    selectedCurrency: String,
    allowAll: Boolean,
    onSelectCurrency: (String) -> Unit,
    onOpenManage: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var dropdownOpen by remember { mutableStateOf(false) }

    val selectedLabel = when {
        selectedCurrency == PRIVATE_ALL_CURRENCIES -> strings.t("كل العملات", "All Currencies")
        else -> currencies.firstOrNull { it.name == selectedCurrency }?.name ?: selectedCurrency
    }

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor) else null,
        shadowElevation = tokens.elevation,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.cardBrush)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                Surface(
                    onClick = { dropdownOpen = true },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 42.dp)
                        .testTag("pa_currency_dropdown")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Spacer(Modifier.width(18.dp))
                        Text(
                            text = selectedLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            Icons.Default.KeyboardArrowDown,
                            contentDescription = strings.t("العملة", "Currency"),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                DropdownMenu(expanded = dropdownOpen, onDismissRequest = { dropdownOpen = false }) {
                    if (allowAll) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    strings.t("كل العملات", "All Currencies"),
                                    fontWeight = if (selectedCurrency == PRIVATE_ALL_CURRENCIES) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            leadingIcon = {
                                if (selectedCurrency == PRIVATE_ALL_CURRENCIES) Icon(Icons.Default.Check, contentDescription = null)
                            },
                            onClick = { onSelectCurrency(PRIVATE_ALL_CURRENCIES); dropdownOpen = false }
                        )
                        HorizontalDivider()
                    }
                    currencies.forEach { c ->
                        val isSel = selectedCurrency == c.name
                        DropdownMenuItem(
                            text = {
                                Text(
                                    "${c.name} (${c.symbol})",
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            leadingIcon = {
                                if (isSel) Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            onClick = { onSelectCurrency(c.name); dropdownOpen = false }
                        )
                    }
                }
            }

            Surface(
                onClick = onOpenManage,
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.7f)),
                shadowElevation = tokens.elevation,
                modifier = Modifier
                    .heightIn(min = 42.dp)
                    .testTag("pa_manage_currencies_btn")
            ) {
                Box(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.t("إدارة العملات", "Currencies"),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun PrivateDateRangeBar(
    fromDate: String,
    toDate: String,
    onRangeChange: (String, String) -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var pickingTarget by remember { mutableStateOf<String?>(null) }

    val safeFrom = fromDate.ifBlank { DateHelper.yearStartIso() }
    val safeTo = toDate.ifBlank { DateHelper.yearEndIso() }

    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.barDivider) else null,
        shadowElevation = tokens.elevation,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.barBrush)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                onClick = {
                    val (nf, nt) = DateHelper.shiftPeriod(safeFrom, safeTo, -1)
                    onRangeChange(nf, nt)
                },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = tokens.barButtonBg,
                border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.barDivider) else null,
                modifier = Modifier.size(42.dp).testTag("pa_date_prev_btn")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.t("الفترة السابقة", "Previous"),
                        tint = tokens.barContent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Surface(
                onClick = { pickingTarget = "from" },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 42.dp)
                    .testTag("pa_date_from_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.CalendarMonth,
                        contentDescription = strings.from,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = DateHelper.displaySlash(safeFrom),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Text(
                text = strings.t("إلى", "to"),
                color = tokens.barContent,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

            Surface(
                onClick = { pickingTarget = "to" },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 42.dp)
                    .testTag("pa_date_to_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Default.CalendarMonth,
                        contentDescription = strings.to,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = DateHelper.displaySlash(safeTo),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Surface(
                onClick = {
                    val (nf, nt) = DateHelper.shiftPeriod(safeFrom, safeTo, 1)
                    onRangeChange(nf, nt)
                },
                shape = RoundedCornerShape(tokens.buttonRadius),
                color = tokens.barButtonBg,
                border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.barDivider) else null,
                modifier = Modifier.size(42.dp).testTag("pa_date_next_btn")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = strings.t("الفترة التالية", "Next"),
                        tint = tokens.barContent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    if (pickingTarget != null) {
        AppDatePickerDialog(
            initialIso = if (pickingTarget == "from") safeFrom else safeTo,
            onPicked = { picked ->
                if (pickingTarget == "from") onRangeChange(picked, safeTo)
                else onRangeChange(safeFrom, picked)
                pickingTarget = null
            },
            onDismiss = { pickingTarget = null }
        )
    }
}

// =====================================================================
// Screen 1: PrivateFoldersScreen (Screenshot 4 — المجلدات الخصوصية)
// =====================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PrivateFoldersScreen(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenDrawer: () -> Unit,
    onBackToHome: () -> Unit = onOpenDrawer,
    onOpenFolder: (PrivateFolder) -> Unit,
    onOpenAccount: (PrivateAccount) -> Unit = {}
) {
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val snap = uiState.snapshot

    var showFolderDialog by remember { mutableStateOf(false) }
    var editingFolder by remember { mutableStateOf<PrivateFolder?>(null) }
    var showStats by remember { mutableStateOf(false) }
    var showQuickSearch by remember { mutableStateOf(false) }

    val currencies = settings.currencies
    val defCur = settings.defaultCurrency.ifBlank { currencies.firstOrNull()?.name ?: "ريال يمني" }

    Scaffold(
        topBar = {
            PrivateTopBar(
                title = strings.privateAccounts,
                onBack = onBackToHome,
                backTestTag = "pa_home_back_btn"
            ) {
                Spacer(Modifier.size(44.dp))
            }
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { editingFolder = null; showFolderDialog = true },
                contentDescription = strings.t("مجلد جديد", "New Folder"),
                modifier = Modifier.testTag("add_private_folder_fab")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // .pa-tools 3-button row (إضافة مجلد / الإحصائيات / البحث السريع)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(
                    Triple(
                        strings.t("إضافة مجلد", "Add Folder"),
                        "pa_add_folder_btn"
                    ) {
                        editingFolder = null
                        showFolderDialog = true
                    },
                    Triple(
                        strings.t("الإحصائيات", "Stats"),
                        "pa_stats_btn"
                    ) {
                        showStats = true
                    },
                    Triple(
                        strings.t("البحث السريع", "Quick Search"),
                        "pa_quick_search_btn"
                    ) {
                        showQuickSearch = true
                    }
                ).forEach { (label, tag, action) ->
                    Surface(
                        onClick = action,
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = Color.Transparent,
                        border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor) else null,
                        shadowElevation = tokens.elevation,
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag(tag)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .background(tokens.cardBrush)
                                .padding(horizontal = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            if (snap.privateFolders.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStateView(
                        icon = Icons.Default.LockPerson,
                        title = strings.t("لا توجد مجلدات حسابات خصوصية", "No Private Folders"),
                        subtitle = strings.t("اضغط على + لإضافة مجلد جديد", "Tap + to add a folder")
                    )
                }
            } else {
                val accountsByFolder = remember(snap.privateAccounts) {
                    snap.privateAccounts.groupBy { it.folderId }
                }
                val txsByAccount = remember(snap.privateTxs) {
                    snap.privateTxs.groupBy { it.accountId }
                }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 104.dp),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(top = 2.dp, bottom = 88.dp)
                ) {
                    items(snap.privateFolders, key = { it.id }) { folder ->
                        val folderAccounts = accountsByFolder[folder.id].orEmpty()
                        val currencyNets = remember(folderAccounts, txsByAccount, defCur) {
                            val nets = LinkedHashMap<String, Double>()
                            for (acc in folderAccounts) {
                                val txs = txsByAccount[acc.id].orEmpty()
                                for (tx in txs) {
                                    val c = tx.currency.ifBlank { defCur }
                                    val delta = if (tx.type == "عليه") tx.amount else -tx.amount
                                    nets[c] = (nets[c] ?: 0.0) + delta
                                }
                            }
                            nets.entries.take(3).map { it.key to it.value }
                        }

                        Surface(
                            shape = RoundedCornerShape(tokens.cornerRadius),
                            color = Color.Transparent,
                            border = if (tokens.frameEnabled) BorderStroke(1.2.dp, tokens.borderColor) else null,
                            shadowElevation = tokens.elevation,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 104.dp)
                                .clip(RoundedCornerShape(tokens.cornerRadius))
                                .combinedClickable(
                                    onClick = { onOpenFolder(folder) },
                                    onLongClick = { editingFolder = folder; showFolderDialog = true }
                                )
                                .testTag("pa_folder_card_${folder.id}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(tokens.cardBrush)
                                    .padding(horizontal = 6.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(tokens.buttonRadius),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.8f)),
                                    shadowElevation = 1.dp,
                                    modifier = Modifier
                                        .size(42.dp)
                                        .heroElement("hero_pf_icon_${folder.id}", zIndexInOverlay = 2f)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Group,
                                            contentDescription = folder.name,
                                            tint = Color(0xFF0284C7),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = folder.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.heroBounds("hero_pf_title_${folder.id}", zIndexInOverlay = 2f)
                                )

                                if (currencyNets.isEmpty()) {
                                    val defSym = privateCurrencySymbol(defCur, currencies)
                                    Text(
                                        text = "${strings.t("متعادل", "Even")} $defSym".trim(),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center
                                    )
                                } else {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        currencyNets.forEach { (c, net) ->
                                            val sym = privateCurrencySymbol(c, currencies)
                                            val (label, col) = when {
                                                net > 1e-9 -> "${strings.t("لكم", "Credit")} ${fmt(net)} $sym".trim() to AppColors.CreditGreen
                                                net < -1e-9 -> "${strings.t("عليكم", "Debit")} ${fmt(-net)} $sym".trim() to AppColors.DebitRed
                                                else -> "${strings.t("متعادل", "Even")} $sym".trim() to MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = col,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFolderDialog) {
        val hasAccs = editingFolder?.let { ef -> snap.privateAccounts.any { it.folderId == ef.id } } ?: false
        PrivateFolderEditDialog(
            existing = editingFolder,
            hasAccounts = hasAccs,
            viewModel = viewModel,
            onDismiss = { showFolderDialog = false; editingFolder = null }
        )
    }

    if (showStats) {
        PrivateStatsDialog(
            foldersCount = snap.privateFolders.size,
            accounts = snap.privateAccounts,
            txs = snap.privateTxs,
            currencies = currencies,
            onDismiss = { showStats = false }
        )
    }

    if (showQuickSearch) {
        PrivateQuickSearchDialog(
            folders = snap.privateFolders,
            accounts = snap.privateAccounts,
            txs = snap.privateTxs,
            defaultCurrency = defCur,
            currencies = currencies,
            onSelectAccount = onOpenAccount,
            onDismiss = { showQuickSearch = false }
        )
    }
}

// =====================================================================
// Screen 2: PrivateFolderAccountsScreen (Screenshot 5 — حسابات المجلد)
// =====================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PrivateFolderAccountsScreen(
    folderId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenAccount: (PrivateAccount) -> Unit,
    onOpenCurrencySettings: () -> Unit = {},
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val activity = LocalContext.current.findActivityOrNull()
    val haptic = LocalHapticFeedback.current
    val snap = uiState.snapshot

    val folder = snap.privateFolders.firstOrNull { it.id == folderId }
    val currencies = settings.currencies
    val defCur = settings.defaultCurrency.ifBlank { currencies.firstOrNull()?.name ?: "ريال يمني" }

    var selectedCur by remember(currencies) {
        mutableStateOf(currencies.firstOrNull()?.name ?: defCur)
    }
    var sortBy by remember { mutableStateOf("name") } // name, balance, date
    var sortAsc by remember { mutableStateOf(true) }
    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }

    var showFolderEdit by remember { mutableStateOf(false) }
    var showCurrencyManager by remember { mutableStateOf(false) }
    var showAccountDialog by remember { mutableStateOf(false) }
    var editingAccount by remember { mutableStateOf<PrivateAccount?>(null) }
    var menuAccount by remember { mutableStateOf<PrivateAccount?>(null) }
    var pendingDeleteAccount by remember { mutableStateOf<PrivateAccount?>(null) }
    var transferAccRequest by remember { mutableStateOf<Pair<PrivateAccount, Boolean>?>(null) } // account to isMove

    val folderAccounts = remember(snap.privateAccounts, folderId) {
        snap.privateAccounts.filter { it.folderId == folderId }
    }
    val accountIds = remember(folderAccounts) { folderAccounts.map { it.id }.toSet() }

    val filteredTxs = remember(snap.privateTxs, accountIds, selectedCur, fromDate, toDate) {
        snap.privateTxs.filter { t ->
            t.accountId in accountIds &&
                (selectedCur == PRIVATE_ALL_CURRENCIES || t.currency == selectedCur) &&
                (fromDate.isBlank() || t.date >= fromDate) &&
                (toDate.isBlank() || t.date <= toDate)
        }
    }

    val accStats = remember(folderAccounts, filteredTxs, snap.privateTxs) {
        var owedUs = 0.0
        var weOwe = 0.0
        var zeroCnt = 0
        val netMap = mutableMapOf<String, Double>()
        val lastDateMap = mutableMapOf<String, String?>()

        folderAccounts.forEach { acc ->
            val accTxs = filteredTxs.filter { it.accountId == acc.id }
            val net = accTxs.sumOf { if (it.type == "عليه") it.amount else -it.amount }
            netMap[acc.id] = net
            if (net > 1e-9) owedUs += net
            else if (net < -1e-9) weOwe += -net
            else zeroCnt++

            val last = snap.privateTxs
                .filter { it.accountId == acc.id && (selectedCur == PRIVATE_ALL_CURRENCIES || it.currency == selectedCur) }
                .maxByOrNull { "${it.date}_${it.createdAt}" }?.date
            lastDateMap[acc.id] = last
        }
        Triple(Triple(weOwe, owedUs, zeroCnt), netMap, lastDateMap)
    }

    val summaryTriple = accStats.first
    val netMap = accStats.second
    val lastDateMap = accStats.third

    val sortedAccounts = remember(folderAccounts, netMap, lastDateMap, sortBy, sortAsc) {
        val base = when (sortBy) {
            "balance" -> folderAccounts.sortedBy { abs(netMap[it.id] ?: 0.0) }
            "date" -> folderAccounts.sortedBy { lastDateMap[it.id] ?: "" }
            else -> folderAccounts.sortedBy { it.name }
        }
        if (sortAsc) base else base.reversed()
    }

    val activeSymbol = if (selectedCur == PRIVATE_ALL_CURRENCIES) "" else privateCurrencySymbol(selectedCur, currencies)

    Scaffold(
        topBar = {
            PrivateTopBar(
                title = folder?.name ?: strings.privateAccounts,
                onBack = onBack,
                backTestTag = "pa_folder_back_btn",
                titleHeroKey = "hero_pf_title_${folderId}"
            ) {
                if (folder != null) {
                    PrivateHeaderIconButton(
                        icon = Icons.Default.Edit,
                        contentDescription = strings.edit,
                        onClick = { showFolderEdit = true },
                        tint = Color(0xFFF59E0B),
                        testTag = "pa_folder_edit_btn"
                    )
                }
            }
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { editingAccount = null; showAccountDialog = true },
                contentDescription = strings.t("إضافة حساب", "Add Account"),
                modifier = Modifier.testTag("add_private_account_fab")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Spacer(Modifier.height(2.dp))

            PrivateCurrencyRow(
                currencies = currencies,
                selectedCurrency = selectedCur,
                allowAll = true,
                onSelectCurrency = { selectedCur = it },
                onOpenManage = { showCurrencyManager = true }
            )

            // 3 Summary Cards: الإجمالي عليكم / الإجمالي لكم / لا يوجد رصيد
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PrivateFolderStatBox(
                    title = strings.t("الإجمالي عليكم", "You Owe"),
                    value = fmt(summaryTriple.first),
                    subLabel = activeSymbol,
                    valueColor = AppColors.DebitRed,
                    modifier = Modifier.weight(1f)
                )
                PrivateFolderStatBox(
                    title = strings.t("الإجمالي لكم", "Owed To You"),
                    value = fmt(summaryTriple.second),
                    subLabel = activeSymbol,
                    valueColor = AppColors.CreditGreen,
                    modifier = Modifier.weight(1f)
                )
                PrivateFolderStatBox(
                    title = strings.t("لا يوجد رصيد", "Zero Balance"),
                    value = summaryTriple.third.toString(),
                    subLabel = strings.t("حساب", "Acc"),
                    valueColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
            }

            LuxurySortBar(
                options = listOf(
                    "name" to strings.t("الاسم", "Name"),
                    "balance" to strings.t("الرصيد", "Balance"),
                    "date" to strings.t("التاريخ", "Date")
                ),
                selected = sortBy,
                sortAsc = sortAsc,
                onSelect = { sortBy = it },
                onDirectionChange = { sortAsc = it }
            )

            PrivateDateRangeBar(
                fromDate = fromDate,
                toDate = toDate,
                onRangeChange = { f, t -> fromDate = f; toDate = t }
            )

            if (sortedAccounts.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyStateView(
                        icon = Icons.Default.PersonAdd,
                        title = strings.t("لا توجد حسابات في هذا المجلد", "No Accounts Here"),
                        subtitle = strings.t("اضغط على + لإضافة حساب جديد", "Tap + to add a new account")
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(sortedAccounts, key = { it.id }) { acc ->
                        val net = netMap[acc.id] ?: 0.0
                        val lastDate = lastDateMap[acc.id]
                        val sub = listOfNotNull(
                            acc.phone.takeIf { it.isNotBlank() },
                            lastDate?.let { strings.t("آخر حركة $it", "Last $it") }
                        ).joinToString(" • ")

                        val balColor = when {
                            net > 1e-9 -> AppColors.CreditGreen
                            net < -1e-9 -> AppColors.DebitRed
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }

                        Surface(
                            shape = RoundedCornerShape(tokens.cornerRadius),
                            color = Color.Transparent,
                            border = if (tokens.frameEnabled) BorderStroke(1.1.dp, tokens.borderColor) else null,
                            shadowElevation = tokens.elevation,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(tokens.cornerRadius))
                                .combinedClickable(
                                    onClick = { onOpenAccount(acc) },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        menuAccount = acc
                                    }
                                )
                                .testTag("pa_account_row_${acc.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 58.dp)
                                    .background(tokens.cardBrush)
                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(tokens.iconTileRadius))
                                        .background(tokens.darkTileBrush)
                                        .then(
                                            if (tokens.frameEnabled) Modifier.border(1.dp, tokens.borderColor, RoundedCornerShape(tokens.iconTileRadius))
                                            else Modifier
                                        )
                                        .heroElement("hero_pa_badge_${acc.id}", zIndexInOverlay = 2f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = acc.name.trim().firstOrNull()?.toString() ?: "؟",
                                        color = tokens.darkTileContent,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp
                                    )
                                }

                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = acc.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.heroBounds("hero_pa_title_${acc.id}", zIndexInOverlay = 2f)
                                    )
                                    if (sub.isNotBlank()) {
                                        Text(
                                            text = sub,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = privateBalanceText(net, settings.lang == "en"),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = balColor,
                                        maxLines = 1
                                    )
                                    if (acc.cap > 0.0 && net > acc.cap) {
                                        Text(
                                            text = strings.t("تجاوز السقف", "Over Cap"),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AppColors.DebitRed,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFolderEdit && folder != null) {
        PrivateFolderEditDialog(
            existing = folder,
            hasAccounts = folderAccounts.isNotEmpty(),
            viewModel = viewModel,
            onDeleted = onBack,
            onDismiss = { showFolderEdit = false }
        )
    }

    if (showCurrencyManager) {
        PrivateCurrencyManagerDialog(
            selectedCurrency = selectedCur,
            currencies = currencies,
            onSelectCurrency = { selectedCur = it },
            onOpenCurrencySettings = onOpenCurrencySettings,
            onDismiss = { showCurrencyManager = false }
        )
    }

    if (showAccountDialog) {
        PrivateAccountEditDialog(
            folderId = folderId,
            existing = editingAccount,
            existingInFolder = folderAccounts,
            defaultSendMethod = settings.messages.sendMethod,
            defaultSendTiming = settings.messages.sendWhen,
            viewModel = viewModel,
            onDismiss = { showAccountDialog = false; editingAccount = null }
        )
    }

    menuAccount?.let { acc ->
        val printCur = if (selectedCur == PRIVATE_ALL_CURRENCIES) {
            snap.privateTxs.firstOrNull { it.accountId == acc.id }?.currency ?: defCur
        } else selectedCur
        val accTxsAllCur = snap.privateTxs
            .filter { it.accountId == acc.id && it.currency == printCur }
            .sortedWith(compareBy<PrivateTx> { it.date }.thenBy { it.createdAt })
        val periodAccTxs = accTxsAllCur.filter { t ->
            (fromDate.isBlank() || t.date >= fromDate) &&
                (toDate.isBlank() || t.date <= toDate)
        }
        AlertDialog(
            onDismissRequest = { menuAccount = null },
            title = { Text(acc.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DebtMenuActionButton(strings.t("تعديل الحساب", "Edit Account"), Icons.Default.Edit) {
                        menuAccount = null
                        editingAccount = acc
                        showAccountDialog = true
                    }
                    DebtMenuActionButton(strings.t("حذف الحساب", "Delete Account"), Icons.Default.Delete, isDestructive = true) {
                        menuAccount = null
                        pendingDeleteAccount = acc
                    }
                    DebtMenuActionButton(strings.t("طباعة كشف للفترة المحددة", "Print Statement"), Icons.Default.Print) {
                        val html = PrintReportBuilders.buildPrivateStatementHtml(
                            account = acc,
                            txs = periodAccTxs,
                            priorBal = 0.0,
                            currencyFilter = printCur,
                            auth = false,
                            settings = uiState.settings
                        )
                        viewModel.printHtmlReport(activity, acc.name, html)
                        menuAccount = null
                    }
                    DebtMenuActionButton(strings.t("طباعة مصادقة حساب للفترة المحددة", "Print Auth Statement"), Icons.Default.Verified) {
                        val html = PrintReportBuilders.buildPrivateStatementHtml(
                            account = acc,
                            txs = periodAccTxs,
                            priorBal = 0.0,
                            currencyFilter = printCur,
                            auth = true,
                            settings = uiState.settings
                        )
                        viewModel.printHtmlReport(activity, "مصادقة ${acc.name}", html)
                        menuAccount = null
                    }
                    DebtMenuActionButton(strings.t("نسخ الحساب إلى مجلد آخر", "Copy to Another Folder"), Icons.Default.ContentCopy) {
                        transferAccRequest = acc to false
                        menuAccount = null
                    }
                    DebtMenuActionButton(strings.t("نقل الحساب إلى مجلد آخر", "Move to Another Folder"), Icons.Default.DriveFileMove) {
                        transferAccRequest = acc to true
                        menuAccount = null
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuAccount = null }) { Text(strings.close) } }
        )
    }

    pendingDeleteAccount?.let { acc ->
        ConfirmActionDialog(
            title = strings.t("حذف الحساب", "Delete Account"),
            message = strings.t("هل تريد نقل الحساب \"${acc.name}\" وجميع معاملاته إلى سلة المهملات؟", "Move account \"${acc.name}\" to trash?"),
            confirmText = strings.delete,
            onConfirm = { viewModel.deletePrivateAccount(acc) },
            onDismiss = { pendingDeleteAccount = null }
        )
    }

    transferAccRequest?.let { (acc, isMove) ->
        val targets = snap.privateFolders.filter { !isMove || it.id != acc.folderId }
        AlertDialog(
            onDismissRequest = { transferAccRequest = null },
            title = {
                Text(
                    strings.t(if (isMove) "نقل الحساب إلى مجلد" else "نسخ الحساب إلى مجلد", "Select Folder"),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (targets.isEmpty()) {
                        Text(strings.t("لا توجد مجلدات أخرى", "No other folders available"))
                    } else {
                        targets.forEach { targetFolder ->
                            DebtMenuActionButton(targetFolder.name, Icons.Default.Folder) {
                                viewModel.copyOrMovePrivateAccount(acc, targetFolder.id, isMove)
                                transferAccRequest = null
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { transferAccRequest = null }) { Text(strings.close) } }
        )
    }
}

@Composable
private fun PrivateFolderStatBox(
    title: String,
    value: String,
    subLabel: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    val tokens = LocalFrameTokens.current
    Surface(
        shape = RoundedCornerShape(tokens.cornerRadius),
        color = Color.Transparent,
        border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor) else null,
        shadowElevation = tokens.elevation,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.cardBrush)
                .padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = valueColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subLabel.isNotBlank()) {
                Text(
                    text = subLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

// =====================================================================
// Screen 3: PrivateAccountStatementScreen (Screenshot 3 — كشف الحساب)
// =====================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PrivateAccountStatementScreen(
    accountId: String,
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onOpenCurrencySettings: () -> Unit = {},
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val activity = context.findActivityOrNull()
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current
    val haptic = LocalHapticFeedback.current

    val account = uiState.snapshot.privateAccounts.firstOrNull { it.id == accountId }
    if (account == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val currencies = settings.currencies
    val defCur = settings.defaultCurrency.ifBlank { currencies.firstOrNull()?.name ?: "ريال يمني" }

    var selectedCur by remember(currencies) {
        mutableStateOf(currencies.firstOrNull()?.name ?: defCur)
    }
    var sortBy by remember { mutableStateOf("date") } // date, amount, type
    var sortAsc by remember { mutableStateOf(false) } // newest first matching Screenshot 3 default
    var periodMode by remember { mutableStateOf("year") } // month, all, year
    var includePrior by remember { mutableStateOf(false) }
    var fromDate by remember { mutableStateOf(DateHelper.yearStartIso()) }
    var toDate by remember { mutableStateOf(DateHelper.yearEndIso()) }
    var selectMode by remember { mutableStateOf(false) }
    val selectedIds = remember { mutableStateListOf<String>() }

    var showVoucherDialog by remember { mutableStateOf(false) }
    var editingTx by remember { mutableStateOf<PrivateTx?>(null) }
    var menuTx by remember { mutableStateOf<PrivateTx?>(null) }
    var transferTxRequest by remember { mutableStateOf<Pair<List<PrivateTx>, Boolean>?>(null) } // txs to isMove
    var showTransfer by remember { mutableStateOf(false) }
    var showAccountEdit by remember { mutableStateOf(false) }
    var showCurrencyManager by remember { mutableStateOf(false) }
    var previewImg by remember { mutableStateOf<Pair<String, String>?>(null) } // path to txId
    var shareTargetTx by remember { mutableStateOf<Pair<PrivateTx, Double>?>(null) }
    var pendingDeleteTx by remember { mutableStateOf<PrivateTx?>(null) }
    var pendingDeleteBulk by remember { mutableStateOf<List<PrivateTx>?>(null) }
    var pendingSendConfirm by remember { mutableStateOf<Pair<String, String>?>(null) } // method to text
    var attachPhotoTx by remember { mutableStateOf<PrivateTx?>(null) }

    val directPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val target = attachPhotoTx
        attachPhotoTx = null
        if (uri != null && target != null) {
            viewModel.saveImageFromUri(uri) { savedPath ->
                viewModel.savePrivateTx(target.copy(img = savedPath))
                viewModel.emitMessage(strings.t("تم إرفاق الصورة", "Photo attached"))
            }
        }
    }

    val allAccountTxsForCur = remember(uiState.snapshot.privateTxs, accountId, selectedCur) {
        uiState.snapshot.privateTxs
            .filter { it.accountId == accountId && it.currency == selectedCur }
            .sortedWith(compareBy<PrivateTx> { it.date }.thenBy { it.createdAt })
    }

    val fullCurBalance = remember(allAccountTxsForCur) {
        allAccountTxsForCur.sumOf { if (it.type == "عليه") it.amount else -it.amount }
    }

    val priorBal = remember(allAccountTxsForCur, fromDate, includePrior, periodMode) {
        if (!includePrior || periodMode == "all" || fromDate.isBlank()) 0.0
        else allAccountTxsForCur.filter { it.date < fromDate }.sumOf { if (it.type == "عليه") it.amount else -it.amount }
    }

    val visibleChrono = remember(allAccountTxsForCur, fromDate, toDate, periodMode) {
        if (periodMode == "all") allAccountTxsForCur
        else allAccountTxsForCur.filter { t ->
            (fromDate.isBlank() || t.date >= fromDate) &&
                (toDate.isBlank() || t.date <= toDate)
        }
    }

    val totDebt = remember(visibleChrono) { visibleChrono.filter { it.type == "عليه" }.sumOf { it.amount } }
    val totPay = remember(visibleChrono) { visibleChrono.filter { it.type == "له" }.sumOf { it.amount } }
    val net = priorBal + totDebt - totPay

    val runningBalances = remember(visibleChrono, priorBal) {
        var run = priorBal
        val m = mutableMapOf<String, Double>()
        visibleChrono.forEach { t ->
            run += if (t.type == "عليه") t.amount else -t.amount
            m[t.id] = run
        }
        m
    }

    val displayTxs = remember(visibleChrono, sortBy, sortAsc) {
        val sorted = when (sortBy) {
            "amount" -> visibleChrono.sortedBy { it.amount }
            "type" -> visibleChrono.sortedWith(compareBy<PrivateTx> { it.type }.thenBy { it.date }.thenBy { it.createdAt })
            else -> visibleChrono // already date + createdAt ascending
        }
        if (sortAsc) sorted else sorted.reversed()
    }

    Scaffold(
        topBar = {
            PrivateTopBar(
                title = account.name,
                onBack = onBack,
                backTestTag = "pa_stmt_back_btn",
                titleHeroKey = "hero_pa_title_${accountId}"
            ) {
                PrivateHeaderIconButton(
                    icon = Icons.Default.SwapHoriz,
                    contentDescription = strings.t("قيد إلى حساب", "Transfer"),
                    onClick = { showTransfer = true },
                    testTag = "pa_stmt_transfer_btn"
                )
                PrivateHeaderIconButton(
                    icon = Icons.Default.Print,
                    contentDescription = strings.print,
                    onClick = {
                        val html = PrintReportBuilders.buildPrivateStatementHtml(
                            account = account,
                            txs = visibleChrono,
                            priorBal = priorBal,
                            currencyFilter = selectedCur,
                            auth = false,
                            settings = uiState.settings
                        )
                        viewModel.printHtmlReport(activity, account.name, html)
                    },
                    testTag = "pa_stmt_print_btn"
                )
                PrivateHeaderIconButton(
                    icon = Icons.Default.Verified,
                    contentDescription = strings.auth,
                    onClick = {
                        val html = PrintReportBuilders.buildPrivateStatementHtml(
                            account = account,
                            txs = visibleChrono,
                            priorBal = priorBal,
                            currencyFilter = selectedCur,
                            auth = true,
                            settings = uiState.settings
                        )
                        viewModel.printHtmlReport(activity, "مصادقة ${account.name}", html)
                    },
                    tint = Color(0xFFF59E0B),
                    testTag = "pa_stmt_auth_btn"
                )
                PrivateHeaderIconButton(
                    icon = Icons.Default.Edit,
                    contentDescription = strings.edit,
                    onClick = { showAccountEdit = true },
                    testTag = "pa_stmt_edit_acc_btn"
                )
            }
        },
        bottomBar = {
            // Sticky Bottom Summary Bar (.pa-foot)
            Surface(
                color = Color.Transparent,
                border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.barDivider) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(tokens.barBrush)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${strings.t("عليه", "Debit")}: ${fmt(totDebt)}",
                        color = tokens.barContent,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${strings.t("له", "Credit")}: ${fmt(totPay)}",
                        color = tokens.barContent,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${strings.t("الرصيد", "Balance")}: ${privateBalanceText(net, settings.lang == "en")}",
                        color = tokens.barAccent,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        floatingActionButtonPosition = rightFabPosition(),
        floatingActionButton = {
            LuxuryAddFab(
                onClick = { editingTx = null; showVoucherDialog = true },
                contentDescription = strings.t("سند جديد", "New Voucher"),
                modifier = Modifier.testTag("add_private_tx_fab")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Spacer(Modifier.height(1.dp))

            if (account.cap > 0.0 && fullCurBalance > account.cap) {
                Surface(
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    color = AppColors.DebitRedContainerLight,
                    border = BorderStroke(1.dp, AppColors.DebitRed.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = AppColors.DebitRed, modifier = Modifier.size(16.dp))
                        Text(
                            text = strings.t(
                                "تنبيه: تجاوز الرصيد (${fmt(fullCurBalance)}) سقف المديونية (${fmt(account.cap)})",
                                "Alert: Balance (${fmt(fullCurBalance)}) exceeds cap (${fmt(account.cap)})"
                            ),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AppColors.DebitRed
                        )
                    }
                }
            }

            PrivateCurrencyRow(
                currencies = currencies,
                selectedCurrency = selectedCur,
                allowAll = false,
                onSelectCurrency = { selectedCur = it },
                onOpenManage = { showCurrencyManager = true }
            )

            LuxurySortBar(
                options = listOf(
                    "date" to strings.t("التاريخ", "Date"),
                    "amount" to strings.t("المبلغ", "Amount"),
                    "type" to strings.t("النوع", "Type")
                ),
                selected = sortBy,
                sortAsc = sortAsc,
                onSelect = { sortBy = it },
                onDirectionChange = { sortAsc = it }
            )

            // .pa-modebar: شهري / الكل / سنوي + رصيد سابق
            Surface(
                shape = RoundedCornerShape(tokens.cornerRadius),
                color = Color.Transparent,
                border = if (tokens.frameEnabled) BorderStroke(1.dp, tokens.borderColor) else null,
                shadowElevation = tokens.elevation,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(tokens.cardBrush)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(
                        "month" to strings.t("شهري", "Monthly"),
                        "all" to strings.t("الكل", "All"),
                        "year" to strings.t("سنوي", "Yearly")
                    ).forEach { (key, lbl) ->
                        val active = periodMode == key
                        Surface(
                            onClick = {
                                periodMode = key
                                when (key) {
                                    "month" -> {
                                        fromDate = DateHelper.monthStartIso()
                                        toDate = DateHelper.todayIso()
                                    }
                                    "year" -> {
                                        fromDate = DateHelper.yearStartIso()
                                        toDate = DateHelper.yearEndIso()
                                    }
                                    else -> {
                                        fromDate = ""
                                        toDate = ""
                                    }
                                }
                            },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                if (active) MaterialTheme.colorScheme.primary else tokens.borderColor.copy(alpha = 0.55f)
                            ),
                            modifier = Modifier.heightIn(min = 36.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                RadioButton(
                                    selected = active,
                                    onClick = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(3.dp))
                                Text(
                                    text = lbl,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { includePrior = !includePrior }
                            .padding(horizontal = 4.dp, vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = includePrior,
                            onCheckedChange = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = strings.t("رصيد سابق", "Prior"),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            if (periodMode != "all") {
                PrivateDateRangeBar(
                    fromDate = fromDate,
                    toDate = toDate,
                    onRangeChange = { f, t -> fromDate = f; toDate = t }
                )
            }

            if (selectMode) {
                val selectedList = displayTxs.filter { it.id in selectedIds }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = { if (selectedList.isNotEmpty()) transferTxRequest = selectedList to true },
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text(strings.t("نقل (${selectedList.size})", "Move (${selectedList.size})"), maxLines = 1) }
                    FilledTonalButton(
                        onClick = { if (selectedList.isNotEmpty()) transferTxRequest = selectedList to false },
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text(strings.t("نسخ", "Copy"), maxLines = 1) }
                    Button(
                        onClick = { if (selectedList.isNotEmpty()) pendingDeleteBulk = selectedList },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                    ) { Text(strings.delete, maxLines = 1) }
                    IconButton(
                        onClick = { selectMode = false; selectedIds.clear() },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = strings.cancel)
                    }
                }
            }

            // Table Header (.pa-th): النوع | المبلغ | التفاصيل | الرصيد
            Surface(
                shape = RoundedCornerShape(topStart = tokens.buttonRadius, topEnd = tokens.buttonRadius),
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(tokens.barBrush)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.t("النوع", "Type"),
                        color = tokens.barContent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.16f)
                    )
                    Text(
                        text = strings.t("المبلغ", "Amount"),
                        color = tokens.barContent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.24f)
                    )
                    Text(
                        text = strings.t("التفاصيل", "Details"),
                        color = tokens.barContent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.38f)
                    )
                    Text(
                        text = strings.t("الرصيد", "Balance"),
                        color = tokens.barContent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(0.22f)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 84.dp)
            ) {
                if (includePrior && periodMode != "all" && abs(priorBal) > 1e-6) {
                    item(key = "prior_row") {
                        Surface(
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (priorBal > 0) "عليه" else "له",
                                    color = if (priorBal > 0) AppColors.CreditGreen else AppColors.DebitRed,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(0.16f)
                                )
                                Text(
                                    text = fmt(abs(priorBal)),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(0.24f)
                                )
                                Text(
                                    text = strings.t("رصيد سابق", "Prior Balance"),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(0.38f)
                                )
                                Text(
                                    text = fmt(abs(priorBal)),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(0.22f)
                                )
                            }
                        }
                    }
                }

                if (displayTxs.isEmpty()) {
                    item(key = "empty_stmt") {
                        EmptyStateView(
                            icon = Icons.Default.ReceiptLong,
                            title = strings.t("لا توجد معاملات في هذه الفترة", "No Transactions"),
                            subtitle = strings.t("اضغط على + لإضافة سند جديد", "Tap + to add a voucher")
                        )
                    }
                } else {
                    items(displayTxs, key = { it.id }) { tx ->
                        val isDebt = tx.type == "عليه"
                        val run = runningBalances[tx.id] ?: 0.0
                        val hasImg = rememberFileExists(tx.img)
                        val isSel = tx.id in selectedIds

                        Surface(
                            shape = RoundedCornerShape(tokens.cornerRadius),
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                if (isSel) 2.dp else 1.2.dp,
                                if (isSel) MaterialTheme.colorScheme.primary else tokens.borderColor.copy(alpha = 0.85f)
                            ),
                            shadowElevation = tokens.elevation,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(tokens.cornerRadius))
                                .combinedClickable(
                                    onClick = {
                                        if (selectMode) {
                                            if (isSel) selectedIds.remove(tx.id) else selectedIds.add(tx.id)
                                        } else {
                                            menuTx = tx
                                        }
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        menuTx = tx
                                    }
                                )
                                .testTag("pa_tx_row_${tx.id}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(0.16f)
                                    ) {
                                        if (selectMode) {
                                            Icon(
                                                imageVector = if (isSel) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        Text(
                                            text = tx.type,
                                            color = if (isDebt) AppColors.CreditGreen else AppColors.DebitRed,
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Black,
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(0.24f)
                                    ) {
                                        Text(
                                            text = fmt(tx.amount),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Black,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = tx.date,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(3.dp),
                                        modifier = Modifier.weight(0.38f).padding(horizontal = 4.dp)
                                    ) {
                                        if (tx.lines.isNotEmpty()) {
                                            Text(
                                                text = tx.lines.joinToString("\n"),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                textAlign = TextAlign.Center,
                                                maxLines = 4,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        if (hasImg) {
                                            Image(
                                                painter = rememberThumbnailPainter(tx.img, maxSizePx = 160),
                                                contentDescription = strings.t("صورة السند", "Voucher Photo"),
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .clickable { previewImg = tx.img to tx.id }
                                            )
                                        }
                                    }

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(0.22f)
                                    ) {
                                        Text(
                                            text = fmt(abs(run)),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (run > 1e-9) AppColors.CreditGreen else if (run < -1e-9) AppColors.DebitRed else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                // .pa-txbtns: 5 bordered icon buttons centered (📷 / 📤 / 🖨️ / ✏️ / 🗑️)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    PrivateTxActionChip(
                                        icon = Icons.Default.PhotoCamera,
                                        contentDescription = strings.t("صورة السند", "Photo"),
                                        tint = if (hasImg) AppColors.CreditGreen else MaterialTheme.colorScheme.onSurface,
                                        onClick = {
                                            if (hasImg) previewImg = tx.img to tx.id
                                            else {
                                                attachPhotoTx = tx
                                                directPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                            }
                                        }
                                    )
                                    PrivateTxActionChip(
                                        icon = Icons.Default.IosShare,
                                        contentDescription = strings.share,
                                        tint = Color(0xFFD97706),
                                        onClick = { shareTargetTx = tx to run }
                                    )
                                    PrivateTxActionChip(
                                        icon = Icons.Default.Print,
                                        contentDescription = strings.print,
                                        tint = MaterialTheme.colorScheme.onSurface,
                                        onClick = {
                                            val html = PrintReportBuilders.buildPrivateSingleVoucherHtml(
                                                account = account,
                                                tx = tx,
                                                allAccountTxs = allAccountTxsForCur,
                                                settings = uiState.settings
                                            )
                                            viewModel.printHtmlReport(activity, "سند ${account.name}", html, isVoucher = true)
                                        }
                                    )
                                    PrivateTxActionChip(
                                        icon = Icons.Default.Edit,
                                        contentDescription = strings.edit,
                                        tint = Color(0xFFB45309),
                                        onClick = { editingTx = tx; showVoucherDialog = true }
                                    )
                                    PrivateTxActionChip(
                                        icon = Icons.Default.Delete,
                                        contentDescription = strings.delete,
                                        tint = Color(0xFF0284C7),
                                        onClick = { pendingDeleteTx = tx }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showVoucherDialog) {
        PrivateVoucherDialog(
            account = account,
            existing = editingTx,
            initialCurrency = selectedCur,
            allAccountTxs = uiState.snapshot.privateTxs.filter { it.accountId == account.id },
            currencies = currencies,
            defaultCurrency = defCur,
            viewModel = viewModel,
            onSaved = { savedTx, newBal ->
                selectedCur = savedTx.currency
                if (editingTx == null && account.phone.isNotBlank()) {
                    val (method, timing) = parsePrivateSend(account.send)
                    if (timing == "auto" || timing == "confirm") {
                        val msgText = viewModel.buildAccountMessageText(
                            accountName = account.name,
                            typeLabel = savedTx.type,
                            amount = savedTx.amount,
                            currency = savedTx.currency,
                            note = savedTx.lines.joinToString(" - "),
                            netBalance = newBal,
                            netIsCreditForClient = newBal <= 0
                        )
                        if (timing == "auto") {
                            if (method == "sms") ShareHelper.openSms(context, account.phone, msgText, settings.messages)
                            else ShareHelper.openWhatsApp(context, account.phone, msgText, settings.messages)
                        } else {
                            pendingSendConfirm = method to msgText
                        }
                    }
                }
            },
            onDismiss = { showVoucherDialog = false; editingTx = null }
        )
    }

    if (showTransfer) {
        PrivateTransferDialog(
            sourceAccount = account,
            allAccounts = uiState.snapshot.privateAccounts,
            folders = uiState.snapshot.privateFolders,
            currencies = currencies,
            initialCurrency = selectedCur,
            viewModel = viewModel,
            onDismiss = { showTransfer = false }
        )
    }

    if (showAccountEdit) {
        val folderAccs = uiState.snapshot.privateAccounts.filter { it.folderId == account.folderId }
        PrivateAccountEditDialog(
            folderId = account.folderId,
            existing = account,
            existingInFolder = folderAccs,
            defaultSendMethod = settings.messages.sendMethod,
            defaultSendTiming = settings.messages.sendWhen,
            viewModel = viewModel,
            onDeleted = onBack,
            onDismiss = { showAccountEdit = false }
        )
    }

    if (showCurrencyManager) {
        PrivateCurrencyManagerDialog(
            selectedCurrency = selectedCur,
            currencies = currencies,
            onSelectCurrency = { picked ->
                if (picked != PRIVATE_ALL_CURRENCIES) selectedCur = picked
            },
            onOpenCurrencySettings = onOpenCurrencySettings,
            onDismiss = { showCurrencyManager = false }
        )
    }

    shareTargetTx?.let { (tx, runBal) ->
        PrivateShareTxDialog(
            account = account,
            tx = tx,
            runningBalanceAfter = runBal,
            currencies = currencies,
            msgSettings = settings.messages,
            onDismiss = { shareTargetTx = null }
        )
    }

    previewImg?.let { (path, txId) ->
        AppImageViewerDialog(
            imagePath = path,
            title = account.name,
            onSaveToGallery = { viewModel.saveImageToGallery(path) },
            onDelete = {
                uiState.snapshot.privateTxs.firstOrNull { it.id == txId }?.let {
                    viewModel.savePrivateTx(it.copy(img = ""))
                }
            },
            onDismiss = { previewImg = null }
        )
    }

    pendingDeleteTx?.let { tx ->
        ConfirmActionDialog(
            title = strings.t("حذف المعاملة", "Delete Transaction"),
            message = strings.t("حذف هذا السند بقيمة ${fmt(tx.amount)}؟", "Delete this voucher (${fmt(tx.amount)})?"),
            confirmText = strings.delete,
            onConfirm = { viewModel.deletePrivateTx(tx.id) },
            onDismiss = { pendingDeleteTx = null }
        )
    }

    pendingDeleteBulk?.let { bulk ->
        ConfirmActionDialog(
            title = strings.t("حذف المعاملات المحددة", "Delete Selected Transactions"),
            message = strings.t("تأكيد حذف (${bulk.size}) معاملة محددة؟", "Delete ${bulk.size} selected transactions?"),
            confirmText = strings.delete,
            onConfirm = {
                viewModel.deletePrivateTxs(bulk.map { it.id })
                selectedIds.clear()
                selectMode = false
            },
            onDismiss = { pendingDeleteBulk = null }
        )
    }

    menuTx?.let { tx ->
        val isSel = tx.id in selectedIds
        val hasImg = rememberFileExists(tx.img)
        AlertDialog(
            onDismissRequest = { menuTx = null },
            title = { Text(strings.t("إجراءات المعاملة", "Voucher Actions"), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DebtMenuActionButton(strings.t("طباعة سند المعاملة", "Print Voucher"), Icons.Default.Print) {
                        val html = PrintReportBuilders.buildPrivateSingleVoucherHtml(
                            account = account,
                            tx = tx,
                            allAccountTxs = allAccountTxsForCur,
                            settings = uiState.settings
                        )
                        viewModel.printHtmlReport(activity, "سند ${account.name}", html, isVoucher = true)
                        menuTx = null
                    }
                    DebtMenuActionButton(strings.t("تعديل المعاملة", "Edit Voucher"), Icons.Default.Edit) {
                        menuTx = null
                        editingTx = tx
                        showVoucherDialog = true
                    }
                    DebtMenuActionButton(
                        strings.t(if (isSel) "إلغاء تحديد المعاملة" else "تحديد المعاملة", if (isSel) "Deselect" else "Select"),
                        Icons.Default.CheckBox
                    ) {
                        selectMode = true
                        if (isSel) selectedIds.remove(tx.id) else selectedIds.add(tx.id)
                        menuTx = null
                    }
                    DebtMenuActionButton(strings.t("تحديد الكل في الحساب الحالي", "Select All in Account"), Icons.Default.SelectAll) {
                        selectMode = true
                        selectedIds.clear()
                        selectedIds.addAll(displayTxs.map { it.id })
                        menuTx = null
                    }
                    DebtMenuActionButton(
                        strings.t(if (hasImg) "فتح الصورة المرفقة" else "إضافة صورة للمعاملة", "Photo"),
                        Icons.Default.Image
                    ) {
                        menuTx = null
                        if (hasImg) {
                            previewImg = tx.img to tx.id
                        } else {
                            attachPhotoTx = tx
                            directPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    }
                    DebtMenuActionButton(strings.t("نقل المعاملة إلى حساب آخر", "Move to Another Account"), Icons.Default.DriveFileMove) {
                        transferTxRequest = listOf(tx) to true
                        menuTx = null
                    }
                    DebtMenuActionButton(strings.t("نسخ المعاملة إلى حساب آخر", "Copy to Another Account"), Icons.Default.ContentCopy) {
                        transferTxRequest = listOf(tx) to false
                        menuTx = null
                    }
                    DebtMenuActionButton(strings.t("حذف المعاملة", "Delete Voucher"), Icons.Default.Delete, isDestructive = true) {
                        menuTx = null
                        pendingDeleteTx = tx
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuTx = null }) { Text(strings.close) } }
        )
    }

    transferTxRequest?.let { (txsToTransfer, isMove) ->
        val folderNames = remember(uiState.snapshot.privateFolders) {
            uiState.snapshot.privateFolders.associate { it.id to it.name }
        }
        val targetAccounts = uiState.snapshot.privateAccounts.filter { it.id != accountId }
        AlertDialog(
            onDismissRequest = { transferTxRequest = null },
            title = {
                Text(
                    strings.t(if (isMove) "نقل المعاملة إلى حساب" else "نسخ المعاملة إلى حساب", "Select Target Account"),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (targetAccounts.isEmpty()) {
                        Text(strings.t("لا توجد حسابات أخرى", "No other accounts available"))
                    } else {
                        targetAccounts.forEach { target ->
                            val fName = folderNames[target.folderId].orEmpty()
                            val label = if (fName.isNotBlank()) "${target.name} ($fName)" else target.name
                            DebtMenuActionButton(label, Icons.Default.Person) {
                                viewModel.copyOrMovePrivateTxs(txsToTransfer, target.id, isMove)
                                selectedIds.clear()
                                selectMode = false
                                transferTxRequest = null
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { transferTxRequest = null }) { Text(strings.close) } }
        )
    }

    pendingSendConfirm?.let { (method, msgText) ->
        val viaLabel = if (method == "sms") "SMS" else strings.t("واتساب", "WhatsApp")
        ConfirmActionDialog(
            title = strings.t("إرسال إشعار ($viaLabel)", "Send Notification ($viaLabel)"),
            message = strings.t("هل تريد إرسال تفاصيل القيد إلى ${account.name} عبر $viaLabel؟", "Send voucher details to ${account.name} via $viaLabel?"),
            confirmText = strings.t("إرسال", "Send"),
            isDestructive = false,
            onConfirm = {
                if (method == "sms") ShareHelper.openSms(context, account.phone, msgText, settings.messages)
                else ShareHelper.openWhatsApp(context, account.phone, msgText, settings.messages)
            },
            onDismiss = { pendingSendConfirm = null }
        )
    }
}

@Composable
private fun PrivateTxActionChip(
    icon: ImageVector,
    contentDescription: String,
    tint: Color,
    onClick: () -> Unit
) {
    val tokens = LocalFrameTokens.current
    Box(
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(tokens.buttonRadius))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.buttonRadius),
            color = tint.copy(alpha = 0.08f),
            border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.55f)),
            modifier = Modifier.size(width = 44.dp, height = 32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = contentDescription,
                    tint = tint,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}
