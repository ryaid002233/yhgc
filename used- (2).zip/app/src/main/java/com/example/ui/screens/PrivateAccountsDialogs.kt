package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.rememberAsyncImagePainter
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.domain.WesternDigits.fmt
import com.example.domain.WesternDigits.num
import com.example.ui.components.*
import com.example.ui.theme.AppColors
import com.example.ui.theme.LocalAppSettings
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import java.util.Locale
import kotlin.math.abs

const val PRIVATE_ALL_CURRENCIES = "*"

fun parsePrivateSend(raw: String): Pair<String, String> {
    if ("|" in raw) {
        val parts = raw.split("|", limit = 2)
        val method = parts.getOrNull(0)?.takeIf { it == "whatsapp" || it == "sms" } ?: "whatsapp"
        val timing = parts.getOrNull(1)?.takeIf { it in listOf("auto", "confirm", "never") } ?: "confirm"
        return method to timing
    }
    val timing = raw.takeIf { it in listOf("auto", "confirm", "never") } ?: "confirm"
    return "whatsapp" to timing
}

fun encodePrivateSend(method: String, timing: String): String = "$method|$timing"

fun privateCurrencySymbol(curName: String, currencies: List<AppCurrency>): String {
    if (curName == PRIVATE_ALL_CURRENCIES || curName.isBlank()) return ""
    return currencies.firstOrNull { it.name == curName }?.symbol ?: curName
}

fun privateBalanceText(net: Double, isEn: Boolean = false): String {
    if (abs(net) < 1e-9) return if (isEn) "Even" else "متعادل"
    return if (net > 0) {
        if (isEn) "Debit ${fmt(net)}" else "عليه ${fmt(net)}"
    } else {
        if (isEn) "Credit ${fmt(-net)}" else "له ${fmt(-net)}"
    }
}

@Composable
fun PrivateFolderEditDialog(
    existing: PrivateFolder?,
    hasAccounts: Boolean,
    viewModel: SmartAdminViewModel,
    onDeleted: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
                BorderStroke(1.5.dp, tokens.borderColor)
            } else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CreateNewFolder,
                        contentDescription = null,
                        tint = tokens.iconTileTint
                    )
                    Text(
                        text = if (existing == null) strings.t("إضافة مجلد", "Add Folder") else strings.t("تعديل مجلد", "Edit Folder"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.t("اسم المجلد", "Folder Name"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    NameSuggestTextField(
                        value = name,
                        onValueChange = { name = it },
                        placeholder = strings.t("ادخل اسم المجلد", "Enter folder name"),
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        testTag = "pa_folder_name_input",
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (existing != null) {
                    OutlinedButton(
                        onClick = {
                            if (hasAccounts) {
                                viewModel.emitMessage(strings.t("انقل حسابات هذا المجلد أو احذفها أولاً", "Move or delete accounts inside this folder first"))
                            } else {
                                confirmDelete = true
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("حذف المجلد", "Delete Folder"), fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.7f)),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text(strings.cancel, fontWeight = FontWeight.Bold)
                    }
                    Surface(
                        onClick = {
                            val trimmed = name.trim()
                            if (trimmed.isBlank()) {
                                viewModel.emitMessage(strings.t("أدخل اسم المجلد", "Enter folder name"))
                                return@Surface
                            }
                            viewModel.savePrivateFolder((existing ?: PrivateFolder()).copy(name = trimmed))
                            onDismiss()
                        },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = Color.Transparent,
                        shadowElevation = tokens.elevation,
                        modifier = Modifier.weight(1f).height(48.dp).testTag("pa_folder_save_btn")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .background(tokens.barBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Save, contentDescription = null, tint = tokens.barContent, modifier = Modifier.size(18.dp))
                                Text(strings.save, color = tokens.barContent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete && existing != null) {
        ConfirmActionDialog(
            title = strings.t("حذف المجلد", "Delete Folder"),
            message = strings.t("تأكيد حذف المجلد (${existing.name})؟", "Delete folder (${existing.name})?"),
            confirmText = strings.delete,
            onConfirm = {
                viewModel.deletePrivateFolder(existing.id)
                onDeleted()
                onDismiss()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
fun PrivateAccountEditDialog(
    folderId: String,
    existing: PrivateAccount?,
    existingInFolder: List<PrivateAccount>,
    defaultSendMethod: String,
    defaultSendTiming: String,
    viewModel: SmartAdminViewModel,
    onDeleted: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current

    val initialPair = remember(existing) {
        if (existing != null) parsePrivateSend(existing.send)
        else (defaultSendMethod.ifBlank { "whatsapp" } to defaultSendTiming.ifBlank { "confirm" })
    }

    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var phone by remember(existing) { mutableStateOf(existing?.phone ?: "") }
    var capEnabled by remember(existing) { mutableStateOf((existing?.cap ?: 0.0) > 0.0) }
    var capStr by remember(existing) {
        mutableStateOf(if ((existing?.cap ?: 0.0) > 0.0) WesternDigits.rawNumberString(existing!!.cap) else "")
    }
    var sendMethod by remember(existing) { mutableStateOf(initialPair.first) }
    var sendTiming by remember(existing) { mutableStateOf(initialPair.second) }
    var confirmDelete by remember { mutableStateOf(false) }

    val contactPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data ?: return@rememberLauncherForActivityResult
        if (res.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.query(
                uri,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                ),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val number = cursor.getString(0).orEmpty().trim()
                    val displayName = cursor.getString(1).orEmpty().trim()
                    if (number.isNotBlank()) phone = WesternDigits.toWestern(number)
                    if (name.isBlank() && displayName.isNotBlank()) name = displayName
                }
            }
        } catch (_: Exception) {
            viewModel.emitMessage(strings.t("تعذر قراءة جهة الاتصال", "Unable to read contact"))
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(16.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled && tokens.frameStyle != "none") {
                BorderStroke(1.5.dp, tokens.borderColor)
            } else null,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = null,
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (existing == null) strings.t("إضافة حساب جديد", "Add New Account") else strings.t("تعديل الحساب", "Edit Account"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // الاسم
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.t("الاسم", "Name"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    NameSuggestTextField(
                        value = name,
                        onValueChange = { name = it },
                        placeholder = strings.t("ادخل الاسم", "Enter name"),
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        testTag = "pa_acc_name_input",
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // رقم الهاتف + زر الأسماء
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.t("رقم الهاتف", "Phone Number"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = WesternDigits.toWestern(it) },
                            placeholder = { Text(strings.t("اختر رقم الهاتف من الأسماء", "Pick phone from contacts"), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            modifier = Modifier.weight(1f).testTag("pa_acc_phone_input")
                        )
                        Surface(
                            onClick = {
                                try {
                                    contactPicker.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                                } catch (_: Exception) {
                                    viewModel.emitMessage(strings.t("اختيار جهات الاتصال غير متاح", "Contacts picker unavailable"))
                                }
                            },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            color = Color.Transparent,
                            modifier = Modifier.size(52.dp).testTag("pa_acc_contacts_btn")
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(tokens.barBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Group,
                                    contentDescription = strings.t("جهات الاتصال", "Contacts"),
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }

                // إضافة سقف مديونية
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(tokens.buttonRadius))
                        .clickable { capEnabled = !capEnabled }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.t("إضافة سقف مديونية", "Add Debt Cap"),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Checkbox(
                        checked = capEnabled,
                        onCheckedChange = { capEnabled = it }
                    )
                }

                if (capEnabled) {
                    WesternNumberField(
                        value = capStr,
                        onValueChange = { capStr = it },
                        label = strings.t("مبلغ السقف", "Cap Amount"),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // طريقة إرسال الرسائل
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.t("طريقة إرسال الرسائل", "Message Method"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Surface(
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        border = BorderStroke(1.5.dp, tokens.borderColor.copy(alpha = 0.85f)),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            listOf("whatsapp" to strings.t("واتساب", "WhatsApp"), "sms" to "SMS").forEach { (key, lbl) ->
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { sendMethod = key }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = sendMethod == key, onClick = { sendMethod = key })
                                    Text(lbl, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                // إرسال الرسائل
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.t("إرسال الرسائل", "Send Timing"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Surface(
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        border = BorderStroke(1.5.dp, tokens.borderColor.copy(alpha = 0.85f)),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            listOf(
                                "auto" to strings.t("تلقائي", "Auto"),
                                "confirm" to strings.t("بعد التأكيد", "Confirm"),
                                "never" to strings.t("لا ترسل", "Never")
                            ).forEach { (key, lbl) ->
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { sendTiming = key }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = sendTiming == key, onClick = { sendTiming = key })
                                    Text(lbl, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                }
                            }
                        }
                    }
                }

                if (existing != null) {
                    OutlinedButton(
                        onClick = { confirmDelete = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("حذف الحساب", "Delete Account"), fontWeight = FontWeight.Bold)
                    }
                }

                // أزرار الحفظ والإلغاء
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = {
                            val trimmed = name.trim()
                            if (trimmed.isBlank()) {
                                viewModel.emitMessage(strings.t("أدخل الاسم", "Enter name"))
                                return@Surface
                            }
                            val capVal = if (capEnabled) num(capStr) else 0.0
                            if (capEnabled && capVal <= 0.0) {
                                viewModel.emitMessage(strings.t("أدخل سقفاً أكبر من صفر", "Enter cap greater than 0"))
                                return@Surface
                            }
                            if (existingInFolder.any { it.name == trimmed && it.id != existing?.id }) {
                                viewModel.emitMessage(strings.t("يوجد حساب بنفس الاسم في هذا المجلد", "An account with this name already exists in this folder"))
                                return@Surface
                            }
                            val acc = (existing ?: PrivateAccount(folderId = folderId)).copy(
                                name = trimmed,
                                phone = phone.trim(),
                                cap = capVal,
                                send = encodePrivateSend(sendMethod, sendTiming)
                            )
                            viewModel.savePrivateAccount(acc)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = Color.Transparent,
                        shadowElevation = tokens.elevation,
                        modifier = Modifier.weight(1f).height(48.dp).testTag("pa_acc_save_btn")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .background(tokens.barBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Save, contentDescription = null, tint = tokens.barContent, modifier = Modifier.size(18.dp))
                                Text(strings.save, color = tokens.barContent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text(strings.cancel, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (confirmDelete && existing != null) {
        ConfirmActionDialog(
            title = strings.t("حذف الحساب", "Delete Account"),
            message = strings.t("نقل حساب (${existing.name}) وكل معاملاته إلى سلة المحذوفات؟", "Move account (${existing.name}) to Trash?"),
            confirmText = strings.delete,
            onConfirm = {
                viewModel.deletePrivateAccount(existing)
                onDeleted()
                onDismiss()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

@Composable
fun PrivateVoucherDialog(
    account: PrivateAccount,
    existing: PrivateTx?,
    initialCurrency: String,
    allAccountTxs: List<PrivateTx>,
    currencies: List<AppCurrency>,
    defaultCurrency: String,
    viewModel: SmartAdminViewModel,
    onSaved: (savedTx: PrivateTx, newBalanceForCurrency: Double) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val settings = LocalAppSettings.current
    val tokens = LocalFrameTokens.current

    val resolvedInitialCur = remember(existing, initialCurrency, currencies, defaultCurrency) {
        existing?.currency?.takeIf { it.isNotBlank() }
            ?: initialCurrency.takeIf { it.isNotBlank() && it != PRIVATE_ALL_CURRENCIES }
            ?: currencies.firstOrNull()?.name
            ?: defaultCurrency
    }

    var selectedCur by remember { mutableStateOf(resolvedInitialCur) }
    var curDropdownOpen by remember { mutableStateOf(false) }
    var txDate by remember { mutableStateOf(existing?.date?.ifBlank { DateHelper.todayIso() } ?: DateHelper.todayIso()) }
    var txTime by remember { mutableStateOf(existing?.time?.ifBlank { DateHelper.nowTime() } ?: DateHelper.nowTime()) }
    var amtStr by remember { mutableStateOf(if (existing != null) WesternDigits.rawNumberString(existing.amount) else "") }
    var txType by remember { mutableStateOf(existing?.type ?: "عليه") }
    var imgPath by remember { mutableStateOf(existing?.img ?: "") }

    val noteLines = remember {
        mutableStateListOf<String>().apply {
            val ls = existing?.lines.orEmpty().filter { it.isNotBlank() }
            if (ls.isEmpty()) add("") else addAll(ls)
        }
    }

    var showDatePicker by remember { mutableStateOf(false) }
    var showCalc by remember { mutableStateOf(false) }
    var showCapConfirm by remember { mutableStateOf(false) }
    var voiceTarget by remember { mutableStateOf("amount") } // "amount" or "note"

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.saveImageFromUri(uri) { imgPath = it }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty().trim()
        if (spoken.isBlank()) return@rememberLauncherForActivityResult
        if (voiceTarget == "amount") {
            val cleaned = WesternDigits.cleanNumericInput(spoken)
            if (cleaned.isNotBlank()) amtStr = cleaned
            else viewModel.emitMessage(strings.t("لم يتم التعرف على رقم", "No number recognized"))
        } else {
            noteLines[0] = if (noteLines[0].isBlank()) spoken else "${noteLines[0]} $spoken"
        }
    }

    fun startSpeech(target: String) {
        voiceTarget = target
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (settings.lang == "en") "en-US" else "ar")
                putExtra(RecognizerIntent.EXTRA_PROMPT, strings.t("تحدث الآن...", "Speak now..."))
            }
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            viewModel.emitMessage(strings.t("الإدخال الصوتي غير متوفر على هذا الجهاز", "Voice input unavailable"))
        }
    }

    val curBal = remember(allAccountTxs, selectedCur) {
        allAccountTxs.filter { it.currency == selectedCur }
            .sumOf { if (it.type == "عليه") it.amount else -it.amount }
    }
    val curSymbol = privateCurrencySymbol(selectedCur, currencies)
    val amtVal = num(amtStr)

    fun commitSave() {
        val cleanLines = noteLines
            .flatMap { it.split('\n') }
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val tx = (existing ?: PrivateTx(accountId = account.id)).copy(
            accountId = account.id,
            currency = selectedCur,
            date = txDate.trim().ifBlank { DateHelper.todayIso() },
            time = txTime.trim().ifBlank { DateHelper.nowTime() },
            amount = amtVal,
            type = txType,
            lines = cleanLines,
            img = imgPath
        )
        viewModel.savePrivateTx(tx)
        val otherBal = allAccountTxs
            .filter { it.currency == selectedCur && it.id != existing?.id }
            .sumOf { if (it.type == "عليه") it.amount else -it.amount }
        val updatedBal = otherBal + (if (txType == "عليه") amtVal else -amtVal)
        onSaved(tx, updatedBal)
        onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.5.dp, tokens.borderColor),
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.93f)
                .widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Dark Header: سند جديد + التاريخ + ترس الإعدادات
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(tokens.barBrush)
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (existing == null) strings.t("سند جديد", "New Voucher") else strings.t("تعديل سند", "Edit Voucher"),
                        color = tokens.barContent,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = { showDatePicker = true },
                            shape = RoundedCornerShape(8.dp),
                            color = tokens.barButtonBg,
                            border = BorderStroke(1.dp, tokens.barDivider.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = DateHelper.displaySlash(txDate),
                                color = tokens.barContent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                        Surface(
                            onClick = {
                                viewModel.emitMessage(strings.t("عليه = دين، له = سداد", "Debit = عليه, Credit = له"))
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = tokens.barButtonBg,
                            border = BorderStroke(1.dp, tokens.barAccent.copy(alpha = 0.7f)),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Settings, contentDescription = strings.settings, tint = tokens.barAccent, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                // الرصيد الحالي في شريط أسود دائري الحواف
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(tokens.barBrush)
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${strings.t("الرصيد", "Balance")} ${privateBalanceText(curBal, settings.lang == "en")} $curSymbol",
                            color = tokens.barContent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Text(
                    text = strings.t("أدخل المبلغ", "Enter Amount"),
                    color = AppColors.GoldAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                // صف المبلغ: العملة + حقل المبلغ + مايك + حاسبة
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        Surface(
                            onClick = { curDropdownOpen = true },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.85f)),
                            modifier = Modifier.widthIn(min = 84.dp, max = 118.dp).height(44.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "$selectedCur ($curSymbol)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }
                        DropdownMenu(expanded = curDropdownOpen, onDismissRequest = { curDropdownOpen = false }) {
                            currencies.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.name} (${c.symbol})") },
                                    onClick = { selectedCur = c.name; curDropdownOpen = false }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amtStr,
                        onValueChange = { amtStr = WesternDigits.cleanNumericInput(it) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("pa_voucher_amount_input")
                    )

                    Surface(
                        onClick = { startSpeech("amount") },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Mic, contentDescription = strings.t("إدخال صوتي", "Voice Input"), modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Surface(
                        onClick = { showCalc = true },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.size(40.dp).testTag("pa_voucher_calc_btn")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Calculate, contentDescription = strings.calculator, modifier = Modifier.size(18.dp), tint = AppColors.DebitRed)
                        }
                    }
                }

                // تلميح محلي تحت المبلغ
                Text(
                    text = if (amtVal > 0.0) "${fmt(amtVal)} $curSymbol" else strings.t("صفر محلي", "Zero local"),
                    color = AppColors.DebitRed.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp)
                )

                // صف البيان: مايك + حقل متعدد الأسطر + كاميرا
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = { startSpeech("note") },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Mic, contentDescription = strings.t("إملاء صوتي", "Dictate Note"), modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    OutlinedTextField(
                        value = noteLines.firstOrNull() ?: "",
                        onValueChange = { if (noteLines.isEmpty()) noteLines.add(it) else noteLines[0] = it },
                        placeholder = { Text(strings.t("اكتب البيان ويمكنك إضافة عدة سطور", "Enter statement (multi-line)"), fontSize = 12.sp) },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("pa_voucher_note_input")
                    )

                    Surface(
                        onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (imgPath.isNotBlank()) AppColors.CreditGreenContainerLight else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (imgPath.isNotBlank()) AppColors.CreditGreen else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.size(40.dp).testTag("pa_voucher_cam_btn")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.PhotoCamera,
                                contentDescription = strings.t("إرفاق صورة", "Attach Photo"),
                                modifier = Modifier.size(18.dp),
                                tint = if (imgPath.isNotBlank()) AppColors.CreditGreen else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // سطور البيان الإضافية
                noteLines.drop(1).forEachIndexed { offsetIdx, extra ->
                    val realIdx = offsetIdx + 1
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = extra,
                            onValueChange = { noteLines[realIdx] = it },
                            placeholder = { Text(strings.t("بيان جديد", "Additional line"), fontSize = 12.sp) },
                            minLines = 1,
                            maxLines = 3,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        )
                        FilledTonalButton(
                            onClick = { noteLines.removeAt(realIdx) },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = AppColors.DebitRedContainerLight,
                                contentColor = AppColors.DebitRed
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 40.dp)
                        ) {
                            Text(strings.delete, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                // أدوات البيان: + إضافة سطر + ملاحظة
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = { noteLines.add("") },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.heightIn(min = 36.dp)
                    ) {
                        Text(strings.t("+ إضافة سطر", "+ Add Line"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = strings.t("يمكنك كتابة أكثر من سطر في البيان", "Multi-line description supported"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // معاينة الصورة المرفقة إن وجدت
                if (rememberFileExists(imgPath)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                            .padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Image(
                            painter = rememberThumbnailPainter(imgPath, maxSizePx = 180),
                            contentDescription = strings.t("صورة السند", "Voucher Image"),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(6.dp))
                        )
                        Text(strings.t("تم إرفاق صورة", "Photo attached"), style = MaterialTheme.typography.labelMedium, color = AppColors.CreditGreen)
                        IconButton(onClick = { imgPath = "" }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Close, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }

                // صف اختيار النوع: له / عليه / شرح
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { txType = "له" }.padding(horizontal = 6.dp)
                        ) {
                            RadioButton(
                                selected = txType == "له",
                                onClick = { txType = "له" },
                                colors = RadioButtonDefaults.colors(selectedColor = AppColors.CreditGreen)
                            )
                            Text(
                                text = strings.t("لـه", "Credit"),
                                color = AppColors.CreditGreen,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { txType = "عليه" }.padding(horizontal = 6.dp)
                        ) {
                            RadioButton(
                                selected = txType == "عليه",
                                onClick = { txType = "عليه" },
                                colors = RadioButtonDefaults.colors(selectedColor = AppColors.DebitRed)
                            )
                            Text(
                                text = strings.t("عليه", "Debit"),
                                color = AppColors.DebitRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }

                        Spacer(Modifier.width(8.dp))

                        Surface(
                            onClick = {
                                viewModel.emitMessage(strings.t("عليه = دين على العميل، له = سداد من العميل", "Debit (عليه) = owed to you, Credit (له) = payment"))
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFD93025),
                            modifier = Modifier.heightIn(min = 34.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF8A80)))
                                Text(strings.t("شرح", "Help"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // أزرار الحفظ والإلغاء
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        onClick = {
                            if (amtVal <= 0.0) {
                                viewModel.emitMessage(strings.t("أدخل المبلغ", "Enter amount"))
                                return@Surface
                            }
                            val otherBal = allAccountTxs
                                .filter { it.currency == selectedCur && it.id != existing?.id }
                                .sumOf { if (it.type == "عليه") it.amount else -it.amount }
                            val projected = otherBal + (if (txType == "عليه") amtVal else -amtVal)
                            if (account.cap > 0.0 && projected > account.cap) {
                                showCapConfirm = true
                            } else {
                                commitSave()
                            }
                        },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = Color.Transparent,
                        modifier = Modifier.widthIn(min = 110.dp).heightIn(min = 44.dp).testTag("pa_voucher_save_btn")
                    ) {
                        Box(
                            modifier = Modifier
                                .background(tokens.barBrush)
                                .padding(horizontal = 24.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(strings.save, color = tokens.barContent, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        modifier = Modifier.widthIn(min = 110.dp).heightIn(min = 44.dp)
                    ) {
                        Text(strings.cancel, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        AppDatePickerDialog(
            initialIso = txDate,
            onPicked = { txDate = it; showDatePicker = false },
            onDismiss = { showDatePicker = false }
        )
    }

    if (showCalc) {
        CalculatorDialog(
            initialValue = amtStr,
            onResult = { amtStr = it },
            onDismiss = { showCalc = false }
        )
    }

    if (showCapConfirm) {
        ConfirmActionDialog(
            title = strings.t("تجاوز سقف المديونية", "Debt Cap Exceeded"),
            message = strings.t("المعاملة تتجاوز سقف المديونية المحدد (${fmt(account.cap)}). هل تريد المتابعة؟", "Transaction exceeds debt cap (${fmt(account.cap)}). Continue?"),
            confirmText = strings.confirm,
            isDestructive = false,
            onConfirm = { commitSave() },
            onDismiss = { showCapConfirm = false }
        )
    }
}

@Composable
fun PrivateStatsDialog(
    foldersCount: Int,
    accounts: List<PrivateAccount>,
    txs: List<PrivateTx>,
    currencies: List<AppCurrency>,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val usedCurs = remember(txs, currencies) {
        val seen = txs.map { it.currency }.filter { it.isNotBlank() }.toSet()
        val ordered = currencies.map { it.name }.filter { it in seen }.toMutableList()
        seen.forEach { if (it !in ordered) ordered.add(it) }
        ordered
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled) BorderStroke(1.5.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.BarChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(strings.t("الإحصائيات", "Statistics"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }

                Surface(
                    shape = RoundedCornerShape(tokens.cornerRadius),
                    border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.6f)),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.t("$foldersCount مجلد — ${accounts.size} حساب", "$foldersCount Folders — ${accounts.size} Accounts"),
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                if (usedCurs.isEmpty()) {
                    Text(strings.t("لا توجد حركات بعد", "No transactions yet"), style = MaterialTheme.typography.bodySmall)
                } else {
                    usedCurs.forEach { c ->
                        var owedUs = 0.0
                        var weOwe = 0.0
                        accounts.forEach { acc ->
                            val b = txs.filter { it.accountId == acc.id && it.currency == c }
                                .sumOf { if (it.type == "عليه") it.amount else -it.amount }
                            if (b > 1e-9) owedUs += b else weOwe -= b
                        }
                        Surface(
                            shape = RoundedCornerShape(tokens.cornerRadius),
                            border = BorderStroke(1.dp, tokens.borderColor.copy(alpha = 0.6f)),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("$c (${privateCurrencySymbol(c, currencies)})", fontWeight = FontWeight.Black)
                                Text(
                                    "${strings.t("الإجمالي لكم", "Total Credit")}: ${fmt(owedUs)}",
                                    color = AppColors.CreditGreen,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "${strings.t("الإجمالي عليكم", "Total Debit")}: ${fmt(weOwe)}",
                                    color = AppColors.DebitRed,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                ) {
                    Text(strings.close, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PrivateQuickSearchDialog(
    folders: List<PrivateFolder>,
    accounts: List<PrivateAccount>,
    txs: List<PrivateTx>,
    defaultCurrency: String,
    currencies: List<AppCurrency>,
    onSelectAccount: (PrivateAccount) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var query by remember { mutableStateOf("") }
    val folderNames = remember(folders) { folders.associate { it.id to it.name } }
    val matches = remember(accounts, query) {
        val q = query.trim()
        accounts.filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(q) }.sortedBy { it.name }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled) BorderStroke(1.5.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(strings.t("البحث السريع", "Quick Search"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(strings.t("اسم الحساب أو رقم الهاتف", "Account name or phone")) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    modifier = Modifier.fillMaxWidth()
                )

                Column(
                    modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (matches.isEmpty()) {
                        Text(
                            text = strings.t("لا توجد نتائج", "No results"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(12.dp)
                        )
                    } else {
                        matches.forEach { acc ->
                            val sym = privateCurrencySymbol(defaultCurrency, currencies)
                            val net = txs.filter { it.accountId == acc.id && it.currency == defaultCurrency }
                                .sumOf { if (it.type == "عليه") it.amount else -it.amount }
                            Surface(
                                onClick = {
                                    onDismiss()
                                    onSelectAccount(acc)
                                },
                                shape = RoundedCornerShape(tokens.cornerRadius),
                                border = BorderStroke(1.2.dp, tokens.borderColor.copy(alpha = 0.7f)),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(tokens.darkTileBrush),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = acc.name.trim().firstOrNull()?.toString() ?: "؟",
                                            color = tokens.darkTileContent,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(acc.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            listOfNotNull(folderNames[acc.folderId], acc.phone.takeIf { it.isNotBlank() }).joinToString(" • "),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "${privateBalanceText(net)} $sym",
                                        fontWeight = FontWeight.Bold,
                                        color = if (abs(net) < 1e-9) MaterialTheme.colorScheme.onSurfaceVariant else if (net > 0) AppColors.CreditGreen else AppColors.DebitRed,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                ) {
                    Text(strings.close, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PrivateCurrencyManagerDialog(
    selectedCurrency: String,
    currencies: List<AppCurrency>,
    onSelectCurrency: (String) -> Unit,
    onOpenCurrencySettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    var tempCur by remember(selectedCurrency) { mutableStateOf(selectedCurrency) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled) BorderStroke(1.5.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CurrencyExchange, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(strings.t("إدارة العملات", "Manage Currencies"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }

                Text(
                    strings.t("العملة المعروضة", "Displayed Currency"),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    border = BorderStroke(1.5.dp, tokens.borderColor.copy(alpha = 0.8f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(6.dp)) {
                        val opts = listOf(PRIVATE_ALL_CURRENCIES to strings.t("كل العملات", "All Currencies")) +
                            currencies.map { it.name to "${it.name} (${it.symbol})" }
                        opts.forEach { (key, lbl) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { tempCur = key }
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = tempCur == key, onClick = { tempCur = key })
                                Text(lbl, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onOpenCurrencySettings()
                    },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.t("تعديل قائمة العملات", "Edit Currencies List"), fontWeight = FontWeight.Bold)
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(strings.cancel, fontWeight = FontWeight.Bold) }

                    Surface(
                        onClick = {
                            onSelectCurrency(tempCur)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = Color.Transparent,
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(48.dp).background(tokens.barBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(strings.t("تطبيق", "Apply"), color = tokens.barContent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivateTransferDialog(
    sourceAccount: PrivateAccount,
    allAccounts: List<PrivateAccount>,
    folders: List<PrivateFolder>,
    currencies: List<AppCurrency>,
    initialCurrency: String,
    viewModel: SmartAdminViewModel,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val folderNames = remember(folders) { folders.associate { it.id to it.name } }
    val otherAccounts = remember(allAccounts, sourceAccount.id) {
        allAccounts.filter { it.id != sourceAccount.id }
    }

    var targetId by remember { mutableStateOf(otherAccounts.firstOrNull()?.id ?: "") }
    var targetMenuOpen by remember { mutableStateOf(false) }
    var selectedCur by remember {
        mutableStateOf(
            initialCurrency.takeIf { it.isNotBlank() && it != PRIVATE_ALL_CURRENCIES }
                ?: currencies.firstOrNull()?.name
                ?: "ريال يمني"
        )
    }
    var curMenuOpen by remember { mutableStateOf(false) }
    var amtStr by remember { mutableStateOf("") }
    var trType by remember { mutableStateOf("عليه") }
    var note by remember { mutableStateOf("") }
    var showCalc by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled) BorderStroke(1.5.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(strings.t("قيد إلى حساب", "Transfer Between Accounts"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }

                Text(
                    text = "${strings.from}: ${sourceAccount.name}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                if (otherAccounts.isEmpty()) {
                    Text(strings.t("لا يوجد حساب آخر للقيد إليه", "No other account available"))
                } else {
                    val target = otherAccounts.firstOrNull { it.id == targetId }
                    val targetLbl = target?.let {
                        val f = if (it.folderId != sourceAccount.folderId) " — ${folderNames[it.folderId] ?: ""}" else ""
                        "${it.name}$f"
                    } ?: ""
                    Box {
                        OutlinedButton(
                            onClick = { targetMenuOpen = true },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                        ) {
                            Text("${strings.to}: $targetLbl", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = targetMenuOpen, onDismissRequest = { targetMenuOpen = false }) {
                            otherAccounts.forEach { acc ->
                                val f = if (acc.folderId != sourceAccount.folderId) " — ${folderNames[acc.folderId] ?: ""}" else ""
                                DropdownMenuItem(
                                    text = { Text("${acc.name}$f") },
                                    onClick = { targetId = acc.id; targetMenuOpen = false }
                                )
                            }
                        }
                    }

                    WesternNumberField(
                        value = amtStr,
                        onValueChange = { amtStr = it },
                        label = strings.amount,
                        trailingIcon = {
                            IconButton(onClick = { showCalc = true }) {
                                Icon(Icons.Default.Calculate, contentDescription = strings.calculator)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Box {
                        OutlinedButton(
                            onClick = { curMenuOpen = true },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                        ) {
                            Text("${strings.t("العملة", "Currency")}: $selectedCur (${privateCurrencySymbol(selectedCur, currencies)})", modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = curMenuOpen, onDismissRequest = { curMenuOpen = false }) {
                            currencies.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.name} (${c.symbol})") },
                                    onClick = { selectedCur = c.name; curMenuOpen = false }
                                )
                            }
                        }
                    }

                    Text(
                        strings.t("القيد على الحساب الحالي", "Entry on current account"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        border = BorderStroke(1.2.dp, tokens.borderColor.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                            listOf("عليه", "له").forEach { key ->
                                Row(
                                    modifier = Modifier.weight(1f).clickable { trType = key },
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = trType == key, onClick = { trType = key })
                                    Text(key, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text(strings.t("البيان", "Details")) },
                        placeholder = { Text(strings.t("قيد بين الحسابات", "Inter-account transfer")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text(strings.cancel, fontWeight = FontWeight.Bold) }

                    if (otherAccounts.isNotEmpty()) {
                        Surface(
                            onClick = {
                                val a = num(amtStr)
                                val targetAcc = otherAccounts.firstOrNull { it.id == targetId }
                                if (a <= 0.0) {
                                    viewModel.emitMessage(strings.t("أدخل مبلغاً صحيحاً", "Enter valid amount"))
                                    return@Surface
                                }
                                if (targetAcc != null) {
                                    viewModel.savePrivateTransfer(sourceAccount, targetAcc, selectedCur, a, trType, note.trim())
                                    onDismiss()
                                }
                            },
                            shape = RoundedCornerShape(tokens.buttonRadius),
                            color = Color.Transparent,
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxWidth().height(48.dp).background(tokens.barBrush),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(strings.t("حفظ القيد", "Save Transfer"), color = tokens.barContent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCalc) {
        CalculatorDialog(initialValue = amtStr, onResult = { amtStr = it }, onDismiss = { showCalc = false })
    }
}

@Composable
fun PrivateShareTxDialog(
    account: PrivateAccount,
    tx: PrivateTx,
    runningBalanceAfter: Double,
    currencies: List<AppCurrency>,
    msgSettings: MessageSettings,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val tokens = LocalFrameTokens.current
    val sym = privateCurrencySymbol(tx.currency, currencies)
    val text = remember(account, tx, runningBalanceAfter, sym) {
        buildList {
            add("سند: ${account.name}")
            add("النوع: ${tx.type}")
            add("المبلغ: ${fmt(tx.amount)} $sym")
            add("التاريخ: ${DateHelper.displaySlash(tx.date)}${if (tx.time.isNotBlank()) " ${tx.time}" else ""}")
            if (tx.lines.isNotEmpty()) add("البيان: ${tx.lines.joinToString(" • ")}")
            add("الرصيد: ${privateBalanceText(runningBalanceAfter)} $sym")
        }.joinToString("\n")
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(tokens.cornerRadius.coerceAtLeast(14.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = if (tokens.frameEnabled) BorderStroke(1.5.dp, tokens.borderColor) else null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(strings.t("إرسال المعاملة", "Send Transaction"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }

                OutlinedButton(
                    onClick = {
                        ShareHelper.shareText(context, "سند ${account.name}", text)
                        onDismiss()
                    },
                    shape = RoundedCornerShape(tokens.buttonRadius),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.t("مشاركة كنص", "Share as Text"), fontWeight = FontWeight.Bold)
                }

                if (account.phone.isNotBlank()) {
                    Surface(
                        onClick = {
                            val (method, _) = parsePrivateSend(account.send)
                            if (method == "sms") ShareHelper.openSms(context, account.phone, text, msgSettings)
                            else ShareHelper.openWhatsApp(context, account.phone, text, msgSettings)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        color = Color.Transparent,
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxWidth().height(48.dp).background(tokens.barBrush), contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Chat, contentDescription = null, tint = tokens.barAccent, modifier = Modifier.size(18.dp))
                                Text(strings.t("إرسال واتساب", "Send via WhatsApp"), color = tokens.barContent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (rememberFileExists(tx.img)) {
                    OutlinedButton(
                        onClick = {
                            ShareHelper.shareImage(context, tx.img, "صورة السند")
                            onDismiss()
                        },
                        shape = RoundedCornerShape(tokens.buttonRadius),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.t("الصورة المرفقة", "Attached Image"), fontWeight = FontWeight.Bold)
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(strings.cancel) }
            }
        }
    }
}
