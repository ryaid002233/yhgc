package com.example.ui.navigation

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import coil.compose.rememberAsyncImagePainter
import com.example.data.ShareHelper
import com.example.domain.*
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.LocalAppStrings
import com.example.ui.theme.LocalFrameTokens
import com.example.ui.theme.LocalOnRemoveSavedName
import com.example.ui.theme.LocalSavedNames
import com.example.ui.viewmodel.SmartAdminUiState
import com.example.ui.viewmodel.SmartAdminViewModel
import java.io.File
import kotlin.math.abs
import kotlinx.coroutines.launch

object AppRoutes {
    const val HOME = "home"
    const val PRIVATE = "private"
    const val BUYER = "buyer"

    const val FOLDERS_HOME = "folders_home"
    const val FOLDERS_BUYER = "folders_buyer"
    const val FOLDER_DETAIL = "folder_detail/{folderId}"
    const val SELLER_INVOICE = "seller_invoice/{folderId}?invoiceId={invoiceId}"
    const val BUYER_INVOICE = "buyer_invoice/{folderId}?invoiceId={invoiceId}"
    const val WEEKLY_FILTERS = "weekly_filters"
    const val WEEKLY_EDITOR = "weekly_editor/{filterId}"
    const val DETAILS_LIST = "details_list"
    const val DETAIL_EDITOR = "detail_editor/{detailId}"
    const val CLOCK_SECTION = "clock_section/{sectionKey}"
    const val DEBT_CASHBOXES = "debt_cashboxes"
    const val AUTO_DEBT_BOX = "auto_debt_box"
    const val DEBT_ACCOUNTS = "debt_accounts/{cashboxId}"
    const val DEBT_LEDGER = "debt_ledger/{accountId}"
    const val TASFEER = "tasfeer"
    const val PRIVATE_FOLDER_ACCOUNTS = "private_folder/{folderId}"
    const val PRIVATE_STATEMENT = "private_statement/{accountId}"
    const val BUYER_TRANSFER = "buyer_transfer"
    const val BUYER_ANNUAL = "buyer_annual"
    const val BUYER_CONTROLLER = "buyer_controller/{mode}"
    const val SETTINGS = "settings?section={section}"

    fun folderDetail(folderId: String) = "folder_detail/${Uri.encode(folderId)}"
    fun sellerInvoice(folderId: String, invoiceId: String? = null) =
        "seller_invoice/${Uri.encode(folderId)}" + (if (invoiceId != null) "?invoiceId=${Uri.encode(invoiceId)}" else "")
    fun buyerInvoice(folderId: String, invoiceId: String? = null) =
        "buyer_invoice/${Uri.encode(folderId)}" + (if (invoiceId != null) "?invoiceId=${Uri.encode(invoiceId)}" else "")
    fun weeklyEditor(filterId: String) = "weekly_editor/${Uri.encode(filterId)}"
    fun detailEditor(detailId: String) = "detail_editor/${Uri.encode(detailId)}"
    fun clockSection(sec: ClockSection) = "clock_section/${sec.key}"
    fun debtAccounts(boxId: String) = "debt_accounts/${Uri.encode(boxId)}"
    fun debtLedger(accId: String) = "debt_ledger/${Uri.encode(accId)}"
    fun privateFolder(folderId: String) = "private_folder/${Uri.encode(folderId)}"
    fun privateStatement(accId: String) = "private_statement/${Uri.encode(accId)}"
    fun buyerController(mode: String) = "buyer_controller/$mode"
    fun settings(section: String = "hub") = "settings?section=${Uri.encode(section)}"
}

@Composable
fun SmartAdminRootApp(
    uiState: SmartAdminUiState,
    viewModel: SmartAdminViewModel,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit
) {
    val strings = LocalAppStrings.current
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.toastEvent.collect { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val bottomPagerState = rememberPagerState(initialPage = 0, pageCount = { 3 })
    val slidingDoorAnimSpec = remember {
        tween<Float>(
            durationMillis = 420,
            easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
        )
    }
    var activeDebtsHeroKey by remember { mutableStateOf("hero_clock_debts") }
    var activeTasfeerHeroKey by remember { mutableStateOf("hero_tasfeer_clock") }

    val activeBottomRoute = when (currentRoute) {
        AppRoutes.HOME -> when (bottomPagerState.currentPage) {
            1 -> AppRoutes.PRIVATE
            2 -> AppRoutes.BUYER
            else -> AppRoutes.HOME
        }
        else -> currentRoute
    }
    val showBottomBar = currentRoute in setOf(
        AppRoutes.HOME,
        AppRoutes.PRIVATE_FOLDER_ACCOUNTS,
        AppRoutes.PRIVATE_STATEMENT
    )

    val context = LocalContext.current
    val activity = remember(context) {
        var ctx: Context = context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) break
            ctx = ctx.baseContext
        }
        ctx as? Activity
    }
    var showExitBackupDialog by remember { mutableStateOf(false) }
    val exitBackupAuthLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        viewModel.handleGoogleDriveResolutionResult(activity, result.data)
    }
    val exitNotificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.startExitBackupAndFinish(
            activity = activity,
            onNeedResolution = { req -> exitBackupAuthLauncher.launch(req) },
            onReadyToExit = { activity?.finish() }
        )
    }

    var activeDrawerSettingsSection by remember { mutableStateOf<String?>(null) }
    val isDrawerClosed by remember { derivedStateOf { drawerState.isClosed } }
    val isDrawerOpen by remember { derivedStateOf { drawerState.isOpen } }

    LaunchedEffect(isDrawerClosed) {
        if (isDrawerClosed) {
            activeDrawerSettingsSection = null
        }
    }

    if (currentRoute == AppRoutes.HOME && bottomPagerState.currentPage != 0 && isDrawerClosed && activeDrawerSettingsSection == null) {
        BackHandler {
            scope.launch {
                bottomPagerState.animateScrollToPage(0, animationSpec = slidingDoorAnimSpec)
            }
        }
    } else if (currentRoute == AppRoutes.HOME && bottomPagerState.currentPage == 0 && uiState.settings.gdriveBackup.backupOnExit && isDrawerClosed && activeDrawerSettingsSection == null) {
        BackHandler {
            showExitBackupDialog = true
        }
    }

    CompositionLocalProvider(
        LocalSavedNames provides uiState.savedNames,
        LocalOnRemoveSavedName provides viewModel::removeSavedName
    ) {
    AppBackgroundLayer {
        val tokens = LocalFrameTokens.current
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = showBottomBar && activeDrawerSettingsSection == null,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = MaterialTheme.colorScheme.background,
                    windowInsets = WindowInsets(0, 0, 0, 0),
                    modifier = Modifier.widthIn(max = 340.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AnimatedContent(
                            targetState = activeDrawerSettingsSection,
                            transitionSpec = {
                                (fadeIn(tween(200)) + slideInVertically(tween(200)) { -it / 10 }) togetherWith
                                    (fadeOut(tween(150)) + slideOutVertically(tween(150)) { -it / 10 })
                            },
                            label = "drawer_settings_branch",
                            modifier = Modifier.fillMaxSize()
                        ) { activeSec ->
                            if (activeSec != null) {
                                BackHandler(enabled = isDrawerOpen) {
                                    activeDrawerSettingsSection = null
                                }
                                SettingsDrawerBranchContent(
                                    section = activeSec,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onExportBackup = onExportBackup,
                                    onImportBackup = onImportBackup,
                                    onSelectSection = { activeDrawerSettingsSection = it },
                                    onBack = { activeDrawerSettingsSection = null }
                                )
                            } else {
                                Column(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(tokens.barBrush)
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = strings.settings,
                                    color = tokens.barContent,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = strings.t("تخصيص التطبيق", "App Customization"),
                                    color = tokens.barAccent,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(tokens.buttonRadius),
                                color = tokens.barButtonBg,
                                border = if (tokens.frameEnabled && tokens.frameStyle != "none") BorderStroke(1.dp, tokens.barDivider) else null,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = null,
                                        tint = tokens.barAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                    if (tokens.frameEnabled && tokens.frameStyle != "none") {
                        HorizontalDivider(thickness = 1.5.dp, color = tokens.barDivider)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .navigationBarsPadding()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Person,
                            title = strings.t("الملف الشخصي", "Profile & Branding"),
                            iconTint = Color(0xFF0284C7),
                            onClick = { activeDrawerSettingsSection = "profile" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.AutoAwesome,
                            title = strings.t("التخصيص", "Specialties"),
                            iconTint = Color(0xFFEAB308),
                            onClick = { activeDrawerSettingsSection = "specialties" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.ShoppingBag,
                            title = strings.t("تخصيص الشرائي", "Buyer Specialties"),
                            iconTint = Color(0xFF10B981),
                            onClick = { activeDrawerSettingsSection = "buyer_specialties" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Language,
                            title = strings.t("اللغة ومظهر التطبيق", "Language & Theme"),
                            iconTint = Color(0xFF0284C7),
                            onClick = { activeDrawerSettingsSection = "appearance" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.MonetizationOn,
                            title = strings.currencies,
                            iconTint = Color(0xFFD97706),
                            onClick = { activeDrawerSettingsSection = "currencies" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Recycling,
                            title = strings.t("سلة المحذوفات (${uiState.snapshot.trash.size})", "Trash (${uiState.snapshot.trash.size})"),
                            iconTint = Color(0xFF16A34A),
                            onClick = { activeDrawerSettingsSection = "trash" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Sms,
                            title = strings.t("الرسائل والواتس", "WhatsApp & SMS"),
                            iconTint = Color(0xFF334155),
                            onClick = { activeDrawerSettingsSection = "messages" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Print,
                            title = strings.t("إعدادات الطباعة", "Printing Settings"),
                            iconTint = Color(0xFF475569),
                            onClick = { activeDrawerSettingsSection = "printing" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Lock,
                            title = strings.t("قفل التطبيق", "App Lock"),
                            iconTint = Color(0xFFCA8A04),
                            onClick = { activeDrawerSettingsSection = "lock" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.CloudUpload,
                            title = strings.t("النسخ السحابي Google Drive", "Google Drive Backup"),
                            iconTint = Color(0xFF2563EB),
                            onClick = { activeDrawerSettingsSection = "gdriveBackup" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Inventory2,
                            title = strings.t("النسخ الاحتياطي والاستعادة", "Backup & Restore"),
                            iconTint = Color(0xFF92400E),
                            onClick = { activeDrawerSettingsSection = "backup" }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.SupportAgent,
                            title = strings.t("واتساب الدعم", "Support WhatsApp"),
                            iconTint = Color(0xFF16A34A),
                            onClick = {
                                scope.launch { drawerState.close() }
                                ShareHelper.openWhatsApp(
                                    context,
                                    uiState.settings.supportPhone,
                                    "مرحباً، بخصوص تطبيق الاداري برو",
                                    uiState.settings.messages
                                )
                            }
                        )
                        LuxuryDrawerMenuRow(
                            icon = Icons.Default.Share,
                            title = strings.t("مشاركة التطبيق", "Share App"),
                            iconTint = Color(0xFF0EA5E9),
                            onClick = {
                                scope.launch { drawerState.close() }
                                ShareHelper.shareText(
                                    context,
                                    strings.appTitle,
                                    "${strings.appTitle} — ${strings.appSubtitle}"
                                )
                            }
                        )
                        if (uiState.settings.appLock.enabled && uiState.settings.appLock.pin.isNotBlank()) {
                            LuxuryDrawerMenuRow(
                                icon = Icons.Default.Security,
                                title = strings.t("قفل التطبيق الآن", "Lock App Now"),
                                isDanger = true,
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    viewModel.lockNowIfEnabled()
                                }
                            )
                        }
                    }
                                }
                            }
                        }
                        if (isDrawerOpen) {
                            SnackbarHost(
                                hostState = snackbarHostState,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .navigationBarsPadding()
                            )
                        }
                    }
                }
            }
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = {
                    SnackbarHost(
                        snackbarHostState,
                        modifier = if (!showBottomBar) Modifier.navigationBarsPadding() else Modifier
                    )
                },
                bottomBar = {
                    if (showBottomBar) {
                        LuxuryBottomNavBar(
                            currentRoute = activeBottomRoute,
                            homeRoute = AppRoutes.HOME,
                            privateRoute = AppRoutes.PRIVATE,
                            buyerRoute = AppRoutes.BUYER,
                            onSelect = { targetRoute ->
                                val targetPage = when (targetRoute) {
                                    AppRoutes.PRIVATE -> 1
                                    AppRoutes.BUYER -> 2
                                    else -> 0
                                }
                                if (currentRoute == AppRoutes.HOME) {
                                    scope.launch {
                                        bottomPagerState.animateScrollToPage(
                                            page = targetPage,
                                            animationSpec = slidingDoorAnimSpec
                                        )
                                    }
                                } else {
                                    scope.launch {
                                        navController.popBackStack(AppRoutes.HOME, inclusive = false)
                                        if (bottomPagerState.currentPage != targetPage) {
                                            bottomPagerState.animateScrollToPage(
                                                page = targetPage,
                                                animationSpec = slidingDoorAnimSpec
                                            )
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .let { if (showBottomBar) it.padding(innerPadding) else it }
                ) {
                    @OptIn(ExperimentalSharedTransitionApi::class)
                    SharedTransitionLayout {
                        CompositionLocalProvider(LocalSharedTransitionScope provides this) {
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HOME,
                        enterTransition = {
                            fadeIn(tween(220, easing = FastOutSlowInEasing)) +
                                scaleIn(initialScale = 0.97f, animationSpec = tween(220, easing = FastOutSlowInEasing))
                        },
                        exitTransition = {
                            fadeOut(tween(180, easing = FastOutSlowInEasing)) +
                                scaleOut(targetScale = 0.99f, animationSpec = tween(180))
                        },
                        popEnterTransition = {
                            fadeIn(tween(210, easing = FastOutSlowInEasing)) +
                                scaleIn(initialScale = 0.985f, animationSpec = tween(210, easing = FastOutSlowInEasing))
                        },
                        popExitTransition = {
                            fadeOut(tween(180, easing = FastOutSlowInEasing)) +
                                scaleOut(targetScale = 0.97f, animationSpec = tween(180))
                        }
                    ) {
                        composable(AppRoutes.HOME) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val layoutDir = LocalLayoutDirection.current
                                val hasCustomBg = rememberFileExists(uiState.settings.appearance.backgroundPath)
                                val doorEdgeColor = tokens.barAccent.copy(alpha = 0.45f)
                                val doorBackdrop = MaterialTheme.colorScheme.background
                                val openDrawerCallback = remember(scope, drawerState) {
                                    { scope.launch { drawerState.open() }; Unit }
                                }
                                val backToHomeCallback = remember(scope, bottomPagerState, slidingDoorAnimSpec) {
                                    {
                                        scope.launch {
                                            bottomPagerState.animateScrollToPage(0, animationSpec = slidingDoorAnimSpec)
                                        }
                                        Unit
                                    }
                                }

                                HorizontalPager(
                                    state = bottomPagerState,
                                    beyondViewportPageCount = 1,
                                    userScrollEnabled = !isDrawerOpen,
                                    modifier = Modifier.fillMaxSize()
                                ) { page ->
                                    val dirSign = if (layoutDir == LayoutDirection.Rtl) -1f else 1f
                                    val isBehind by remember(page) {
                                        derivedStateOf {
                                            ((bottomPagerState.currentPage - page) + bottomPagerState.currentPageOffsetFraction) > 0.001f
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .zIndex(if (isBehind) 0f else 1f)
                                            .graphicsLayer {
                                                val pageOffset = (bottomPagerState.currentPage - page) + bottomPagerState.currentPageOffsetFraction
                                                val behindProgress = pageOffset.coerceIn(0f, 1f)
                                                val isMoving = abs(bottomPagerState.currentPageOffsetFraction) > 0.001f
                                                if (pageOffset > 0f) {
                                                    translationX = dirSign * size.width * behindProgress * 0.50f
                                                    val s = 1f - 0.045f * behindProgress
                                                    scaleX = s
                                                    scaleY = s
                                                    alpha = 1f - 0.24f * behindProgress
                                                } else if (isMoving) {
                                                    shadowElevation = 18.dp.toPx()
                                                }
                                            }
                                            .drawBehind {
                                                val doorBgAlpha = if (!hasCustomBg) 1f else (abs(bottomPagerState.currentPageOffsetFraction) * 5f).coerceIn(0f, 1f)
                                                if (doorBgAlpha > 0f) {
                                                    drawRect(color = doorBackdrop.copy(alpha = doorBgAlpha))
                                                }
                                            }
                                            .drawWithContent {
                                                drawContent()
                                                val pageOffset = (bottomPagerState.currentPage - page) + bottomPagerState.currentPageOffsetFraction
                                                val isMoving = abs(bottomPagerState.currentPageOffsetFraction) > 0.001f
                                                if (isMoving && pageOffset <= 0.001f && pageOffset > -1f) {
                                                    val edgeW = 2.dp.toPx()
                                                    val x = if (layoutDir == LayoutDirection.Rtl) size.width - edgeW else 0f
                                                    drawRect(
                                                        color = doorEdgeColor,
                                                        topLeft = Offset(x, 0f),
                                                        size = Size(edgeW, size.height)
                                                    )
                                                }
                                            }
                                    ) {
                                        when (page) {
                                            0 -> HomeScreen(
                                                uiState = uiState,
                                                onOpenDrawer = openDrawerCallback,
                                                onToggleLang = viewModel::toggleLanguage,
                                                onToggleDark = viewModel::toggleDarkTheme,
                                                onSelectSpecialty = viewModel::setHomeSpecialty,
                                                onAddSpecialty = viewModel::addHomeSpecialty,
                                                onOpenClockSection = { sec ->
                                                    if (sec == ClockSection.DEBTS) {
                                                        activeDebtsHeroKey = "hero_clock_debts"
                                                    }
                                                    navController.navigate(AppRoutes.clockSection(sec))
                                                },
                                                onOpenTasfeer = {
                                                    activeTasfeerHeroKey = "hero_tasfeer_clock"
                                                    navController.navigate(AppRoutes.TASFEER)
                                                },
                                                onOpenTasfeerFromSummary = {
                                                    activeTasfeerHeroKey = "hero_tasfeer_summary"
                                                    navController.navigate(AppRoutes.TASFEER)
                                                },
                                                onOpenFolders = { navController.navigate(AppRoutes.FOLDERS_HOME) },
                                                onOpenWeeklyFilters = { navController.navigate(AppRoutes.WEEKLY_FILTERS) },
                                                onOpenDetails = { navController.navigate(AppRoutes.DETAILS_LIST) },
                                                onOpenDebtCashboxes = {
                                                    activeDebtsHeroKey = "hero_debts_cashboxes_title"
                                                    navController.navigate(AppRoutes.DEBT_CASHBOXES)
                                                }
                                            )
                                            1 -> PrivateFoldersScreen(
                                                uiState = uiState,
                                                viewModel = viewModel,
                                                onOpenDrawer = openDrawerCallback,
                                                onBackToHome = backToHomeCallback,
                                                onOpenFolder = { f -> navController.navigate(AppRoutes.privateFolder(f.id)) },
                                                onOpenAccount = { acc -> navController.navigate(AppRoutes.privateStatement(acc.id)) }
                                            )
                                            else -> BuyerHubScreen(
                                                uiState = uiState,
                                                viewModel = viewModel,
                                                onOpenDrawer = openDrawerCallback,
                                                onOpenBuyerFolders = { navController.navigate(AppRoutes.FOLDERS_BUYER) },
                                                onOpenTransferSheets = { navController.navigate(AppRoutes.BUYER_TRANSFER) },
                                                onOpenAnnualSheets = { navController.navigate(AppRoutes.BUYER_ANNUAL) },
                                                onOpenSalesLedger = { navController.navigate(AppRoutes.buyerController("sales")) },
                                                onOpenProfitLedger = { tgt -> navController.navigate(AppRoutes.buyerController(tgt)) }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        composable(AppRoutes.FOLDERS_HOME) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                WeekFoldersScreen(
                                    scope = FolderScope.HOME,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenFolder = { f -> navController.navigate(AppRoutes.folderDetail(f.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.FOLDERS_BUYER) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                WeekFoldersScreen(
                                    scope = FolderScope.BUYER,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenFolder = { f -> navController.navigate(AppRoutes.folderDetail(f.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.FOLDER_DETAIL,
                            arguments = listOf(navArgument("folderId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val folderId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                                FolderDetailScreen(
                                    folderId = folderId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenInvoice = { inv ->
                                        if (inv.invoiceKind == "buyer") navController.navigate(AppRoutes.buyerInvoice(folderId, inv.id))
                                        else navController.navigate(AppRoutes.sellerInvoice(folderId, inv.id))
                                    },
                                    onCreateInvoice = { fld ->
                                        if (fld.scope == FolderScope.BUYER) navController.navigate(AppRoutes.buyerInvoice(fld.id))
                                        else navController.navigate(AppRoutes.sellerInvoice(fld.id))
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.SELLER_INVOICE,
                            arguments = listOf(
                                navArgument("folderId") { type = NavType.StringType },
                                navArgument("invoiceId") { type = NavType.StringType; nullable = true }
                            )
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val fId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                                val invId = entry.arguments?.getString("invoiceId")?.let { Uri.decode(it) }
                                SellerInvoiceEditorScreen(
                                    folderId = fId,
                                    invoiceId = invId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.BUYER_INVOICE,
                            arguments = listOf(
                                navArgument("folderId") { type = NavType.StringType },
                                navArgument("invoiceId") { type = NavType.StringType; nullable = true }
                            )
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val fId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                                val invId = entry.arguments?.getString("invoiceId")?.let { Uri.decode(it) }
                                BuyerInvoiceEditorScreen(
                                    folderId = fId,
                                    invoiceId = invId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.WEEKLY_FILTERS) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                WeeklyFiltersListScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenFilter = { wf -> navController.navigate(AppRoutes.weeklyEditor(wf.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.WEEKLY_EDITOR,
                            arguments = listOf(navArgument("filterId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val filterId = Uri.decode(entry.arguments?.getString("filterId") ?: "")
                                WeeklyFilterEditorScreen(
                                    filterId = filterId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenDetailForFilter = { wf ->
                                        val det = uiState.snapshot.details.firstOrNull { it.autoFilterId == wf.id || it.sourceFolderId == wf.sourceFolderId }
                                        if (det != null) navController.navigate(AppRoutes.detailEditor(det.id))
                                        else navController.navigate(AppRoutes.DETAILS_LIST)
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.DETAILS_LIST) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                DetailsListScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenDetail = { det -> navController.navigate(AppRoutes.detailEditor(det.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.DETAIL_EDITOR,
                            arguments = listOf(navArgument("detailId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val detailId = Uri.decode(entry.arguments?.getString("detailId") ?: "")
                                DetailEditorScreen(
                                    detailId = detailId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.CLOCK_SECTION,
                            arguments = listOf(navArgument("sectionKey") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val key = entry.arguments?.getString("sectionKey") ?: "sale"
                                val sec = ClockSection.entries.firstOrNull { it.key == key } ?: ClockSection.SALE
                                if (sec == ClockSection.DEBTS) {
                                    DebtsMainScreen(
                                        uiState = uiState,
                                        viewModel = viewModel,
                                        titleHeroKey = activeDebtsHeroKey,
                                        onOpenAutoBox = { navController.navigate(AppRoutes.AUTO_DEBT_BOX) },
                                        onOpenCashbox = { box -> navController.navigate(AppRoutes.debtAccounts(box.id)) },
                                        onBack = { navController.popBackStack() }
                                    )
                                } else {
                                    ClockDetailScreen(
                                        section = sec,
                                        uiState = uiState,
                                        viewModel = viewModel,
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                            }
                        }

                        composable(AppRoutes.DEBT_CASHBOXES) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                DebtsMainScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    titleHeroKey = activeDebtsHeroKey,
                                    onOpenAutoBox = { navController.navigate(AppRoutes.AUTO_DEBT_BOX) },
                                    onOpenCashbox = { box -> navController.navigate(AppRoutes.debtAccounts(box.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.AUTO_DEBT_BOX) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                AutoDebtBoxScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.DEBT_ACCOUNTS,
                            arguments = listOf(navArgument("cashboxId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val boxId = Uri.decode(entry.arguments?.getString("cashboxId") ?: "")
                                DebtAccountsScreen(
                                    cashboxId = boxId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenAccount = { acc -> navController.navigate(AppRoutes.debtLedger(acc.id)) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.DEBT_LEDGER,
                            arguments = listOf(navArgument("accountId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val accId = Uri.decode(entry.arguments?.getString("accountId") ?: "")
                                DebtAccountLedgerScreen(
                                    accountId = accId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.TASFEER) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                TasfeerScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    titleHeroKey = activeTasfeerHeroKey,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.PRIVATE_FOLDER_ACCOUNTS,
                            arguments = listOf(navArgument("folderId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val fId = Uri.decode(entry.arguments?.getString("folderId") ?: "")
                                PrivateFolderAccountsScreen(
                                    folderId = fId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenAccount = { acc -> navController.navigate(AppRoutes.privateStatement(acc.id)) },
                                    onOpenCurrencySettings = { navController.navigate(AppRoutes.settings("currencies")) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.PRIVATE_STATEMENT,
                            arguments = listOf(navArgument("accountId") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val accId = Uri.decode(entry.arguments?.getString("accountId") ?: "")
                                PrivateAccountStatementScreen(
                                    accountId = accId,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onOpenCurrencySettings = { navController.navigate(AppRoutes.settings("currencies")) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.BUYER_TRANSFER) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                BuyerTransferListAndEditorScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(AppRoutes.BUYER_ANNUAL) {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                BuyerAnnualScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.BUYER_CONTROLLER,
                            arguments = listOf(navArgument("mode") { type = NavType.StringType })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val mode = entry.arguments?.getString("mode") ?: "sales"
                                BuyerControllerLedgerScreen(
                                    mode = mode,
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }

                        composable(
                            route = AppRoutes.SETTINGS,
                            arguments = listOf(navArgument("section") { type = NavType.StringType; defaultValue = "hub" })
                        ) { entry ->
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                val sec = entry.arguments?.getString("section")?.let { Uri.decode(it) } ?: "hub"
                                SettingsScreen(
                                    uiState = uiState,
                                    viewModel = viewModel,
                                    onExportBackup = onExportBackup,
                                    onImportBackup = onImportBackup,
                                    onBack = { navController.popBackStack() },
                                    initialSection = sec
                                )
                            }
                        }
                    }
                        }
                    }
                }
            }
        }
    }

    if (uiState.isLocked && !uiState.splashVisible) {
        AppLockScreen(
            lockSettings = uiState.settings.appLock,
            onVerifyPin = viewModel::verifyPin,
            onBiometricSuccess = viewModel::unlockApp
        )
    }

    AnimatedVisibility(
        visible = uiState.splashVisible,
        exit = fadeOut(
            animationSpec = tween(
                durationMillis = 480,
                easing = CubicBezierEasing(0.65f, 0f, 0.35f, 1f)
            )
        )
    ) {
        LuxurySplashOverlay(onFinished = viewModel::dismissSplash)
    }

    if (showExitBackupDialog) {
        AlertDialog(
            onDismissRequest = { showExitBackupDialog = false },
            title = { Text(strings.t("النسخ الاحتياطي قبل الخروج", "Backup Before Exit")) },
            text = {
                val promptMsg = if (uiState.settings.gdriveBackup.connected) {
                    strings.t(
                        "هل تريد النسخ الاحتياطي إلى Google Drive (مجلد RYD1) في الخلفية قبل الخروج النهائي من التطبيق؟",
                        "Do you want to back up to Google Drive (RYD1 folder) in the background before exiting?"
                    )
                } else {
                    strings.t(
                        "هل تريد النسخ الاحتياطي إلى Google Drive (مجلد RYD1) قبل الخروج النهائي؟ (يتطلب ربط حساب Google)",
                        "Do you want to back up to Google Drive (RYD1 folder) before exiting? (Requires linking a Google account)"
                    )
                }
                Text(promptMsg)
            },
            confirmButton = {
                Button(onClick = {
                    showExitBackupDialog = false
                    val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) != PackageManager.PERMISSION_GRANTED
                    if (needsNotifPermission) {
                        exitNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        viewModel.startExitBackupAndFinish(
                            activity = activity,
                            onNeedResolution = { req -> exitBackupAuthLauncher.launch(req) },
                            onReadyToExit = { activity?.finish() }
                        )
                    }
                }) {
                    Text(strings.t("نعم", "Yes"))
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        showExitBackupDialog = false
                        activity?.finish()
                    }) {
                        Text(strings.t("لا (خروج)", "No (Exit)"))
                    }
                    TextButton(onClick = { showExitBackupDialog = false }) {
                        Text(strings.cancel)
                    }
                }
            }
        )
    }
    }
}
