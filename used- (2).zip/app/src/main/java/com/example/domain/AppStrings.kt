package com.example.domain

import androidx.compose.runtime.Immutable

/**
 * Bilingual string lookup (Arabic default, English supported cleanly via toggle).
 */
@Immutable
data class Strings(val isEn: Boolean) {
    fun t(ar: String, en: String): String = if (isEn) en else ar

    val appTitle get() = t("الاداري برو", "Al-Idari Pro")
    val appSubtitle get() = t("النظام المحاسبي والإداري الذكي", "Smart Financial & Admin System")
    val home get() = t("الرئيسية", "Home")
    val privateAccounts get() = t("الحسابات الخصوصية", "Private")
    val purchase get() = t("الشرائي", "Purchase")
    val invoices get() = t("الفواتير", "Invoices")
    val weeklyFilter get() = t("الفلتر الأسبوعي", "Weekly Filter")
    val detail get() = t("التفصيل", "Detail")
    val clockTitle get() = t("المراقب", "Monitor")
    val finalSale get() = t("جملة البيع النهائية", "Final Sales Total")
    val workersOut get() = t("خرج العمال", "Workers Expenses")
    val withdrawals get() = t("السحب", "Withdrawals")
    val debts get() = t("الديون", "Debts")
    val currencies get() = t("العملات", "Currencies")
    val tasfeer get() = t("الصرافة", "Exchange")
    val credit get() = t("لكم", "Credit")
    val debit get() = t("عليكم", "Debit")
    val balanced get() = t("متوازن", "Balanced")
    val matching get() = t("متطابق", "Matched")
    val save get() = t("حفظ", "Save")
    val cancel get() = t("إلغاء", "Cancel")
    val delete get() = t("حذف", "Delete")
    val edit get() = t("تعديل", "Edit")
    val print get() = t("طباعة", "Print")
    val auth get() = t("مصادقة", "Confirm")
    val share get() = t("مشاركة", "Share")
    val copy get() = t("نسخ", "Copy")
    val move get() = t("نقل", "Move")
    val settings get() = t("الإعدادات", "Settings")
    val allSpecialties get() = t("كل التخاصيص", "All Allocations")
    val noSpecialty get() = t("بدون تخصيص", "Unassigned")
    val selectAll get() = t("تحديد الكل", "Select All")
    val total get() = t("الإجمالي", "Total")
    val net get() = t("الصافي", "Net")
    val date get() = t("التاريخ", "Date")
    val from get() = t("من", "From")
    val to get() = t("إلى", "To")
    val note get() = t("البيان", "Note")
    val amount get() = t("المبلغ", "Amount")
    val confirm get() = t("تأكيد", "Confirm")
    val close get() = t("إغلاق", "Close")
    val calculator get() = t("الحاسبة", "Calculator")
}
