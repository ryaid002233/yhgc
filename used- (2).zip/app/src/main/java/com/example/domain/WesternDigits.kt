package com.example.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

object WesternDigits {

    fun toWestern(input: String?): String {
        if (input.isNullOrEmpty()) return ""
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '\u0660'..'\u0669' -> sb.append(('0'.code + (ch.code - 0x0660)).toChar())
                in '\u06F0'..'\u06F9' -> sb.append(('0'.code + (ch.code - 0x06F0)).toChar())
                '\u066B', ',' -> sb.append(',')
                '\u066C' -> sb.append('.')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun cleanNumericInput(input: String?): String {
        val en = toWestern(input).replace(",", "").trim()
        val sb = StringBuilder()
        var dotSeen = false
        for (i in en.indices) {
            val ch = en[i]
            when {
                ch in '0'..'9' -> sb.append(ch)
                ch == '.' && !dotSeen -> {
                    dotSeen = true
                    sb.append(ch)
                }
                ch == '-' && i == 0 -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun num(input: String?): Double {
        if (input.isNullOrBlank()) return 0.0
        val cleaned = toWestern(input).replace(",", "").trim()
        val parsed = cleaned.toDoubleOrNull()
        return if (parsed != null && parsed.isFinite()) parsed else 0.0
    }

    fun num(value: Double?): Double = if (value != null && value.isFinite()) value else 0.0

    fun round2(value: Double): Double =
        if (!value.isFinite()) 0.0 else (value * 100.0).roundToLong() / 100.0

    fun round3(value: Double): Double =
        if (!value.isFinite()) 0.0 else (value * 1000.0).roundToLong() / 1000.0

    fun round6(value: Double): Double =
        if (!value.isFinite()) 0.0 else (value * 1_000_000.0).roundToLong() / 1_000_000.0

    private val symbols = DecimalFormatSymbols(Locale.US).apply {
        decimalSeparator = '.'
        groupingSeparator = ','
    }

    fun fmt(value: Double, maxDecimals: Int = 3, minDecimals: Int = 0): String {
        if (!value.isFinite() || abs(value) < 1e-10) {
            return if (minDecimals > 0) {
                "0." + "0".repeat(minDecimals)
            } else {
                "0"
            }
        }
        val pattern = buildString {
            append("#,##0")
            if (maxDecimals > 0) {
                append('.')
                repeat(minDecimals) { append('0') }
                repeat((maxDecimals - minDecimals).coerceAtLeast(0)) { append('#') }
            }
        }
        val df = DecimalFormat(pattern, symbols)
        return df.format(value)
    }

    fun fmtBlankIfZero(value: Double, maxDecimals: Int = 3): String {
        return if (!value.isFinite() || abs(value) < 1e-10) "" else fmt(value, maxDecimals)
    }

    fun rawNumberString(value: Double, maxDecimals: Int = 3): String {
        if (!value.isFinite() || abs(value) < 1e-10) return ""
        val rounded = when (maxDecimals) {
            2 -> round2(value)
            3 -> round3(value)
            else -> round6(value)
        }
        val asLong = rounded.toLong()
        return if (abs(rounded - asLong.toDouble()) < 1e-9) {
            asLong.toString()
        } else {
            rounded.toString()
        }
    }
}

object DateHelper {
    private fun isoFormat() = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
    private fun timeFormat() = SimpleDateFormat("HH:mm", Locale.US)

    private val arabicDays = arrayOf(
        "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    )

    private val englishDays = arrayOf(
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    )

    fun todayIso(): String = isoFormat().format(Calendar.getInstance().time)

    fun nowTime(): String = timeFormat().format(Calendar.getInstance().time)

    fun monthStartIso(refIso: String = todayIso()): String {
        val cal = parseCalendar(refIso) ?: Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return isoFormat().format(cal.time)
    }

    fun yearStartIso(refIso: String = todayIso()): String {
        val cal = parseCalendar(refIso) ?: Calendar.getInstance()
        return "${cal.get(Calendar.YEAR)}-01-01"
    }

    fun yearEndIso(refIso: String = todayIso()): String {
        val cal = parseCalendar(refIso) ?: Calendar.getInstance()
        return "${cal.get(Calendar.YEAR)}-12-31"
    }

    fun parseCalendar(iso: String?): Calendar? {
        val clean = WesternDigits.toWestern(iso).trim()
        if (!Regex("""^\d{4}-\d{2}-\d{2}$""").matches(clean)) return null
        return try {
            val date = isoFormat().parse(clean) ?: return null
            Calendar.getInstance().apply {
                time = date
                set(Calendar.HOUR_OF_DAY, 12)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun isIsoDate(iso: String?): Boolean = parseCalendar(iso) != null

    fun parseFlexibleDate(input: String?): String {
        val s = WesternDigits.toWestern(input).trim()
            .replace('/', ' ')
            .replace('-', ' ')
            .replace('.', ' ')
            .replace(Regex("""\s+"""), " ")
        val parts = s.split(' ')
        if (parts.size != 3) return ""
        var y: Int
        var m: Int
        var d: Int
        if (parts[0].length == 4) {
            y = parts[0].toIntOrNull() ?: return ""
            m = parts[1].toIntOrNull() ?: return ""
            d = parts[2].toIntOrNull() ?: return ""
        } else {
            d = parts[0].toIntOrNull() ?: return ""
            m = parts[1].toIntOrNull() ?: return ""
            y = parts[2].toIntOrNull() ?: return ""
        }
        if (y in 1..99) y += 2000
        if (y < 1900 || m !in 1..12 || d !in 1..31) return ""
        val candidate = "%04d-%02d-%02d".format(Locale.US, y, m, d)
        return if (isIsoDate(candidate)) candidate else ""
    }

    fun displaySlash(iso: String?): String {
        val s = WesternDigits.toWestern(iso).trim()
        val p = s.split('-')
        return if (p.size == 3) "${p[2]}/${p[1]}/${p[0]}" else s
    }

    fun dayNameAr(iso: String?): String {
        val cal = parseCalendar(iso) ?: return ""
        return arabicDays[(cal.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY).coerceIn(0, 6)]
    }

    fun dayNameEn(iso: String?): String {
        val cal = parseCalendar(iso) ?: return ""
        return englishDays[(cal.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY).coerceIn(0, 6)]
    }

    fun formatInvoiceDate(iso: String?, english: Boolean = false): String {
        val clean = WesternDigits.toWestern(iso).trim()
        if (!isIsoDate(clean)) return clean
        val day = if (english) dayNameEn(clean) else dayNameAr(clean)
        return "$day ${displaySlash(clean)}"
    }

    fun addDays(iso: String, deltaDays: Int): String {
        val cal = parseCalendar(iso) ?: return iso
        cal.add(Calendar.DAY_OF_YEAR, deltaDays)
        return isoFormat().format(cal.time)
    }

    fun daysBetweenInclusive(fromIso: String?, toIso: String?): Int {
        val a = parseCalendar(fromIso) ?: return 0
        val b = parseCalendar(toIso) ?: return 0
        val diffMs = b.timeInMillis - a.timeInMillis
        val days = (diffMs / 86_400_000L).toInt() + 1
        return days.coerceAtLeast(1)
    }

    fun shiftPeriod(fromIso: String, toIso: String, dir: Int): Pair<String, String> {
        val fCal = parseCalendar(fromIso) ?: return fromIso to toIso
        val tCal = parseCalendar(toIso) ?: return fromIso to toIso
        val isFullYear = fCal.get(Calendar.MONTH) == Calendar.JANUARY &&
            fCal.get(Calendar.DAY_OF_MONTH) == 1 &&
            tCal.get(Calendar.MONTH) == Calendar.DECEMBER &&
            tCal.get(Calendar.DAY_OF_MONTH) == 31 &&
            fCal.get(Calendar.YEAR) == tCal.get(Calendar.YEAR)
        return if (isFullYear) {
            fCal.add(Calendar.YEAR, dir)
            tCal.add(Calendar.YEAR, dir)
            isoFormat().format(fCal.time) to isoFormat().format(tCal.time)
        } else {
            val isFullMonth = fCal.get(Calendar.DAY_OF_MONTH) == 1 &&
                tCal.get(Calendar.DAY_OF_MONTH) == tCal.getActualMaximum(Calendar.DAY_OF_MONTH) &&
                fCal.get(Calendar.YEAR) == tCal.get(Calendar.YEAR) &&
                fCal.get(Calendar.MONTH) == tCal.get(Calendar.MONTH)
            if (isFullMonth) {
                fCal.add(Calendar.MONTH, dir)
                val endCal = (fCal.clone() as Calendar).apply {
                    set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                }
                isoFormat().format(fCal.time) to isoFormat().format(endCal.time)
            } else {
                val span = daysBetweenInclusive(fromIso, toIso)
                addDays(fromIso, dir * span) to addDays(toIso, dir * span)
            }
        }
    }

    fun buildWeekSlots(fromIso: String, toIso: String): List<Pair<String, String>> {
        val defaultDays = listOf(
            "السبت", "الأحد", "الإثنين", "الثلاثاء",
            "الأربعاء", "الخميس", "الجمعة", "السبت لحقه"
        )
        if (fromIso.isBlank()) return defaultDays.map { it to "" }
        val start = parseCalendar(fromIso) ?: return defaultDays.map { it to "" }
        val end = parseCalendar(toIso) ?: (start.clone() as Calendar)
        if (end.timeInMillis < start.timeInMillis) return emptyList()
        val out = mutableListOf<Pair<String, String>>()
        val cur = start.clone() as Calendar
        while (cur.timeInMillis <= end.timeInMillis && out.size < 8) {
            val iso = isoFormat().format(cur.time)
            val name = arabicDays[(cur.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY).coerceIn(0, 6)]
            out.add(name to iso)
            cur.add(Calendar.DAY_OF_YEAR, 1)
        }
        return out
    }

    fun suggestNextFreeDate(startDate: String, endDate: String, takenDates: Set<String>): String {
        if (startDate.isBlank() || endDate.isBlank()) return todayIso()
        val inWeek = takenDates.filter { it in startDate..endDate }.sorted()
        var candidate = if (inWeek.isNotEmpty()) addDays(inWeek.last(), 1) else startDate
        var guard = 0
        while (guard < 400 && candidate <= endDate) {
            if (candidate >= startDate && candidate !in takenDates) return candidate
            candidate = addDays(candidate, 1)
            guard++
        }
        candidate = startDate
        guard = 0
        while (guard < 400 && candidate <= endDate) {
            if (candidate !in takenDates) return candidate
            candidate = addDays(candidate, 1)
            guard++
        }
        return startDate
    }
}
