package com.example.domain

import androidx.compose.runtime.Immutable
import java.util.UUID

fun newId(prefix: String = "id"): String =
    "$prefix-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(6)}"

enum class FolderScope(val key: String) {
    HOME("home"),
    BUYER("buyer");

    companion object {
        fun fromKey(k: String?): FolderScope = if (k == "buyer") BUYER else HOME
    }
}

enum class FolderSortType(val key: String) {
    DATE("date"),
    NAME("name"),
    ORDER("order")
}

enum class SortDir(val key: String) {
    ASC("asc"),
    DESC("desc")
}

@Immutable
data class Specialty(
    val id: String = newId("sp"),
    val name: String = "",
    val workersAmount: Double = 0.0
)

@Immutable
data class AppCurrency(
    val name: String,
    val symbol: String,
    val sellRate: Double = 1.0,
    val buyRate: Double = 1.0,
    val fraction: Double = 1.0,
    val isDefault: Boolean = false,
    val subUnit: String = ""
)

@Immutable
data class WeekFolder(
    val id: String = newId("fld"),
    val name: String = "",
    val imagePath: String = "",
    val note: String = "",
    val order: Int = 1,
    val scope: FolderScope = FolderScope.HOME,
    val startDate: String = "",
    val endDate: String = "",
    val specialtyId: String = "",
    val locked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val invoices: List<FolderInvoice> = emptyList()
)

@Immutable
data class SaleRow(
    val id: String = newId("sr"),
    val s1n: String = "",
    val s1m: String = "",
    val s2n: String = "",
    val s2m: String = "",
    val s3n: String = "",
    val s3m: String = "",
    val dn: String = "",
    val dm: String = "",
    val dname: String = "",
    val onQty: String = "",
    val om: String = "",
    val oname: String = ""
)

@Immutable
data class MoneyNameRow(
    val id: String = newId("mr"),
    val name: String = "",
    val amount: String = ""
)

@Immutable
data class SellerCurrencyRow(
    val id: String = newId("cr"),
    val cur: String = "يمني",
    val amount: String = "",
    val rate: String = ""
)

@Immutable
data class SellerFormData(
    val saleColCount: Int = 1,
    val qty: String = "",
    val note: String = "",
    val salesRows: List<SaleRow> = listOf(SaleRow()),
    val receivedRows: List<MoneyNameRow> = listOf(MoneyNameRow()),
    val outRows: List<MoneyNameRow> = listOf(MoneyNameRow()),
    val withdrawRows: List<MoneyNameRow> = listOf(MoneyNameRow()),
    val weeklyRows: List<MoneyNameRow> = listOf(MoneyNameRow()),
    val currencyRows: List<SellerCurrencyRow> = emptyList()
)

@Immutable
data class BuyerInvoiceRow(
    val id: String = newId("br"),
    val name: String = "",
    val qty: String = "",
    val price: String = "",
    val total: Double = 0.0
)

@Immutable
data class FolderInvoice(
    val id: String = newId("inv"),
    val folderId: String = "",
    val invoiceKind: String = "seller", // "seller" or "buyer"
    val initDate: String = "",
    val initDateISO: String = "",
    val initSeller: String = "",
    val initPlace: String = "",
    val initWeeklyFilter: String = "",
    val initNo: String = "",
    val note: String = "",
    val specialtyId: String = "",
    val sellerPhotoPath: String = "",
    val invoicePaperPhotoPath: String = "",
    val formData: SellerFormData = SellerFormData(),
    val buyerRows: List<BuyerInvoiceRow> = emptyList(),
    val buyerTotal: Double = 0.0,
    val buyerExpense: Double = 0.0,
    val buyerNet: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Immutable
data class WeeklyQtyRow(
    val day: String = "",
    val date: String = "",
    val qty: String = "",
    val cash: String = "",
    val debt: String = "",
    val expense: String = ""
)

@Immutable
data class WeeklySalesRow(
    val day: String = "",
    val date: String = "",
    val cash: String = "",
    val saleGross: String = "",
    val outAmt: String = "",
    val weeklyAmt: String = "",
    val weeklyNote: String = "",
    val weeklySalesAmt: String = "",
    val weeklySalesNote: String = "",
    val prevAmt: String = "",
    val prevNote: String = ""
)

@Immutable
data class WeeklyMoneyRow(
    val day: String = "",
    val date: String = "",
    val yemeni: String = "",
    val saudiAmt: String = "",
    val saudiExch: String = "",
    val omaniAmt: String = "",
    val omaniExch: String = "",
    val dirhamAmt: String = "",
    val dirhamExch: String = ""
)

@Immutable
data class WeeklyFilter(
    val id: String = newId("wf"),
    val name: String = "",
    val fromDate: String = "",
    val toDate: String = "",
    val sourceFolderId: String = "",
    val specialtyId: String = "",
    val qtyRows: List<WeeklyQtyRow> = emptyList(),
    val salesRows: List<WeeklySalesRow> = emptyList(),
    val moneyRows: List<WeeklyMoneyRow> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Immutable
data class DetailReceivedRow(
    val id: String = newId("dr"),
    val name: String = "",
    val amount: String = ""
)

@Immutable
data class DetailDebtRow(
    val id: String = newId("dd"),
    val name: String = "",
    val qty: String = "",
    val amount: String = "",
    val weekly: String = "",
    val rest: Double = 0.0
)

@Immutable
data class DetailMoneyRow(
    val id: String = newId("dm"),
    val amount: String = "",
    val label: String = "",
    val value: String = ""
)

@Immutable
data class DetailWithdrawItem(
    val name: String = "",
    val amount: Double = 0.0,
    val date: String = "",
    val note: String = ""
)

@Immutable
data class DetailMoneyDayItem(
    val cur: String = "",
    val amount: Double = 0.0,
    val rate: Double = 1.0,
    val value: Double = 0.0,
    val date: String = "",
    val dayName: String = ""
)

@Immutable
data class DetailMoneySnapshot(
    val yemeniAmt: Double = 0.0,
    val yemeniVal: Double = 0.0,
    val saudiAmt: Double = 0.0,
    val saudiVal: Double = 0.0,
    val omaniAmt: Double = 0.0,
    val omaniVal: Double = 0.0,
    val dirhamAmt: Double = 0.0,
    val dirhamVal: Double = 0.0
)

@Immutable
data class DetailFormData(
    val qQty: String = "",
    val qCash: String = "",
    val qDebt: String = "",
    val qOut: String = "",
    val sSale: String = "",
    val sWeekly: String = "",
    val sPrivateOut: String = "",
    val wLabel: String = "السحب فلوس",
    val wValue: String = "",
    val note: String = "",
    val manualOverrides: Map<String, String> = emptyMap(),
    val receivedRows: List<DetailReceivedRow> = emptyList(),
    val debtRows: List<DetailDebtRow> = emptyList(),
    val moneyRows: List<DetailMoneyRow> = listOf(
        DetailMoneyRow(label = "يمني"),
        DetailMoneyRow(label = "سعودي"),
        DetailMoneyRow(label = "عماني"),
        DetailMoneyRow(label = "درهم")
    ),
    val calcQRest: Double = 0.0,
    val calcSCashRest: Double = 0.0,
    val calcSDebtSale: Double = 0.0,
    val calcSGrand: Double = 0.0,
    val calcPrevTotal: Double = 0.0,
    val calcMidTotal: Double = 0.0,
    val calcMTotal: Double = 0.0,
    val calcChkDiff: Double = 0.0,
    val withdrawSnapshot: List<DetailWithdrawItem> = emptyList(),
    val moneyDaysSnapshot: List<DetailMoneyDayItem> = emptyList(),
    val moneySummarySnapshot: DetailMoneySnapshot = DetailMoneySnapshot()
)

@Immutable
data class DetailRecord(
    val id: String = newId("det"),
    val autoFilterId: String = "",
    val sourceFolderId: String = "",
    val specialtyId: String = "",
    val initDetail: String = "",
    val initDateFrom: String = "",
    val initDateTo: String = "",
    val initNo: String = "",
    val initFilter: String = "",
    val note: String = "",
    val formData: DetailFormData = DetailFormData(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class ClockSection(val key: String, val labelAr: String, val labelEn: String) {
    SALE("sale", "جملة البيع النهائية", "Final sales total"),
    WORKERS("workers", "خرج العمال", "Workers' expenses"),
    WITHDRAW("withdraw", "السحب", "Withdrawal"),
    DEBTS("debts", "الديون", "Debts"),
    CURRENCY("currency", "العملات", "Currencies")
}

@Immutable
data class ClockDebtSubRow(
    val name: String = "",
    val amount: Double = 0.0,
    val qty: Double = 0.0,
    val rest: Double = 0.0
)

@Immutable
data class ClockEntry(
    val id: String = newId("ck"),
    val section: ClockSection = ClockSection.SALE,
    val srcDetailId: String = "",
    val specialtyId: String = "",
    val dir: String = "لكم", // "لكم" (+) or "عليكم" (-)
    val amount: Double = 0.0,
    val name: String = "",
    val date: String = "",
    val time: String = "",
    val from: String = "",
    val to: String = "",
    val note: String = "",
    val days: Int = 0,
    val qty: Double = 0.0,
    val cur: String = "",
    val curAmount: Double = 0.0,
    val curRate: Double = 1.0,
    val kind: String = "", // "", "received", "debtsale"
    val subRows: List<ClockDebtSubRow> = emptyList(),
    val rows: List<TsRowCurrency> = emptyList(),
    val img: String = "",
    val tsVoucherId: String = "",
    val tsKind: String = "", // "acc" or "fund"
    val auto: Boolean = true,
    val sentStamp: Long = System.currentTimeMillis()
)

@Immutable
data class DebtCashbox(
    val id: String = newId("box"),
    val name: String = "",
    val imagePath: String = "",
    val note: String = "",
    val order: Int = 1,
    val locked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
data class DebtAccount(
    val id: String = newId("acc"),
    val cashboxId: String = "",
    val name: String = "",
    val phone: String = "",
    val limitEnabled: Boolean = false,
    val limitAmount: Double = 0.0,
    val messageSend: String = "confirm",
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
data class DebtVoucher(
    val id: String = newId("dv"),
    val accountId: String = "",
    val specialtyId: String = "",
    val type: String = "debt", // "debt" (عليه / دين) or "pay" (له / تسديد)
    val amount: Double = 0.0,
    val currency: String = "ريال يمني",
    val note: String = "",
    val date: String = "",
    val time: String = "",
    val imagePath: String = "",
    val autoSourceKey: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// Currency Strip Transfers
@Immutable
data class CurrencyReceipt(
    val id: String = newId("crv"),
    val fromFundId: String = "",
    val toAccountId: String = "",
    val toAccountName: String = "",
    val currency: String = "",
    val amount: Double = 0.0,
    val rate: Double = 1.0,
    val fee: Double = 0.0,
    val date: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
data class CurrencyExchangeOp(
    val id: String = newId("cex"),
    val fromCurrency: String = "",
    val fromAmount: Double = 0.0,
    val toCurrency: String = "",
    val rate: Double = 1.0,
    val toAmount: Double = 0.0,
    val date: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// Tasfeer (الصرافة)
@Immutable
data class TsFolder(
    val id: String = newId("tsf"),
    val name: String = "",
    val parentId: String = "",
    val img: String = "",
    val order: Int = 1
)

@Immutable
data class TsAccount(
    val id: String = newId("tsa"),
    val folderId: String = "",
    val name: String = "",
    val phone: String = "",
    val img: String = "",
    val limitAmount: Double = 0.0
)

@Immutable
data class TsFund(
    val id: String = newId("tsfd"),
    val name: String = "",
    val img: String = "",
    val order: Int = 1
)

@Immutable
data class TsRowCurrency(
    val cur: String = "",
    val a: Double = 0.0,
    val r: Double = 1.0
)

@Immutable
data class TsFxEntry(
    val cur: String = "",
    val amount: Double = 0.0,
    val avgCost: Double = 1.0,
    val sellRate: Double = 1.0,
    val diff: Double = 0.0
)

@Immutable
data class TsVoucher(
    val id: String = newId("tsv"),
    val kind: String = "receipt", // "receipt", "transfer", "internal", "exchange", "fx"
    val dir: String = "in", // "in" (قبض/لكم), "out" (صرف/عليكم)
    val date: String = "",
    val time: String = "",
    val accId: String = "",
    val fundId: String = "",
    val fromFundId: String = "",
    val toFundId: String = "",
    val note: String = "",
    val img: String = "",
    val cur: String = "",
    val amount: Double = 0.0,
    val rate: Double = 1.0,
    val rows: List<TsRowCurrency> = emptyList(),
    val fromCur: String = "",
    val fromAmt: Double = 0.0,
    val toCur: String = "",
    val toAmt: Double = 0.0,
    val sender: String = "",
    val receiver: String = "",
    val dest: String = "",
    val transferNo: String = "",
    val com: Double = 0.0,
    val comCur: String = "",
    val isFx: Boolean = false,
    val isCom: Boolean = false,
    val fxParentId: String = "",
    val fxFromLabel: String = "",
    val fxDetail: List<TsFxEntry> = emptyList(),
    val pg: String = "",
    val specialtyId: String = "",
    val srcClockId: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// Private Accounts (الحسابات الخصوصية)
@Immutable
data class PrivateFolder(
    val id: String = newId("pf"),
    val name: String = "",
    val img: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
data class PrivateAccount(
    val id: String = newId("pa"),
    val folderId: String = "",
    val name: String = "",
    val phone: String = "",
    val cap: Double = 0.0,
    val send: String = "confirm",
    val img: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
data class PrivateTx(
    val id: String = newId("pt"),
    val accountId: String = "",
    val currency: String = "ريال يمني",
    val date: String = "",
    val time: String = "",
    val amount: Double = 0.0,
    val type: String = "عليه", // "عليه" or "له"
    val lines: List<String> = emptyList(),
    val img: String = "",
    val xfer: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// Buyer / Purchase Program (الشرائي)
@Immutable
data class BuyerTransferRow(
    val id: String = newId("btr"),
    val name: String = "",
    val buy: Double = 0.0,
    val exp: Double = 0.0
)

@Immutable
data class BuyerTransferSheet(
    val id: String = newId("bt"),
    val folderId: String = "",
    val specialtyId: String = "",
    val name: String = "",
    val fromDate: String = "",
    val toDate: String = "",
    val rows: List<BuyerTransferRow> = emptyList(),
    val oldPrice: Double = 0.0,
    val newPrice: Double = 0.0,
    val rentRada: Double = 0.0,
    val rentShip: Double = 0.0,
    val weeklySale: Double = 0.0,
    val habbaCount: Double = 0.0,
    val diffAccountName: String = "",
    val diffNote: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Immutable
data class BuyerAnnualRow(
    val id: String = newId("bar"),
    val from: String = "",
    val to: String = "",
    val day: String = "",
    val name: String = "",
    val buy: Double = 0.0,
    val sell: Double = 0.0,
    val habba: Double = 0.0,
    val diff: Double = 0.0,
    val profitLabel: String = "0",
    val autoKey: String = ""
)

@Immutable
data class BuyerAnnualFolder(
    val id: String = newId("baf"),
    val specialtyId: String = "",
    val name: String = "",
    val rows: List<BuyerAnnualRow> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Immutable
data class BuyerSaleEntry(
    val id: String = newId("bse"),
    val dir: String = "عليكم", // "لكم" (auto) or "عليكم" (manual hawala)
    val date: String = "",
    val from: String = "",
    val to: String = "",
    val amount: Double = 0.0,
    val qty: Double = 0.0,
    val unitPrice: Double = 0.0,
    val specialtyId: String = "",
    val note: String = "",
    val sender: String = "",
    val receiver: String = "",
    val refNo: String = "",
    val entity: String = "",
    val commission: Double = 0.0,
    val curBreakdown: Map<String, Pair<Double, Double>> = emptyMap(), // curKey -> (amount, rate)
    val img: String = "",
    val auto: Boolean = false,
    val autoKey: String = ""
)

@Immutable
data class BuyerProfitEntry(
    val id: String = newId("bpe"),
    val target: String = "seller", // "seller" or "supplier"
    val type: String = "ربح", // "ربح" or "سحب"
    val kind: String = "", // "ربح" or "خسارة" for auto
    val date: String = "",
    val from: String = "",
    val to: String = "",
    val amount: Double = 0.0,
    val specialtyId: String = "",
    val note: String = "",
    val autoProfit: Boolean = false,
    val autoKey: String = ""
)

// Trash
@Immutable
data class TrashItem(
    val id: String = newId("tr"),
    val type: String = "",
    val name: String = "",
    val parentId: String = "",
    val payloadJson: String = "",
    val deletedAt: String = ""
)
