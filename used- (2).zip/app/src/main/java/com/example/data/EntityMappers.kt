package com.example.data

import com.example.domain.*

object EntityMappers {

    fun WeekFolderEntity.toDomain(invoices: List<FolderInvoice>) = WeekFolder(
        id = id,
        name = name,
        imagePath = imagePath,
        note = note,
        order = sortOrder,
        scope = FolderScope.fromKey(scope),
        startDate = startDate,
        endDate = endDate,
        specialtyId = specialtyId,
        locked = locked,
        createdAt = createdAt,
        invoices = invoices
    )

    fun WeekFolder.toEntity() = WeekFolderEntity(
        id = id,
        name = name,
        imagePath = imagePath,
        note = note,
        sortOrder = order,
        scope = scope.key,
        startDate = startDate,
        endDate = endDate,
        specialtyId = specialtyId,
        locked = locked,
        createdAt = createdAt
    )

    fun FolderInvoiceEntity.toDomain() = FolderInvoice(
        id = id,
        folderId = folderId,
        invoiceKind = invoiceKind,
        initDate = initDate,
        initDateISO = initDateISO,
        initSeller = initSeller,
        initPlace = initPlace,
        initWeeklyFilter = initWeeklyFilter,
        initNo = initNo,
        note = note,
        specialtyId = specialtyId,
        sellerPhotoPath = sellerPhotoPath,
        invoicePaperPhotoPath = invoicePaperPhotoPath,
        formData = JsonCodec.decodeSellerForm(formDataJson),
        buyerRows = JsonCodec.decodeBuyerRows(buyerRowsJson),
        buyerTotal = buyerTotal,
        buyerExpense = buyerExpense,
        buyerNet = buyerNet,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun FolderInvoice.toEntity() = FolderInvoiceEntity(
        id = id,
        folderId = folderId,
        invoiceKind = invoiceKind,
        initDate = initDate,
        initDateISO = initDateISO,
        initSeller = initSeller,
        initPlace = initPlace,
        initWeeklyFilter = initWeeklyFilter,
        initNo = initNo,
        note = note,
        specialtyId = specialtyId,
        sellerPhotoPath = sellerPhotoPath,
        invoicePaperPhotoPath = invoicePaperPhotoPath,
        formDataJson = JsonCodec.encodeSellerForm(formData).toString(),
        buyerRowsJson = JsonCodec.encodeBuyerRows(buyerRows),
        buyerTotal = buyerTotal,
        buyerExpense = buyerExpense,
        buyerNet = buyerNet,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun WeeklyFilterEntity.toDomain(): WeeklyFilter {
        val base = WeeklyFilter(
            id = id,
            name = name,
            fromDate = fromDate,
            toDate = toDate,
            sourceFolderId = sourceFolderId,
            specialtyId = specialtyId,
            updatedAt = updatedAt
        )
        return JsonCodec.decodeWeeklyFilterPayload(base, payloadJson)
    }

    fun WeeklyFilter.toEntity() = WeeklyFilterEntity(
        id = id,
        name = name,
        fromDate = fromDate,
        toDate = toDate,
        sourceFolderId = sourceFolderId,
        specialtyId = specialtyId,
        payloadJson = JsonCodec.encodeWeeklyFilterPayload(this),
        updatedAt = updatedAt
    )

    fun DetailRecordEntity.toDomain() = DetailRecord(
        id = id,
        autoFilterId = autoFilterId,
        sourceFolderId = sourceFolderId,
        specialtyId = specialtyId,
        initDetail = initDetail,
        initDateFrom = initDateFrom,
        initDateTo = initDateTo,
        initNo = initNo,
        initFilter = initFilter,
        note = note,
        formData = JsonCodec.decodeDetailForm(formDataJson),
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun DetailRecord.toEntity() = DetailRecordEntity(
        id = id,
        autoFilterId = autoFilterId,
        sourceFolderId = sourceFolderId,
        specialtyId = specialtyId,
        initDetail = initDetail,
        initDateFrom = initDateFrom,
        initDateTo = initDateTo,
        initNo = initNo,
        initFilter = initFilter,
        note = note,
        formDataJson = JsonCodec.encodeDetailForm(formData),
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    fun ClockEntryEntity.toDomain() = ClockEntry(
        id = id,
        section = ClockSection.entries.firstOrNull { it.key == section } ?: ClockSection.SALE,
        srcDetailId = srcDetailId,
        specialtyId = specialtyId,
        dir = dir,
        amount = amount,
        name = name,
        date = date,
        time = time,
        from = fromDate,
        to = toDate,
        note = note,
        days = days,
        qty = qty,
        cur = cur,
        curAmount = curAmount,
        curRate = curRate,
        kind = kind,
        subRows = JsonCodec.decodeClockSubRows(subRowsJson),
        rows = JsonCodec.decodeTsRows(rowsJson),
        img = img,
        tsVoucherId = tsVoucherId,
        tsKind = tsKind,
        auto = auto,
        sentStamp = sentStamp
    )

    fun ClockEntry.toEntity() = ClockEntryEntity(
        id = id,
        section = section.key,
        srcDetailId = srcDetailId,
        specialtyId = specialtyId,
        dir = dir,
        amount = amount,
        name = name,
        date = date,
        time = time,
        fromDate = from,
        toDate = to,
        note = note,
        days = days,
        qty = qty,
        cur = cur,
        curAmount = curAmount,
        curRate = curRate,
        kind = kind,
        subRowsJson = JsonCodec.encodeClockSubRows(subRows),
        rowsJson = JsonCodec.encodeTsRows(rows),
        img = img,
        tsVoucherId = tsVoucherId,
        tsKind = tsKind,
        auto = auto,
        sentStamp = sentStamp
    )

    fun DebtCashboxEntity.toDomain() = DebtCashbox(id, name, imagePath, note, sortOrder, locked, createdAt)
    fun DebtCashbox.toEntity() = DebtCashboxEntity(id, name, imagePath, note, order, locked, createdAt)

    fun DebtAccountEntity.toDomain() = DebtAccount(id, cashboxId, name, phone, limitEnabled, limitAmount, messageSend, createdAt)
    fun DebtAccount.toEntity() = DebtAccountEntity(id, cashboxId, name, phone, limitEnabled, limitAmount, messageSend, createdAt)

    fun DebtVoucherEntity.toDomain() = DebtVoucher(id, accountId, specialtyId, type, amount, currency, note, date, time, imagePath, autoSourceKey, createdAt)
    fun DebtVoucher.toEntity() = DebtVoucherEntity(id, accountId, specialtyId, type, amount, currency, note, date, time, imagePath, autoSourceKey, createdAt)

    fun CurrencyReceiptEntity.toDomain() = CurrencyReceipt(id, fromFundId, toAccountId, toAccountName, currency, amount, rate, fee, date, note, createdAt)
    fun CurrencyReceipt.toEntity() = CurrencyReceiptEntity(id, fromFundId, toAccountId, toAccountName, currency, amount, rate, fee, date, note, createdAt)

    fun CurrencyExchangeEntity.toDomain() = CurrencyExchangeOp(id, fromCurrency, fromAmount, toCurrency, rate, toAmount, date, note, createdAt)
    fun CurrencyExchangeOp.toEntity() = CurrencyExchangeEntity(id, fromCurrency, fromAmount, toCurrency, rate, toAmount, date, note, createdAt)

    fun TsFolderEntity.toDomain() = TsFolder(id, name, parentId, img, sortOrder)
    fun TsFolder.toEntity() = TsFolderEntity(id, name, parentId, img, order)

    fun TsAccountEntity.toDomain() = TsAccount(id, folderId, name, phone, img, limitAmount)
    fun TsAccount.toEntity() = TsAccountEntity(id, folderId, name, phone, img, limitAmount)

    fun TsFundEntity.toDomain() = TsFund(id, name, img, sortOrder)
    fun TsFund.toEntity() = TsFundEntity(id, name, img, order)

    fun TsVoucherEntity.toDomain() = TsVoucher(
        id = id, kind = kind, dir = dir, date = date, time = time,
        accId = accId, fundId = fundId, fromFundId = fromFundId, toFundId = toFundId,
        note = note, img = img, cur = cur, amount = amount, rate = rate,
        rows = JsonCodec.decodeTsRows(rowsJson),
        fromCur = fromCur, fromAmt = fromAmt, toCur = toCur, toAmt = toAmt,
        sender = sender, receiver = receiver, dest = dest, transferNo = transferNo,
        com = com, comCur = comCur, pg = pg, specialtyId = specialtyId,
        srcClockId = srcClockId, createdAt = createdAt
    )

    fun TsVoucher.toEntity() = TsVoucherEntity(
        id = id, kind = kind, dir = dir, date = date, time = time,
        accId = accId, fundId = fundId, fromFundId = fromFundId, toFundId = toFundId,
        note = note, img = img, cur = cur, amount = amount, rate = rate,
        rowsJson = JsonCodec.encodeTsRows(rows),
        fromCur = fromCur, fromAmt = fromAmt, toCur = toCur, toAmt = toAmt,
        sender = sender, receiver = receiver, dest = dest, transferNo = transferNo,
        com = com, comCur = comCur, pg = pg, specialtyId = specialtyId,
        srcClockId = srcClockId, createdAt = createdAt
    )

    fun PrivateFolderEntity.toDomain() = PrivateFolder(id, name, img, createdAt)
    fun PrivateFolder.toEntity() = PrivateFolderEntity(id, name, img, createdAt)

    fun PrivateAccountEntity.toDomain() = PrivateAccount(id, folderId, name, phone, cap, send, img, createdAt)
    fun PrivateAccount.toEntity() = PrivateAccountEntity(id, folderId, name, phone, cap, send, img, createdAt)

    fun PrivateTxEntity.toDomain() = PrivateTx(
        id = id, accountId = accountId, currency = currency,
        date = date, time = time, amount = amount, type = type,
        lines = JsonCodec.decodeLines(linesJson),
        img = img, xfer = xfer, createdAt = createdAt
    )

    fun PrivateTx.toEntity() = PrivateTxEntity(
        id = id, accountId = accountId, currency = currency,
        date = date, time = time, amount = amount, type = type,
        linesJson = JsonCodec.encodeLines(lines),
        img = img, xfer = xfer, createdAt = createdAt
    )

    fun BuyerTransferEntity.toDomain() = BuyerTransferSheet(
        id = id, folderId = folderId, specialtyId = specialtyId,
        name = name, fromDate = fromDate, toDate = toDate,
        rows = JsonCodec.decodeBuyerTransferRows(rowsJson),
        oldPrice = oldPrice, newPrice = newPrice,
        rentRada = rentRada, rentShip = rentShip,
        weeklySale = weeklySale, habbaCount = habbaCount,
        diffAccountName = diffAccountName, diffNote = diffNote,
        updatedAt = updatedAt
    )

    fun BuyerTransferSheet.toEntity() = BuyerTransferEntity(
        id = id, folderId = folderId, specialtyId = specialtyId,
        name = name, fromDate = fromDate, toDate = toDate,
        rowsJson = JsonCodec.encodeBuyerTransferRows(rows),
        oldPrice = oldPrice, newPrice = newPrice,
        rentRada = rentRada, rentShip = rentShip,
        weeklySale = weeklySale, habbaCount = habbaCount,
        diffAccountName = diffAccountName, diffNote = diffNote,
        updatedAt = updatedAt
    )

    fun BuyerAnnualFolderEntity.toDomain() = BuyerAnnualFolder(
        id = id, specialtyId = specialtyId, name = name,
        rows = JsonCodec.decodeBuyerAnnualRows(rowsJson),
        updatedAt = updatedAt
    )

    fun BuyerAnnualFolder.toEntity() = BuyerAnnualFolderEntity(
        id = id, specialtyId = specialtyId, name = name,
        rowsJson = JsonCodec.encodeBuyerAnnualRows(rows),
        updatedAt = updatedAt
    )

    fun BuyerSaleEntity.toDomain() = BuyerSaleEntry(
        id = id, dir = dir, date = date, from = fromDate, to = toDate,
        amount = amount, qty = qty, unitPrice = unitPrice,
        specialtyId = specialtyId, note = note,
        sender = sender, receiver = receiver, refNo = refNo, entity = entity,
        commission = commission, curBreakdown = JsonCodec.decodeCurMap(curMapJson),
        img = img, auto = auto, autoKey = autoKey
    )

    fun BuyerSaleEntry.toEntity() = BuyerSaleEntity(
        id = id, dir = dir, date = date, fromDate = from, toDate = to,
        amount = amount, qty = qty, unitPrice = unitPrice,
        specialtyId = specialtyId, note = note,
        sender = sender, receiver = receiver, refNo = refNo, entity = entity,
        commission = commission, curMapJson = JsonCodec.encodeCurMap(curBreakdown),
        img = img, auto = auto, autoKey = autoKey
    )

    fun BuyerProfitEntity.toDomain() = BuyerProfitEntry(
        id = id, target = target, type = type, kind = kind,
        date = date, from = fromDate, to = toDate,
        amount = amount, specialtyId = specialtyId, note = note,
        autoProfit = autoProfit, autoKey = autoKey
    )

    fun BuyerProfitEntry.toEntity() = BuyerProfitEntity(
        id = id, target = target, type = type, kind = kind,
        date = date, fromDate = from, toDate = to,
        amount = amount, specialtyId = specialtyId, note = note,
        autoProfit = autoProfit, autoKey = autoKey
    )

    fun TrashItemEntity.toDomain() = TrashItem(id, type, name, parentId, payloadJson, deletedAt)
    fun TrashItem.toEntity() = TrashItemEntity(id, type, name, parentId, payloadJson, deletedAt)
}
