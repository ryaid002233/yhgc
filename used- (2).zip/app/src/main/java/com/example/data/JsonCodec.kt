package com.example.data

import com.example.domain.*
import org.json.JSONArray
import org.json.JSONObject

object JsonCodec {

    fun encodeSaleRow(r: SaleRow) = JSONObject().apply {
        put("id", r.id)
        put("s1n", r.s1n); put("s1m", r.s1m)
        put("s2n", r.s2n); put("s2m", r.s2m)
        put("s3n", r.s3n); put("s3m", r.s3m)
        put("dn", r.dn); put("dm", r.dm); put("dname", r.dname)
        put("on", r.onQty); put("om", r.om); put("oname", r.oname)
    }

    fun decodeSaleRow(o: JSONObject) = SaleRow(
        id = o.optString("id", newId("sr")),
        s1n = o.optString("s1n"), s1m = o.optString("s1m"),
        s2n = o.optString("s2n"), s2m = o.optString("s2m"),
        s3n = o.optString("s3n"), s3m = o.optString("s3m"),
        dn = o.optString("dn"), dm = o.optString("dm"), dname = o.optString("dname"),
        onQty = o.optString("on"), om = o.optString("om"), oname = o.optString("oname")
    )

    fun encodeMoneyNameList(list: List<MoneyNameRow>) = JSONArray().apply {
        list.forEach { r ->
            put(JSONObject().apply {
                put("id", r.id)
                put("name", r.name)
                put("amount", r.amount)
            })
        }
    }

    fun decodeMoneyNameList(arr: JSONArray?): List<MoneyNameRow> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            MoneyNameRow(
                id = o.optString("id", newId("mr")),
                name = o.optString("name"),
                amount = o.optString("amount")
            )
        }
    }

    fun encodeSellerForm(f: SellerFormData) = JSONObject().apply {
        put("saleColCount", f.saleColCount)
        put("qty", f.qty)
        put("note", f.note)
        put("salesRows", JSONArray().apply { f.salesRows.forEach { put(encodeSaleRow(it)) } })
        put("receivedRows", encodeMoneyNameList(f.receivedRows))
        put("outRows", encodeMoneyNameList(f.outRows))
        put("withdrawRows", encodeMoneyNameList(f.withdrawRows))
        put("weeklyRows", encodeMoneyNameList(f.weeklyRows))
        put("currencyRows", JSONArray().apply {
            f.currencyRows.forEach { r ->
                put(JSONObject().apply {
                    put("id", r.id)
                    put("cur", r.cur)
                    put("amount", r.amount)
                    put("rate", r.rate)
                })
            }
        })
    }

    fun decodeSellerForm(jsonStr: String): SellerFormData {
        if (jsonStr.isBlank()) return SellerFormData()
        return try {
            val o = JSONObject(jsonStr)
            val srArr = o.optJSONArray("salesRows")
            val salesRows = if (srArr != null && srArr.length() > 0) {
                (0 until srArr.length()).map { decodeSaleRow(srArr.getJSONObject(it)) }
            } else listOf(SaleRow())
            val crArr = o.optJSONArray("currencyRows")
            val curRows = if (crArr != null) {
                (0 until crArr.length()).map { i ->
                    val c = crArr.getJSONObject(i)
                    SellerCurrencyRow(
                        id = c.optString("id", newId("cr")),
                        cur = c.optString("cur", "يمني"),
                        amount = c.optString("amount"),
                        rate = c.optString("rate")
                    )
                }
            } else emptyList()
            SellerFormData(
                saleColCount = o.optInt("saleColCount", 1).coerceIn(1, 3),
                qty = o.optString("qty"),
                note = o.optString("note"),
                salesRows = salesRows,
                receivedRows = decodeMoneyNameList(o.optJSONArray("receivedRows")).ifEmpty { listOf(MoneyNameRow()) },
                outRows = decodeMoneyNameList(o.optJSONArray("outRows")).ifEmpty { listOf(MoneyNameRow()) },
                withdrawRows = decodeMoneyNameList(o.optJSONArray("withdrawRows")).ifEmpty { listOf(MoneyNameRow()) },
                weeklyRows = decodeMoneyNameList(o.optJSONArray("weeklyRows")).ifEmpty { listOf(MoneyNameRow()) },
                currencyRows = curRows
            )
        } catch (_: Exception) {
            SellerFormData()
        }
    }

    fun encodeBuyerRows(rows: List<BuyerInvoiceRow>): String = JSONArray().apply {
        rows.forEach { r ->
            put(JSONObject().apply {
                put("id", r.id); put("name", r.name)
                put("qty", r.qty); put("price", r.price); put("total", r.total)
            })
        }
    }.toString()

    fun decodeBuyerRows(jsonStr: String): List<BuyerInvoiceRow> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                BuyerInvoiceRow(
                    id = o.optString("id", newId("br")),
                    name = o.optString("name"),
                    qty = o.optString("qty"),
                    price = o.optString("price"),
                    total = o.optDouble("total", 0.0)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeWeeklyFilterPayload(w: WeeklyFilter): String = JSONObject().apply {
        put("qtyRows", JSONArray().apply {
            w.qtyRows.forEach { r ->
                put(JSONObject().apply {
                    put("day", r.day); put("date", r.date)
                    put("qty", r.qty); put("cash", r.cash)
                    put("debt", r.debt); put("expense", r.expense)
                })
            }
        })
        put("salesRows", JSONArray().apply {
            w.salesRows.forEach { r ->
                put(JSONObject().apply {
                    put("day", r.day); put("date", r.date)
                    put("cash", r.cash); put("saleGross", r.saleGross); put("outAmt", r.outAmt)
                    put("weeklyAmt", r.weeklyAmt); put("weeklyNote", r.weeklyNote)
                    put("weeklySalesAmt", r.weeklySalesAmt); put("weeklySalesNote", r.weeklySalesNote)
                    put("prevAmt", r.prevAmt); put("prevNote", r.prevNote)
                })
            }
        })
        put("moneyRows", JSONArray().apply {
            w.moneyRows.forEach { r ->
                put(JSONObject().apply {
                    put("day", r.day); put("date", r.date)
                    put("yemeni", r.yemeni)
                    put("saudiAmt", r.saudiAmt); put("saudiExch", r.saudiExch)
                    put("omaniAmt", r.omaniAmt); put("omaniExch", r.omaniExch)
                    put("dirhamAmt", r.dirhamAmt); put("dirhamExch", r.dirhamExch)
                })
            }
        })
    }.toString()

    fun decodeWeeklyFilterPayload(w: WeeklyFilter, jsonStr: String): WeeklyFilter {
        if (jsonStr.isBlank()) return w
        return try {
            val o = JSONObject(jsonStr)
            val qArr = o.optJSONArray("qtyRows")
            val sArr = o.optJSONArray("salesRows")
            val mArr = o.optJSONArray("moneyRows")
            w.copy(
                qtyRows = if (qArr != null) (0 until qArr.length()).map { i ->
                    val x = qArr.getJSONObject(i)
                    WeeklyQtyRow(x.optString("day"), x.optString("date"), x.optString("qty"), x.optString("cash"), x.optString("debt"), x.optString("expense"))
                } else emptyList(),
                salesRows = if (sArr != null) (0 until sArr.length()).map { i ->
                    val x = sArr.getJSONObject(i)
                    WeeklySalesRow(x.optString("day"), x.optString("date"), x.optString("cash"), x.optString("saleGross"), x.optString("outAmt"), x.optString("weeklyAmt"), x.optString("weeklyNote"), x.optString("weeklySalesAmt"), x.optString("weeklySalesNote"), x.optString("prevAmt"), x.optString("prevNote"))
                } else emptyList(),
                moneyRows = if (mArr != null) (0 until mArr.length()).map { i ->
                    val x = mArr.getJSONObject(i)
                    WeeklyMoneyRow(x.optString("day"), x.optString("date"), x.optString("yemeni"), x.optString("saudiAmt"), x.optString("saudiExch"), x.optString("omaniAmt"), x.optString("omaniExch"), x.optString("dirhamAmt"), x.optString("dirhamExch"))
                } else emptyList()
            )
        } catch (_: Exception) {
            w
        }
    }

    fun encodeDetailForm(f: DetailFormData): String = JSONObject().apply {
        put("qQty", f.qQty); put("qCash", f.qCash); put("qDebt", f.qDebt); put("qOut", f.qOut)
        put("sSale", f.sSale); put("sWeekly", f.sWeekly); put("sPrivateOut", f.sPrivateOut)
        put("wLabel", f.wLabel); put("wValue", f.wValue); put("note", f.note)
        put("manualOverrides", JSONObject(f.manualOverrides))
        put("receivedRows", JSONArray().apply {
            f.receivedRows.forEach { r -> put(JSONObject().apply { put("id", r.id); put("name", r.name); put("amount", r.amount) }) }
        })
        put("debtRows", JSONArray().apply {
            f.debtRows.forEach { r -> put(JSONObject().apply { put("id", r.id); put("name", r.name); put("qty", r.qty); put("amount", r.amount); put("weekly", r.weekly); put("rest", r.rest) }) }
        })
        put("moneyRows", JSONArray().apply {
            f.moneyRows.forEach { r -> put(JSONObject().apply { put("id", r.id); put("amount", r.amount); put("label", r.label); put("value", r.value) }) }
        })
        put("withdrawSnapshot", JSONArray().apply {
            f.withdrawSnapshot.forEach { w -> put(JSONObject().apply { put("name", w.name); put("amount", w.amount); put("date", w.date); put("note", w.note) }) }
        })
        put("moneyDaysSnapshot", JSONArray().apply {
            f.moneyDaysSnapshot.forEach { d -> put(JSONObject().apply { put("cur", d.cur); put("amount", d.amount); put("rate", d.rate); put("value", d.value); put("date", d.date); put("dayName", d.dayName) }) }
        })
    }.toString()

    fun decodeDetailForm(jsonStr: String): DetailFormData {
        if (jsonStr.isBlank()) return DetailFormData()
        return try {
            val o = JSONObject(jsonStr)
            val ovObj = o.optJSONObject("manualOverrides")
            val ovMap = mutableMapOf<String, String>()
            if (ovObj != null) ovObj.keys().forEach { k -> ovMap[k] = ovObj.optString(k) }

            val recArr = o.optJSONArray("receivedRows")
            val recRows = if (recArr != null) (0 until recArr.length()).map { i ->
                val x = recArr.getJSONObject(i)
                DetailReceivedRow(x.optString("id", newId("dr")), x.optString("name"), x.optString("amount"))
            } else emptyList()

            val debArr = o.optJSONArray("debtRows")
            val debRows = if (debArr != null) (0 until debArr.length()).map { i ->
                val x = debArr.getJSONObject(i)
                DetailDebtRow(x.optString("id", newId("dd")), x.optString("name"), x.optString("qty"), x.optString("amount"), x.optString("weekly"), x.optDouble("rest", 0.0))
            } else emptyList()

            val monArr = o.optJSONArray("moneyRows")
            val monRows = if (monArr != null && monArr.length() > 0) (0 until monArr.length()).map { i ->
                val x = monArr.getJSONObject(i)
                DetailMoneyRow(x.optString("id", newId("dm")), x.optString("amount"), x.optString("label"), x.optString("value"))
            } else DetailFormData().moneyRows

            val wArr = o.optJSONArray("withdrawSnapshot")
            val wList = if (wArr != null) (0 until wArr.length()).map { i ->
                val x = wArr.getJSONObject(i)
                DetailWithdrawItem(x.optString("name"), x.optDouble("amount"), x.optString("date"), x.optString("note"))
            } else emptyList()

            val mdArr = o.optJSONArray("moneyDaysSnapshot")
            val mdList = if (mdArr != null) (0 until mdArr.length()).map { i ->
                val x = mdArr.getJSONObject(i)
                DetailMoneyDayItem(x.optString("cur"), x.optDouble("amount"), x.optDouble("rate", 1.0), x.optDouble("value"), x.optString("date"), x.optString("dayName"))
            } else emptyList()

            DetailCalculator.recalculate(
                DetailFormData(
                    qQty = o.optString("qQty"), qCash = o.optString("qCash"),
                    qDebt = o.optString("qDebt"), qOut = o.optString("qOut"),
                    sSale = o.optString("sSale"), sWeekly = o.optString("sWeekly"),
                    sPrivateOut = o.optString("sPrivateOut"),
                    wLabel = o.optString("wLabel", "السحب فلوس"), wValue = o.optString("wValue"),
                    note = o.optString("note"),
                    manualOverrides = ovMap,
                    receivedRows = recRows,
                    debtRows = debRows,
                    moneyRows = monRows,
                    withdrawSnapshot = wList,
                    moneyDaysSnapshot = mdList
                )
            )
        } catch (_: Exception) {
            DetailFormData()
        }
    }

    fun encodeClockSubRows(rows: List<ClockDebtSubRow>): String = JSONArray().apply {
        rows.forEach { r ->
            put(JSONObject().apply {
                put("name", r.name); put("amount", r.amount)
                put("qty", r.qty); put("rest", r.rest)
            })
        }
    }.toString()

    fun decodeClockSubRows(jsonStr: String): List<ClockDebtSubRow> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ClockDebtSubRow(o.optString("name"), o.optDouble("amount"), o.optDouble("qty"), o.optDouble("rest"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeTsRows(rows: List<TsRowCurrency>): String = JSONArray().apply {
        rows.forEach { r ->
            put(JSONObject().apply { put("cur", r.cur); put("a", r.a); put("r", r.r) })
        }
    }.toString()

    fun decodeTsRows(jsonStr: String): List<TsRowCurrency> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TsRowCurrency(o.optString("cur"), o.optDouble("a"), o.optDouble("r", 1.0))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeLines(lines: List<String>): String = JSONArray().apply { lines.forEach { put(it) } }.toString()

    fun decodeLines(jsonStr: String): List<String> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { arr.optString(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeBuyerTransferRows(rows: List<BuyerTransferRow>): String = JSONArray().apply {
        rows.forEach { r ->
            put(JSONObject().apply { put("id", r.id); put("name", r.name); put("buy", r.buy); put("exp", r.exp) })
        }
    }.toString()

    fun decodeBuyerTransferRows(jsonStr: String): List<BuyerTransferRow> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                BuyerTransferRow(o.optString("id", newId("btr")), o.optString("name"), o.optDouble("buy"), o.optDouble("exp"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeBuyerAnnualRows(rows: List<BuyerAnnualRow>): String = JSONArray().apply {
        rows.forEach { r ->
            put(JSONObject().apply {
                put("id", r.id); put("from", r.from); put("to", r.to)
                put("day", r.day); put("name", r.name); put("buy", r.buy)
                put("sell", r.sell); put("habba", r.habba); put("diff", r.diff)
                put("profitLabel", r.profitLabel); put("autoKey", r.autoKey)
            })
        }
    }.toString()

    fun decodeBuyerAnnualRows(jsonStr: String): List<BuyerAnnualRow> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(jsonStr)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                BuyerAnnualRow(
                    id = o.optString("id", newId("bar")),
                    from = o.optString("from"), to = o.optString("to"),
                    day = o.optString("day"), name = o.optString("name"),
                    buy = o.optDouble("buy"), sell = o.optDouble("sell"),
                    habba = o.optDouble("habba"), diff = o.optDouble("diff"),
                    profitLabel = o.optString("profitLabel", "0"),
                    autoKey = o.optString("autoKey")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeCurMap(map: Map<String, Pair<Double, Double>>): String = JSONObject().apply {
        map.forEach { (k, v) ->
            put(k, JSONObject().apply { put("a", v.first); put("r", v.second) })
        }
    }.toString()

    fun decodeCurMap(jsonStr: String): Map<String, Pair<Double, Double>> {
        if (jsonStr.isBlank()) return emptyMap()
        return try {
            val o = JSONObject(jsonStr)
            val out = linkedMapOf<String, Pair<Double, Double>>()
            o.keys().forEach { k ->
                val sub = o.getJSONObject(k)
                out[k] = sub.optDouble("a") to sub.optDouble("r", 1.0)
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }
}
