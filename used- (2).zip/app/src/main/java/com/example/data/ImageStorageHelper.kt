package com.example.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object ImageStorageHelper {

    private fun imagesDir(context: Context): File =
        File(context.filesDir, "images").apply { if (!exists()) mkdirs() }

    suspend fun savePickedImage(
        context: Context,
        uri: Uri,
        maxDimension: Int = 1080,
        quality: Int = 78
    ): String? = withContext(Dispatchers.IO) {
        try {
            val input = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val bitmap = input.use { BitmapFactory.decodeStream(it) } ?: return@withContext null
            val scaled = scaleBitmap(bitmap, maxDimension)
            val file = File(imagesDir(context), "img_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
            FileOutputStream(file).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
            }
            if (scaled !== bitmap) bitmap.recycle()
            scaled.recycle()
            file.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    fun deleteStoredImage(path: String?) {
        if (path.isNullOrBlank()) return
        try {
            val f = File(path)
            if (f.exists() && f.parentFile?.name == "images") {
                f.delete()
            }
        } catch (_: Exception) {
        }
    }

    fun toBase64DataUrl(path: String?): String {
        if (path.isNullOrBlank()) return ""
        return try {
            val f = File(path)
            if (!f.exists()) return ""
            val bytes = f.readBytes()
            "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun saveToGallery(context: Context, path: String, displayName: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val src = File(path)
                if (!src.exists()) return@withContext false
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AlIdariPro")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                val itemUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext false
                resolver.openOutputStream(itemUri)?.use { out ->
                    src.inputStream().use { it.copyTo(out) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(itemUri, values, null, null)
                }
                true
            } catch (_: Exception) {
                false
            }
        }

    private fun scaleBitmap(src: Bitmap, maxDim: Int): Bitmap {
        val w = src.width
        val h = src.height
        val maxSide = maxOf(w, h)
        if (maxSide <= maxDim) return src
        val ratio = maxDim.toFloat() / maxSide.toFloat()
        return Bitmap.createScaledBitmap(src, (w * ratio).toInt().coerceAtLeast(1), (h * ratio).toInt().coerceAtLeast(1), true)
    }

    fun compressBase64(dataUrl: String): ByteArray? {
        return try {
            val b64 = dataUrl.substringAfter("base64,", dataUrl)
            val raw = Base64.decode(b64, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: return raw
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 78, out)
            bmp.recycle()
            out.toByteArray()
        } catch (_: Exception) {
            null
        }
    }
}
