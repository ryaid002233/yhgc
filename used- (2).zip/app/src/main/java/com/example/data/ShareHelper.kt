package com.example.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.domain.MessageSettings
import java.io.File

object ShareHelper {

    fun normalizePhone(rawPhone: String, msg: MessageSettings): String {
        val digits = rawPhone.replace(Regex("[^0-9+]"), "")
        if (digits.isBlank()) return ""
        if (digits.startsWith("+")) return digits.drop(1)
        if (digits.startsWith("00")) return digits.drop(2)
        val clean = digits.trimStart('0')
        val codeDigits = msg.countryCode.replace(Regex("[^0-9]"), "")
        return if (codeDigits.isNotBlank() && !clean.startsWith(codeDigits)) {
            codeDigits + clean
        } else {
            clean
        }
    }

    fun openWhatsApp(context: Context, rawPhone: String, text: String, msg: MessageSettings) {
        val phone = normalizePhone(rawPhone, msg)
        val url = if (phone.isNotBlank()) {
            "https://wa.me/$phone?text=${Uri.encode(text)}"
        } else {
            "https://wa.me/?text=${Uri.encode(text)}"
        }
        val pkg = if (msg.waType == "green") "com.whatsapp" else "com.whatsapp.w4b"
        val targeted = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(targeted)
        } catch (_: Exception) {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (_: Exception) {
                shareText(context, "رسالة", text)
            }
        }
    }

    fun openSms(context: Context, rawPhone: String, text: String, msg: MessageSettings) {
        val num = when (msg.lineKey) {
            "zero" -> rawPhone.trim()
            "country" -> "+" + normalizePhone(rawPhone, msg)
            else -> rawPhone.replace(Regex("[^0-9+]"), "")
        }
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(num)}")).apply {
            putExtra("sms_body", text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            shareText(context, "رسالة", text)
        }
    }

    fun shareText(context: Context, title: String, text: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(sendIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun copyToClipboard(context: Context, text: String, toastMessage: String = "تم النسخ") {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("SmartAdmin", text))
        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
    }

    fun shareImage(context: Context, imagePath: String, title: String = "صورة مرفقة") {
        val file = File(imagePath)
        if (!file.exists()) return
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun shareFile(context: Context, file: File, mimeType: String, title: String) {
        if (!file.exists()) return
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun openExternalUrl(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }
}
