package com.example

import com.example.domain.NameSuggestionHelper
import org.junit.Assert.*
import org.junit.Test

class NameSuggestionUnitTest {

    @Test
    fun suggestNames_matchesThreeWordArabicPrefixAndTokens() {
        val pool = listOf(
            "محمد أحمد",
            "محمد علي صالح",
            "أحمد يحيى القباطي",
            "خالد سعيد عمر الحمادي"
        )

        val singleWord = NameSuggestionHelper.suggestNames("محم", pool)
        assertEquals("محمد علي صالح", singleWord.first())
        assertTrue(singleWord.contains("محمد أحمد"))

        val threeWordInitials = NameSuggestionHelper.suggestNames("م ع ص", pool)
        assertEquals(listOf("محمد علي صالح"), threeWordInitials)

        val partialThreeWords = NameSuggestionHelper.suggestNames("محمد ع ص", pool)
        assertEquals(listOf("محمد علي صالح"), partialThreeWords)
    }

    @Test
    fun suggestNames_normalizesArabicVariantsAndDiacritics() {
        val pool = listOf("أحمد إبرآهيم القُباطِي")
        val matches = NameSuggestionHelper.suggestNames("احمد ابراهيم القباطي", pool)
        // Exact normalized match with same cleaned text skips self only when identical, or matches partial:
        val partial = NameSuggestionHelper.suggestNames("احمد ابراهي", pool)
        assertEquals(listOf("أحمد إبرآهيم القُباطِي"), partial)
        assertEquals(0, matches.size)
    }

    @Test
    fun suggestNames_supportsUnorderedTokenMatch() {
        val pool = listOf("صالح محمد علي", "يحيى عبدالله ناصر")
        val matches = NameSuggestionHelper.suggestNames("علي صالح", pool)
        assertEquals(listOf("صالح محمد علي"), matches)
    }

    @Test
    fun suggestNames_prioritizesThreeWordNamesWhenEmptyQuery() {
        val pool = listOf(
            "علي",
            "محمد علي",
            "سعيد يحيى صالح",
            "أحمد حسن محمد"
        )
        val top = NameSuggestionHelper.suggestNames("", pool, limit = 4)
        assertEquals(listOf("سعيد يحيى صالح", "أحمد حسن محمد", "محمد علي", "علي"), top)
    }

    @Test
    fun addAndRemoveNames_deduplicatesAndPreservesRecency() {
        val initial = listOf("أحمد علي صالح", "خالد عمر")
        val updated = NameSuggestionHelper.addNamesToSaved(
            existing = initial,
            newNames = listOf("  احمد   علي   صالح ", "يحيى ناصر قاسم", "12345", "بدون تخصيص")
        )
        assertEquals(listOf("يحيى ناصر قاسم", "احمد علي صالح", "خالد عمر"), updated)

        val afterRemove = NameSuggestionHelper.removeName(updated, "احمد علي صالح")
        assertEquals(listOf("يحيى ناصر قاسم", "خالد عمر"), afterRemove)
    }

    @Test
    fun mergeSavedNames_keepsExplicitOrderAndAddsHarvestedWithoutDuplicates() {
        val explicit = listOf("محمد علي صالح")
        val harvested = listOf("محمد علي صالح", "علي حسن يحيى", "  9999 ")
        val merged = NameSuggestionHelper.mergeSavedNames(explicit, harvested)
        assertEquals(listOf("محمد علي صالح", "علي حسن يحيى"), merged)
    }
}
